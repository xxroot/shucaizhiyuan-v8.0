<?php
declare (strict_types = 1);
namespace app\admin\controller;

use think\App;
use think\facade\View;

abstract class Base
{
    /**
     * Request实例
     * @var \think\Request
     */
    protected $request;

    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;

    /**
     * 是否批量验证
     * @var bool
     */
    protected $batchValidate = false;

    /**
     * 控制器中间件
     * @var array
     */
    protected $middleware = [];

    /**
     * 构造方法
     * @access public
     * @param  App  $app  应用对象
     */
    public function __construct(App $app)
    {
        $this->app     = $app;
        $this->request = $this->app->request;
        $this->initialize();
    }

    protected function initialize()
    {
        global $_G;
        if (empty($_G['uid']) || empty($_G['user'])) {
            return redirect('admin/account/login');
        }
        if ($_G['user']['type'] !== 'system') {
            $_G['user']->logout();
            return redirect('index/index/index');
        }
        $this->admin_menu();
    }

    private function admin_menu()
    {
        global $_G;
        $_G['admin_menu'] = [
            'Index'    => [
                'name'     => '控制台',
                'icon'     => 'icon-home',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '数据统计',
                        'active_list' => ['index'],
                        'url'         => 'admin/index/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '访问前台',
                        'active_list' => [],
                        'url'         => 'index/index/index',
                        'target'      => '_blank',
                    ],
                ],
            ],
            'Setting'  => [
                'name'     => '设置',
                'icon'     => 'icon-setting',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '基础设置',
                        'active_list' => ['index'],
                        'url'         => 'admin/setting/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '注册与访问',
                        'active_list' => ['account'],
                        'url'         => 'admin/setting/account',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '邮箱设置',
                        'active_list' => ['email'],
                        'url'         => 'admin/setting/email',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '附件存储',
                        'active_list' => ['storage'],
                        'url'         => 'admin/setting/storage',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '裂变推广',
                        'active_list' => ['fission'],
                        'url'         => 'admin/setting/fission',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '支付配置',
                        'active_list' => ['payment'],
                        'url'         => 'admin/setting/payment',
                    ],
                ],
            ],
            'Site'     => [
                'name'     => '站点',
                'icon'     => 'icon-extend',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '素材站点',
                        'active_list' => ['index', 'add_site', 'edit_site', 'delete_site', 'cookie', 'add_cookie', 'edit_cookie', 'delete_cookie'],
                        'url'         => 'admin/site/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => 'Cookie列表',
                        'active_list' => ['cookie_all'],
                        'url'         => 'admin/site/cookie_all',
                    ],
                ],
            ],
            'User'     => [
                'name'     => '用户',
                'icon'     => 'icon-users',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '用户列表',
                        'active_list' => ['index', 'add_user', 'edit_user', 'batch_add'],
                        'url'         => 'admin/user/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '导出用户',
                        'active_list' => ['export_user'],
                        'url'         => 'admin/user/export_user',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '搜索用户',
                        'active_list' => ['search_user'],
                        'url'         => 'admin/user/search_user',
                    ],
                ],
            ],
            'Portal'   => [
                'name'     => '内容',
                'icon'     => 'icon-article',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '文章管理',
                        'active_list' => ['index', 'add_article', 'edit_article', 'delete_article'],
                        'url'         => 'admin/portal/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '用户分享',
                        'active_list' => ['share', 'add_share', 'edit_share', 'delete_share'],
                        'url'         => 'admin/portal/share',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '附件管理',
                        'active_list' => ['attach', 'add_attach', 'edit_attach', 'delete_attach'],
                        'url'         => 'admin/portal/attach',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '下载记录',
                        'active_list' => ['download_log', 'add_download_log', 'edit_download_log', 'delete_download_log'],
                        'url'         => 'admin/portal/download_log',
                    ],
                ],
            ],
            'Announce' => [
                'name'     => '运营',
                'icon'     => 'icon-circle',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '套餐配置',
                        'active_list' => ['index', 'add_meal', 'edit_meal'],
                        'url'         => 'admin/announce/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '充值卡',
                        'active_list' => ['card', 'card_add', 'card_edit', 'card_delete', 'card_search', 'card_export'],
                        'url'         => 'admin/announce/card',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '套餐订单',
                        'active_list' => ['meal_order', 'meal_info'],
                        'url'         => 'admin/announce/meal_order',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '充值订单',
                        'active_list' => ['recharge', 'recharge_info'],
                        'url'         => 'admin/announce/recharge',
                    ],
                ],
            ],
            'Tools'    => [
                'name'     => '工具',
                'icon'     => 'icon-tools',
                'sub_menu' => [
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '更新缓存',
                        'active_list' => ['index'],
                        'url'         => 'admin/tools/index',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '数据备份',
                        'active_list' => ['database'],
                        'url'         => 'admin/tools/database',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '数据恢复',
                        'active_list' => ['backup'],
                        'url'         => 'admin/tools/backup',
                    ],
                    [
                        'icon'        => 'icon-nav',
                        'name'        => '检查更新',
                        'active_list' => ['upgrade'],
                        'url'         => 'admin/tools/upgrade',
                    ],
                ],
            ],
        ];
        View::assign('_G', $_G);
    }
}

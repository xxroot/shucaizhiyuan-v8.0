<?php
namespace app\admin\controller;

use think\facade\Db;

class Update
{

    public function __construct()
    {
        exit('error');
    }

    public function all2()
    {
        set_time_limit(0);
        Db::name('user_site_access')->where('id', '>', 0)->update(['out_time' => '1593792000']);
        echo 'OK';
    }
    public function all()
    {
        set_time_limit(0);
        $access_list = [];
        foreach (Db::name('user_site_access')->select() as $access) {
            if (empty($access_list[$access['uid']])) {
                $access_list[$access['uid']] = [];
            }
            $access_list[$access['uid']][$access['site_id']] = $access;
        }
        foreach (Db::name('user_main')->select() as $user) {
            for ($i = 1; $i < 28; $i++) {
                if (empty($access_list[$user['uid']][$i])) {
                    Db::name('user_site_access')->insert([
                        'uid'         => $user['uid'],
                        'site_id'     => $i,
                        'parse_times' => 0,
                        'day_times'   => 10,
                        'week_times'  => 0,
                        'month_times' => 0,
                        'year_times'  => 0,
                        'max_times'   => 0,
                        'out_time'    => '1593792000',
                    ]);
                } else {
                    Db::name('user_site_access')->where('id', '=', $access_list[$user['uid']][$i]['id'])->update([
                        'parse_times' => 0,
                        'day_times'   => 10,
                        'week_times'  => 0,
                        'month_times' => 0,
                        'year_times'  => 0,
                        'max_times'   => 0,
                        'out_time'    => '1593792000',
                    ]);
                }
            }
        }
        echo '升级成功';
    }

    public function index()
    {
        set_time_limit(0);
        $users    = Db::name('member')->select();
        $old_sets = [];
        foreach (Db::name('setting')
            ->where('key', 'in', ['site_name', 'allow_register', 'must_login', 'AccessKeyId', 'AccessKeySecret', 'Endpoint', 'Bucket', 'auto_save_file', 'email_host', 'email_port', 'email_username', 'email_password', 'email_fromname'])
            ->select() as $set) {
            $old_sets[$set['key']] = $set['value'];
        }
        $new_sql = <<<EOT
DROP TABLE IF EXISTS `setting`;
DROP TABLE IF EXISTS `common_setting`;
CREATE TABLE `common_setting` (
	`key` varchar(255) NOT NULL DEFAULT '' COMMENT '变量名',
	`value` mediumtext NOT NULL COMMENT '变量值',
	PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='全局设置';

INSERT INTO `common_setting` VALUES
('site_name','百度一下'),
('site_close',0),
('site_qq','3555990206'),
('site_close_tip','<p>网站维护中，请稍后再访问~</p>'),
('allow_register',1),
('must_login',0),
('allow_same_login',0),
('verify_code_time',30),
('AccessKeyId',''),
('AccessKeySecret',''),
('Endpoint','http://oss-cn-shanghai.aliyuncs.com'),
('Bucket',''),
('auto_save_type',''),
('parse_space_time',60),
('email_host','smtp.qq.com'),
('email_port',465),
('email_username',''),
('email_password',''),
('email_fromname',''),
('email_reset_password',0),
('email_reset_content','<p>您申请的重置账户登陆密码验证码：<span style="color: rgb(40, 167, 69); font-size: 11.2px; font-weight: bolder;">[REGISTER_CODE]</span>，该验证码 30 分钟内有效。如非本人操作请忽略。</p>'),
('email_register',0),
('email_register_content','<p>您申请的账户注册验证码：<span style="color: rgb(40, 167, 69); font-size: 11.2px; font-weight: bolder;">[REGISTER_CODE]</span>，该验证码 30 分钟内有效。如非本人操作请忽略。</p>'),
('user_fission',1),
('user_fission_time',48),
('user_fission_lv',3),
('user_fission_reward','{"times":{"27":"1","26":"1","25":"1","24":"1","23":"1","22":"1","21":"1","20":"1","19":"1","18":"1","17":"1","16":"1","15":"1","14":"1","13":"1","11":"1","10":"1","9":"1","8":"1","7":"1","6":"1","5":"1","4":"1","3":"1","2":"1","1":"1"},"out_time":{"27":"8760","26":"8760","25":"8760","24":"8760","23":"8760","22":"8760","21":"8760","20":"8760","19":"8760","18":"8760","17":"8760","16":"8760","15":"8760","14":"8760","13":"8760","11":"8760","10":"8760","9":"8760","8":"8760","7":"8760","6":"8760","5":"8760","4":"8760","3":"8760","2":"8760","1":"8760"}}'),
('user_fission_reward_lv',3),
('user_fission_reward_day_times',10),
('user_fission_reward_max_times',20),
('api_domain','http://39.98.209.69/'),
('recharge_all',0),
('withdraw_all',0),
('register_review',0),
('alipay_switch',1),
('alipay_app_id',''),
('alipay_merchant_private_key',''),
('alipay_alipay_public_key',''),
('wxpay_switch',1),
('wxpay_app_id',''),
('wxpay_merchant_id',''),
('wxpay_key',''),
('wxpay_app_secret',''),
('qqpay_switch',1),
('qqpay_mch_id',''),
('qqpay_key',''),
('min_recharge_price',10),
('max_recharge_price',1000),
('version','2019071301');

DROP TABLE IF EXISTS `jobs`;

DROP TABLE IF EXISTS `common_queue`;
CREATE TABLE `common_queue`  (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`queue` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
	`payload` longtext NOT NULL COMMENT '执行任务文件',
	`attempts` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '已执行次数',
	`reserved` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '重发次数',
	`reserved_at` int(11) unsigned NULL DEFAULT NULL COMMENT '上次执行时间',
	`available_at` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '下次执行时间',
	`created_at` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
	`status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='队列';

INSERT INTO `common_queue` VALUES
(1, 'download', '{\"job\":\"common\\/Download\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}', 0, 0, NULL, 1561960408, 1561960408, 1),
(2, 'upload', '{\"job\":\"common\\/Upload\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}', 0, 0, NULL, 1561960408, 1561960408, 1),
(3, 'default', '{\"job\":\"common\\/Common\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}', 0, 0, NULL, 1561960408, 1561960408, 1);

DROP TABLE IF EXISTS `web_third`;
DROP TABLE IF EXISTS `web_site`;
CREATE TABLE `web_site`  (
	`site_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`title` varchar(255) NOT NULL DEFAULT '' COMMENT '网站名称',
	`url` varchar(255) NOT NULL DEFAULT '' COMMENT '官网地址',
	`url_regular` varchar(255) NOT NULL DEFAULT '' COMMENT '特征码',
	`demo_url` varchar(255) NOT NULL DEFAULT '' COMMENT '下载地址',
	`param` text NOT NULL COMMENT '额外配置参数',
	`status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-禁用，1-启用',
	PRIMARY KEY (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='资源站点';

INSERT INTO `web_site` VALUES
(1, '觅元素', 'http://www.51yuansu.com/', '51yuansu.com', 'http://www.51yuansu.com/sc/lcvnlvrkig.html', '[]', 1),
(2, '我图网', 'https://www.ooopic.com/', 'ooopic.com', 'https://www.ooopic.com/pic_27796570.html', '[]', 1),
(3, '千图网', 'https://www.58pic.com/', '58pic.com', 'http://www.58pic.com/newpic/33513860.html', '[]', 1),
(4, '昵图网', 'http://www.nipic.com/', 'nipic.com', 'http://www.nipic.com/show/22717419.html', '[]', 1),
(5, '90设计', 'http://90sheji.com/', '90sheji.com', 'http://90sheji.com/sucai/22176591.html', '[]', 1),
(6, '千库网', 'https://588ku.com/', '588ku.com', 'https://588ku.com/ycpng/11716645.html', '[]', 1),
(7, '包图网', 'https://ibaotu.com/', 'ibaotu.com', 'https://ibaotu.com/sucai/18002368.html', '[]', 1),
(8, '摄图网', 'http://699pic.com/', '699pic.com', 'http://699pic.com/tupian-501104528.html', '[]', 1),
(9, 'CSDN下载', 'https://download.csdn.net/', 'download.csdn.net', 'https://download.csdn.net/download/qgy879765368/10961370', '[]', 1),
(10, '稻壳儿', 'http://www.docer.com/', 'docer.com', 'http://detail.docer.com/4512476.html', '[]', 1),
(11, '百度文库', 'https://wenku.baidu.com/', 'wenku.baidu.com', 'https://wenku.baidu.com/view/72264a1b6d85ec3a87c24028915f804d2b16877f.html', '[]', 1),
(13, '熊猫办公', 'http://www.tukuppt.com/', 'tukuppt.com', 'http://www.tukuppt.com/muban/pgxdkwmz.html', '[]', 1),
(14, '92素材', 'http://www.92sucai.com/', '92sucai.com', 'http://www.92sucai.com/ae/31712.html', '[]', 1),
(15, '演界网', 'http://www.yanj.cn/', 'yanj.cn', 'http://www.yanj.cn/goods-177783.html', '[]', 1),
(16, '彼岸图', 'http://pic.netbian.com/', 'pic.netbian.com', 'http://pic.netbian.com/tupian/23507.html', '[]', 1),
(17, '绘艺素材', 'https://www.huiyi8.com/', 'huiyi8.com', 'https://www.huiyi8.com/sc/1100690.html', '[]', 1),
(18, '图品汇', 'https://www.88tph.com/', '88tph.com', 'https://www.88tph.com/sucai/12508222.html', '[]', 1),
(19, '觅知网', 'https://www.51miz.com/', '51miz.com', 'http://www.51miz.com/sucai/999440.html', '[]', 1),
(20, '六图网', 'https://www.16pic.com/', '16pic.com', 'https://www.16pic.com/pic/pic_8717237.html', '[]', 1),
(21, '全图网', 'https://www.125pic.com/', '125pic.com', 'http://www.125pic.com/sucai/104678', '[]', 1),
(22, '风云办公', 'http://ppt.dwuva.com/', 'ppt.dwuva.com', 'http://ppt.dwuva.com/scb/a6b61897.html', '[]', 1),
(23, '风云办公2', 'http://www.ppt118.com/', 'ppt118.com', 'http://www.ppt118.com/scb/a6b61897.html', '[]', 1),
(24, '易图网', 'http://www.yipic.cn/', 'yipic.cn', 'http://www.yipic.cn/sucai/4413479.html', '[]', 1),
(25, '图行天下', 'http://www.photophoto.cn/', 'photophoto.cn', 'http://www.photophoto.cn/pic/32218471.html', '[]', 1),
(26, '万素网', 'http://669pic.com/', '669pic.com', 'http://669pic.com/sc/173705.html', '[]', 1),
(27, '快图网', 'http://www.kuaipng.com/', 'kuaipng.com', 'http://www.kuaipng.com/sucai/20889.html', '[]', 1);

DROP TABLE IF EXISTS `web_site_cookie`;
CREATE TABLE `web_site_cookie`  (
	`cookie_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'cookie_id',
	`site_id` smallint(6) unsigned NOT NULL DEFAULT 0 COMMENT '网站ID',
	`title` varchar(500) NOT NULL DEFAULT '' COMMENT '名称，方便自己查看',
	`content` text NOT NULL COMMENT 'cookie内容',
	`day_used` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '今日已使用次数',
	`day_max` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '该COOKIE每日可用次数',
	`all_used` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '总是用次数',
	`all_max` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '总可用次数',
	`use_time` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '最后使用时间',
	`available` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-失效，1-有效',
	`status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-禁用，1-启用',
	PRIMARY KEY (`cookie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='站点Cookie';

ALTER TABLE `attach` RENAME TO `attach_main`;
ALTER TABLE `attach_main` ADD `uid` INT(11) NOT NULL DEFAULT 0 AFTER `attach_id`;
ALTER TABLE `attach_main` ADD `from` varchar(255) NOT NULL DEFAULT '' AFTER `site_id`;

ALTER TABLE `member` RENAME TO `user_main`;
ALTER TABLE `user_main` ADD `up_uid` INT(11) NOT NULL DEFAULT 0 AFTER `uid`;
ALTER TABLE `user_main` ADD `proxy_uid` INT(11) NOT NULL DEFAULT 0 AFTER `up_uid`;
ALTER TABLE `user_main` ADD `qq` varchar(20) NOT NULL DEFAULT '' AFTER `password_see`;
ALTER TABLE `user_main` ADD `weixin` varchar(20) NOT NULL DEFAULT '' AFTER `qq`;
ALTER TABLE `user_main` ADD `discount` varchar(20) NOT NULL DEFAULT '' AFTER `type`;
ALTER TABLE `user_main` DROP `out_time`;
ALTER TABLE `user_main` DROP `site_access`;
ALTER TABLE `user_main` DROP `from`;

DROP TABLE IF EXISTS `member_access`;

ALTER TABLE `member_log` RENAME TO `user_download_log`;
ALTER TABLE `user_download_log` ADD `type` varchar(255) NOT NULL DEFAULT '' AFTER `parse`;
ALTER TABLE `user_download_log` CHANGE `times` `use_times` mediumint(8) NOT NULL DEFAULT 0;
ALTER TABLE `user_download_log` DROP `delete_time`;

DROP TABLE IF EXISTS `card`;

DROP TABLE IF EXISTS `user_site_access`;
CREATE TABLE `user_site_access` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT 'UID',
	`site_id` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '素材站id',
	`parse_times` mediumint(8) unsigned NOT NULL DEFAULT 0 COMMENT '已解析次数',
	`day_times` mediumint(8) NOT NULL DEFAULT 0 COMMENT '每日可解析次数',
	`week_times` mediumint(8) NOT NULL DEFAULT 0 COMMENT '每周可解析次数',
	`month_times` mediumint(8) NOT NULL DEFAULT 0 COMMENT '每月可解析次数',
	`year_times` mediumint(8) NOT NULL DEFAULT 0 COMMENT '每年可解析次数',
	`max_times` mediumint(8) NOT NULL DEFAULT 0 COMMENT '最大可解析次数',
	`out_time` varchar(20) NOT NULL DEFAULT '0' COMMENT '该站点权限过期时间,-1失效，0永久，时间参数表示过期时间',
	PRIMARY KEY (`id`),
    UNIQUE KEY `uid_site_id` (`uid`,`site_id`),
    KEY `uid` (`uid`),
    KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户解析权限';

DROP TABLE IF EXISTS `user_download_count`;
CREATE TABLE `user_download_count` (
	`count_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
	`site_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '站点ID',
	`day_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '今日解析次数',
	`week_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '本周解析次数',
	`month_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '本月解析次数',
	`year_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '今年解析次数',
	`day_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '日刷新时间',
	`week_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '周刷新时间',
	`month_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '月刷新时间',
	`year_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '年刷新时间',
	PRIMARY KEY (`count_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='解析统计';

DROP TABLE IF EXISTS `user_notification`;
CREATE TABLE `user_notification` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
	`from_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建用户id',
	`to_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收用户id',
	`type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型，system-系统通知,letter-私信',
	`title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
	`message` text NOT NULL COMMENT '详细内容',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
	`read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
	`read_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '阅读ip',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
	`status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-已阅读，1-未读',
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='消息通知';

DROP TABLE IF EXISTS `user_fission`;
CREATE TABLE `user_fission` (
	`spread_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '推广用户UID',
	`fission_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '裂变新用户UID',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建ip',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
	`floor` smallint(6) unsigned NOT NULL DEFAULT '1' COMMENT '层级数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='裂变推广绑定';

DROP TABLE IF EXISTS `user_download_times`;
CREATE TABLE `user_download_times` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
	`uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
	`site_id` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '奖励的站点',
	`times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '奖励次数',
	`used_times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '该奖励已使用次数',
	`from` varchar(50) NOT NULL DEFAULT '' COMMENT '奖励来源类型',
	`summary` varchar(255) NOT NULL DEFAULT '' COMMENT '奖励说明',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
	`update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
	`out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
	`status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-无效，1-有效',
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='奖励次数';

DROP TABLE IF EXISTS `user_reward`;
CREATE TABLE `user_reward` (
	`uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
	`day` varchar(50) NOT NULL DEFAULT '' COMMENT '日期',
	`times` smallint(6) NOT NULL DEFAULT '0' COMMENT '当日已获得奖励次数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='奖励统计';

DROP TABLE IF EXISTS `user_recharge`;
CREATE TABLE `user_recharge` (
	`recharge_id` varchar(255) NOT NULL DEFAULT '' COMMENT '主键',
	`uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
	`price` decimal(9,2) NOT NULL DEFAULT '0.00' COMMENT '充值金额',
	`subject` varchar(255) NOT NULL DEFAULT '' COMMENT '充值说明',
	`body` varchar(255) NOT NULL DEFAULT '' COMMENT '充值说明',
	`payinfo` text NOT NULL COMMENT '支付平台返回信息',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
	`update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
	`pay_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
	`status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-无效，0-待支付，1-已完成',
	PRIMARY KEY (`recharge_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户充值订单';

DROP TABLE IF EXISTS `user_meal`;
CREATE TABLE `user_meal` (
	`meal_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
	`type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
	`summary` varchar(500) NOT NULL DEFAULT '' COMMENT '说明',
	`price` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
	`vip_access` text NOT NULL COMMENT 'VIP权限',
	`download_times` text NOT NULL COMMENT '下载权限',
	`proxy_access` text NOT NULL COMMENT '代理开户套餐',
	`status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-禁用，1-启用',
	PRIMARY KEY (`meal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='运营套餐';

DROP TABLE IF EXISTS `user_meal_order`;
CREATE TABLE `user_meal_order` (
	`order_id` varchar(50) NOT NULL DEFAULT '' COMMENT '流水号',
	`uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
	`title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
	`type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
	`body` varchar(500) NOT NULL DEFAULT '' COMMENT '说明',
	`buy_number` smallint(6) NOT NULL DEFAULT 0 COMMENT '购买份数',
	`price` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
	`vip_access` text NOT NULL COMMENT 'VIP权限',
	`download_times` text NOT NULL COMMENT '下载权限',
	`proxy_access` text NOT NULL COMMENT '代理开户套餐',
	`payinfo` text NOT NULL COMMENT '支付平台返回信息',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
	`update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
	`pay_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
	`status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-无效，0-待支付，1-已完成',
	PRIMARY KEY (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户套餐订单';

DROP TABLE IF EXISTS `portal_article`;
CREATE TABLE `portal_article` (
	`article_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT 'uid',
	`subject` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
	`cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
	`message` text NOT NULL COMMENT '详细内容',
	`views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
	`update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
	`status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-隐藏，1-显示',
	PRIMARY KEY (`article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='门户文章';

DROP TABLE IF EXISTS `portal_share`;
CREATE TABLE `portal_share` (
	`share_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
	`uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT 'uid',
	`attach_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '附件ID',
	`site_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '源素材站',
	`from_url` varchar(1000) NOT NULL DEFAULT '' COMMENT '文件来源地址',
	`subject` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
	`cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
	`message` text NOT NULL COMMENT '分享内容',
	`reward` text NOT NULL COMMENT '奖励内容',
	`views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
	`create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
	`create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
	`update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
	`update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
	`delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
	`status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-禁止，0-待审核，1-有效',
	PRIMARY KEY (`share_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件分享';

ALTER TABLE `verify_code` ADD `mobile` varchar(255) NOT NULL DEFAULT '' AFTER `email`;
ALTER TABLE `verify_code` ADD `create_time` INT(11) unsigned NOT NULL DEFAULT 0 AFTER `code`;
ALTER TABLE `verify_code` ADD `status` tinyint(1) NOT NULL DEFAULT 0 AFTER `create_time`;
ALTER TABLE `verify_code` DROP `out_time`;
EOT;
        $this->_run_sql($new_sql);

        foreach ($old_sets as $key => $value) {
            Db::name('common_setting')->where('key', '=', $key)->update(['value' => $value]);
        }
        foreach ($users as $user) {
            $site_access = json_decode($user['site_access'], true);
            if (!empty($site_access)) {
                foreach ($site_access as $site_id => $access) {
                    $site_id = intval($site_id);
                    if ($site_id <= 0) {
                        echo $user['uid'] . ':' . var_dump($site_access);
                        continue;
                    }
                    Db::name('user_site_access')->insert([
                        'uid'         => $user['uid'],
                        'site_id'     => $site_id,
                        'parse_times' => $access['max_used'] ?? 0,
                        'day_times'   => $access['day'] ?? 0,
                        'week_times'  => 0,
                        'month_times' => 0,
                        'year_times'  => 0,
                        'max_times'   => $access['all'] ?? 0,
                        'out_time'    => $user['out_time'] < 0 ? '-1' : ($user['out_time'] == 0 ? '0' : $user['out_time']),
                    ]);
                }
            }
        }
        echo '升级成功';
        exit;
    }

    private function _run_sql($sql = '')
    {
        if (!$sql) {
            return false;
        }
        $i = $error = 0;
        foreach ($this->_split_sql(str_replace(
            [' {prefix}', ' prefix_', ' `prefix_', ' adt_', ' `adt_'],
            [' ' . config('database.prefix'), ' ' . config('database.prefix'), ' `' . config('database.prefix'), ' ' . config('database.prefix'), ' `' . config('database.prefix')],
            $sql)) as $sql) {
            try {
                $result = Db::execute($sql);
                if ($result !== false) {
                    $i++;
                }
            } catch (\Exception $e) {
                $error++;
            }
        }
        return ['success' => $i, 'error' => $error];
    }

    private function _split_sql($sql)
    {
        $sql          = str_replace([PHP_EOL, "\r"], "\n", $sql);
        $ret          = [];
        $num          = 0;
        $queriesarray = explode(";\n", trim($sql));
        unset($sql);
        foreach ($queriesarray as $query) {
            $queries   = explode("\n", trim($query));
            $ret[$num] = '';
            foreach ($queries as $query) {
                $ret[$num] .= substr($query, 0, 1) == "#" ? null : $query;
            }
            $num++;
        }
        return ($ret);
    }
}

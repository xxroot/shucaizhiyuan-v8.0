<?php
namespace app\admin\controller;

use app\admin\controller\Base;
use app\common\model\AttachMain;
use app\common\model\UserDownloadLog;
use app\common\model\UserMain;
use app\common\model\WebSite;
use think\facade\Request;
use think\facade\View;

class Index extends Base
{
    public function index()
    {
        $count = [
            'users'         => UserMain::count('uid'),
            'web_sites'     => WebSite::where('status', '=', 1)->count('site_id'),
            'attachs'       => AttachMain::where('status', '>', 1)->count('attach_id'),
            'download_logs' => UserDownloadLog::where('status', '=', 1)->count('log_id'),
            'proxy_users'   => UserMain::where('type', '=', 'proxy')->count(),
            'fission_users' => UserMain::where('up_uid', '<>', 0)->count('uid'),
        ];
        $now  = Request::time();
        $days = $logs = $registers = [];
        for ($i = 6; $i >= 0; $i--) {
            $d      = date('Y-m-d', $now - $i * 86400);
            $logs[] = UserDownloadLog::where([
                ['create_time', '>=', strtotime($d . ' 00:00:00')],
                ['create_time', '<=', strtotime($d . ' 23:59:59')],
                ['status', '=', 1],
            ])->count('log_id');
            $registers[] = UserMain::where([
                ['register_time', '>=', strtotime($d . ' 00:00:00')],
                ['register_time', '<=', strtotime($d . ' 23:59:59')],
                ['status', '=', 1],
            ])->count('uid');
            $days[] = $d;
        }
        return View::assign([
            'count'     => $count,
            'days'      => json_encode($days),
            'logs'      => json_encode($logs),
            'registers' => json_encode($registers),
        ])->fetch();
    }
}

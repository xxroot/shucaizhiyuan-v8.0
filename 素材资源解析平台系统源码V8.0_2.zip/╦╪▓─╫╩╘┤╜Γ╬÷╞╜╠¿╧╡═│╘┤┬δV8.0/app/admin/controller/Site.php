<?php
namespace app\admin\controller;

use app\admin\controller\Base;
use app\common\model\UserSiteAccess;
use app\common\model\WebSite;
use app\common\model\WebSiteCookie;
use think\facade\Request;
use think\facade\Validate;
use think\facade\View;

class Site extends Base
{
    public function index()
    {
        $web_site_list = WebSite::order('site_id', 'desc')->select();
        return View::assign([
            'web_site_list' => $web_site_list,
        ])->fetch();
    }

    public function add_site()
    {
        if (Request::isAjax() && Request::isPost()) {
            $post     = Request::post();
            $validate = Validate::rule([
                'title'       => 'require',
                'url'         => 'require',
                'url_regular' => 'require',
                'demo_url'    => 'require',
            ])->message([
                'title.require'       => '网站名称必填',
                'url.require'         => '官网地址必填',
                'url_regular.require' => '网站特征码必填',
                'demo_url.require'    => '实例地址必填',
            ]);

            if (!$validate->check($post)) {
                return show_error($validate->getError());
            }
            $post['param'] = [];
            WebSite::create($post);
            return show_success('站点添加成功', 'admin/site/index');
        }
        return View::fetch('edit_site');
    }

    public function edit_site($site_id = 0)
    {
        if (!$web_site = WebSite::where('site_id', '=', $site_id)->find()) {
            return show_error('指定素材站点不存在', 'admin/site/index');
        }
        if (Request::isAjax() && Request::isPost()) {
            $post     = Request::post();
            $validate = Validate::rule([
                'title'       => 'require',
                'url'         => 'require',
                'url_regular' => 'require',
                'demo_url'    => 'require',
            ])->message([
                'title.require'       => '网站名称必填',
                'url.require'         => '官网地址必填',
                'url_regular.require' => '网站特征码必填',
                'demo_url.require'    => '实例地址必填',
            ]);

            if (!$validate->check($post)) {
                return show_error($validate->getError());
            }
            $web_site->save($post);
            return show_success('站点添加成功', 'admin/site/index');
        }
        return View::assign([
            'web_site' => $web_site,
        ])->fetch('edit_site');
    }

    public function delete_site($site_id = 0)
    {
        if (!Request::isAjax()) {
            return show_error('请求类型错误');
        }
        $data = WebSite::where('site_id', '=', $site_id)->find();
        if (empty($data)) {
            return show_error('指定数据不存在');
        }
        UserSiteAccess::where('site_id', '=', $data['site_id'])->update();
        WebSiteCookie::where('site_id', '=', $data['site_id'])->delete();
        $data->delete();
        return show_success('数据删除成功', 'admin/site/index');
    }

    public function cookie($site_id = 0)
    {
        if (!$web_site = WebSite::where('site_id', '=', $site_id)->find()) {
            return show_error('站点不存在！', 'admin/site/index');
        }
        $cookie_list = WebSiteCookie::where('site_id', '=', $web_site['site_id'])->order('cookie_id', 'desc')->select();
        return View::assign([
            'web_site'    => $web_site,
            'cookie_list' => $cookie_list,
        ])->fetch();
    }

    public function add_cookie($site_id = 0)
    {
        if (!$web_site = WebSite::where('site_id', '=', $site_id)->find()) {
            return show_error('指定站点不存在', 'admin/site/index');
        }
        if (Request::isAjax() && Request::isPost()) {
            $post     = Request::post();
            $validate = Validate::rule([
                'content' => 'require',
            ])->message([
                'content.require' => 'Cookie内容必填',
            ]);

            if (!$validate->check($post)) {
                return show_error($validate->getError());
            }
            $post['available'] = 1;
            $cookie            = WebSiteCookie::create($post);

            $cookies_count = [
                'available' => WebSiteCookie::where([
                    ['site_id', '=', $web_site['site_id']],
                    ['available', '=', 1],
                ])->count('cookie_id'),
                'all'       => WebSiteCookie::where([
                    ['site_id', '=', $web_site['site_id']],
                ])->count('cookie_id'),
            ];
            $web_site->cookies_count = $cookies_count;
            $web_site->save();
            http_post('cookie', ['cookie' => $cookie->toArray(), 'web_site' => $web_site['url_regular']]);
            return show_success('Cookie保存成功', url('admin/site/cookie', ['site_id' => $web_site['site_id']]));
        }
        return View::assign([
            'web_site' => $web_site,
        ])->fetch('edit_cookie');
    }

    public function edit_cookie($cookie_id = 0)
    {
        if (!$cookie = WebSiteCookie::where('cookie_id', '=', $cookie_id)->find()) {
            return show_error('Cookie不存在！', 'admin/site/index');
        }
        $web_site = WebSite::where('site_id', '=', $cookie['site_id'])->find();
        if (Request::isAjax() && Request::isPost()) {
            $post     = Request::post();
            $validate = Validate::rule([
                'content' => 'require',
            ])->message([
                'content.require' => 'Cookie内容必填',
            ]);

            if (!$validate->check($post)) {
                return show_error($validate->getError());
            }
            $post['available'] = 1;
            $cookie->save($post);
            $cookies_count = [
                'available' => WebSiteCookie::where([
                    ['site_id', '=', $web_site['site_id']],
                    ['available', '=', 1],
                ])->count('cookie_id'),
                'all'       => WebSiteCookie::where([
                    ['site_id', '=', $web_site['site_id']],
                ])->count('cookie_id'),
            ];
            $web_site->cookies_count = $cookies_count;
            $web_site->save();
            http_post('cookie', ['cookie' => $cookie->toArray(), 'web_site' => $web_site['url_regular']]);
            return show_success('Cookie保存成功', url('admin/site/cookie', ['site_id' => $cookie['site_id']]));
        }
        return View::assign([
            'web_site' => $web_site,
            'cookie'   => $cookie,
        ])->fetch('edit_cookie');
    }

    public function delete_cookie($cookie_id = 0)
    {
        if (!Request::isAjax()) {
            return show_error('请求类型错误');
        }
        $data = $cookie = WebSiteCookie::where('cookie_id', '=', $cookie_id)->find();
        if (empty($data)) {
            return show_error('指定数据不存在');
        }
        $web_site = WebSite::where('site_id', '=', $data['site_id'])->find();
        http_post('cookie', ['operate' => 'delete', 'cookie' => $cookie->toArray(), 'web_site' => $web_site['url_regular']]);
        $data->delete();
        $cookies_count = [
            'available' => WebSiteCookie::where([
                ['site_id', '=', $web_site['site_id']],
                ['available', '=', 1],
            ])->count('cookie_id'),
            'all'       => WebSiteCookie::where([
                ['site_id', '=', $web_site['site_id']],
            ])->count('cookie_id'),
        ];
        $web_site->cookies_count = $cookies_count;
        $web_site->save();
        return show_success('数据删除成功', url('admin/site/cookie', ['site_id' => $web_site['site_id'] ?? '']));
    }

    public function cookie_all()
    {
        $cookie_list = WebSiteCookie::order('cookie_id', 'desc')->paginate(30);
        return View::assign([
            'cookie_list' => $cookie_list,
        ])->fetch();
    }
}

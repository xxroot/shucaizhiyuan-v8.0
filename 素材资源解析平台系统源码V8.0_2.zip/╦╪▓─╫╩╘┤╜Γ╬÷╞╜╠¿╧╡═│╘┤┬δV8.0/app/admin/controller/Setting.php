<?php
namespace app\admin\controller;

use app\admin\controller\Base;
use app\common\model\CommonSetting;
use app\common\model\WebSite;
use think\facade\Cache;
use think\facade\Request;
use think\facade\View;

class Setting extends Base
{
    protected function initialize()
    {
        parent::initialize();
        if (Request::isPost() && Request::isAjax()) {
            foreach (Request::post('setting/a') as $key => $value) {
                CommonSetting::where('key', '=', $key)->update(['value' => is_array($value) ? json_encode($value) : $value]);
            }
            Cache::delete('common_setting');
            return show_success('设置保存成功');
        }
    }

    public function index()
    {
        return View::fetch();
    }

    public function account()
    {
        return View::fetch();
    }

    public function email()
    {
        return View::fetch();
    }

    public function storage()
    {
        return View::fetch();
    }

    public function proxy()
    {
        return View::fetch();
    }

    public function payment()
    {
        return View::fetch();
    }

    public function fission()
    {
        $web_site_list = WebSite::order('site_id', 'desc')->select();
        return View::assign([
            'web_site_list' => $web_site_list,
        ])->fetch();
    }
}

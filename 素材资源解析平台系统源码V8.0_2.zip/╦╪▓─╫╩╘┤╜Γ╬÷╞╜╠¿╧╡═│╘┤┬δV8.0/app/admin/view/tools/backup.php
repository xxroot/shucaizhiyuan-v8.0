<div class="alert alert-success">
	请选择需要恢复的数据，在数据恢复过程中请勿关闭浏览器
	<button type="button" class="btn close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">×</span>
	</button>
</div>
<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">备份列表</div>
	<div class="card-body p-0">
		<table class="table nav-cat-table table-striped table-hover mb-0">
			<tr>
				<th width="200">备份时间</th>
				<th>备份名称</th>
				<th width="180">卷数</th>
				<th width="180">大小</th>
				<th width="150">操作</th>
			</tr>
			{if empty($backup_list)}
				<tr>
					<td colspan="5" class="text-center">暂无备份记录</td>
				</tr>
			{else}
				{foreach $backup_list as $key=>$backup}
					<tr>
						<td>{$backup['back_time']}</td>
						<td>{$backup['back_name']}</td>
						<td>{$backup['rolls']}</td>
						<td>{:format_bytes($backup['size'])}</td>
						<td>
							<a href="{:url('admin/tools/restore',['key'=>$key])}">恢复</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/tools/backup_delete',['key'=>$key])}">删除</a>
						</td>
					</tr>
				{/foreach}
			{/if}
		</table>
	</div>
</div>

{if !empty($table)}
	<div class="card">
		<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">数据表名：{$table['table']}</div>
		<div class="card-body p-0">
			<table class="table table-striped table-hover mb-0">
				<thead>
					<tr>
						<th width="150">标识</th>
						<th width="130">类型</th>
						<th width="90">允许Null</th>
						<th width="90">Key</th>
						<th width="150">默认值</th>
						<th width="150">Extra</th>
						<th>备注</th>
					</tr>
				</thead>
				<tbody>
					{volist name="$table['field']" id="field"}
						<tr>
							<td>{$field['Field']}</td>
							<td>{$field['Type']}</td>
							<td>{$field['Null']}</td>
							<td>{$field['Key']}</td>
							<td>
								{if is_null($field['Default'])}
									Null
								{else}
									{$field['Default']}
								{/if}
							</td>
							<td>{$field['Extra']}</td>
							<td>{$field['Comment']}</td>
						</tr>
					{/volist}
				</tbody>
			</table>
		</div>
		<div class="card-footer">
			<a class="btn btn-success" href="{:url('admin/tools/database')}">返回</a>
		</div>
	</div>
{else}
	<form method="post">
		<input type="hidden" name="operation" value="">
		<div class="card">
			<div class="card-header border-bottom-0">全部数据表，共 {:count($table_list)} 张数据表</div>
			<div class="card-body p-0">
				<table class="table table-striped table-hover mb-0">
					<thead>
						<tr>
							<th width="50"></th>
							<th width="250">表名</th>
							<th width="80">类型</th>
							<th width="100">数据量</th>
							<th width="150">占用空间</th>
							<th width="160">更新时间</th>
							<th>备注</th>
						</tr>
					</thead>
					<tbody>
						{volist name="table_list" id="table"}
							<tr>
								<td>
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input" name="tables[]" value="{$table['Name']}" checked>
										<label class="custom-control-label"></label>
									</div>
								</td>
								<td><a href="{:url('admin/tools/database',['table'=>$table['Name']])}">{$table['Name']}</a></td>
								<td>{$table['Engine']}</td>
								<td>{$table['Rows']}</td>
								<td>{:format_bytes($table['Data_length']+$table['Index_length'])}</td>
								<td>{$table['Update_time'] ?: $table['Create_time']}</td>
								<td>{$table['Comment']}</td>
							</tr>
						{/volist}
					</tbody>
				</table>
			</div>
			<div class="card-footer">
				<button type="submit" class="btn btn-success btn-submit">立即备份</button>
				<button type="submit" class="btn btn-primary btn-submit" data-before="database_action" data-operation="optimize">优化选中表</button>
				<button type="submit" class="btn btn-warning btn-submit" data-before="database_action" data-operation="repair">修复选中表</button>
			</div>
		</div>
	</form>
	<script>
		function database_action(form,btn){
			$('input[name="operation"]').val(btn.data('operation'));
			return true;
		}
	</script>
{/if}

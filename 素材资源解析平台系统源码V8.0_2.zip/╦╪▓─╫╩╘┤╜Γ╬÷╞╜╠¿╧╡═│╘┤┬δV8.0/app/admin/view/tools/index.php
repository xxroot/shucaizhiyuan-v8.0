<form method="post">
	<div class="card">
		<div class="card-header">更新缓存</div>
		<div class="card-body">
			<div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" name="cache_clear" value="1" checked>
				<label class="custom-control-label">清除网站所有缓存数据</label>
			</div>
			<div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" name="temp_clear" value="1" checked>
				<label class="custom-control-label">清除模板缓存文件</label>
			</div>
			<div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" name="log_clear" value="1" checked>
				<label class="custom-control-label">清空网站访问日志</label>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success btn-submit">开始</button>
		</div>
	</div>
</form>

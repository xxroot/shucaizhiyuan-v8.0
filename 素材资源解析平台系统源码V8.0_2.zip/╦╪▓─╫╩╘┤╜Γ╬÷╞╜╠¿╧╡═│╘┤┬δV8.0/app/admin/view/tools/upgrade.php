{if $version > $now_version}
	<div class="alert alert-danger">版本更新过程中请勿关闭浏览器，否则可能会丢失数据</div>
{else}
	<div class="alert alert-success">您的程序已是最新版本</div>
{/if}
<div class="card">
	<div class="card-header">
		当前版本：<strong class="text-success px-2">{$now_version}</strong>
		{if $version > $now_version}
			发现最新版：<strong class="text-danger px-2">{$version}</strong>
			{if $ZipArchive}
				<a class="btn btn-small btn-success" href="{:url('admin/tools/start_upgrade',['upgrade_url'=>$upgrade_url])}">更新程序</a>
			{else}
				在线更新需要Zip扩展的支持，系统检测到服务器未安装该拓展，请联系南波湾获取更新文件
			{/if}
		{/if}
	</div>
	<div class="card-body">{$update_log|raw}</div>
	{if $version > $now_version}
		<div class="card-footer">
			{if $ZipArchive}
				<a class="btn btn-success" href="{:url('admin/tools/start_upgrade',['upgrade_url'=>$upgrade_url])}">更新程序</a>
			{else}
				在线更新需要Zip扩展的支持，系统检测到服务器未安装该拓展，请联系南波湾获取更新文件
			{/if}
		</div>
	{/if}
</div>

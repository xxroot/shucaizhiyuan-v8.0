<div class="alert alert-danger">
	错误的SQL语句可能会破坏网站数据，请确保该功能的危险性后再操作
	<button type="button" class="btn close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<form method="post">
	<div class="card">
		<div class="card-header">执行原生数据库语句</div>
		<div class="card-body">
			<div class="form-group">
				<label>SQL语句</label>
				<div class="col-12">
					<textarea class="form-control" name="sql"></textarea>
					<small class="form-text text-muted">请输入原生SQL语句，谨慎使用本功能</small>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-danger">立即执行</button>
		</div>
	</div>
</form>

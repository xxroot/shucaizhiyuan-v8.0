<form method="post" autocomplete="off">
	{if !empty($share)}
		<input type="hidden" name="share_id" value="{$share['share_id']}">
		<input type="hidden" name="attach_id" value="{$share['attach_id']}">
	{/if}
	<input type="hidden" name="cover" value="{$share['cover']??''}">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link disabled" href="#" tabindex="-1">{if empty($share)}新增分享{else}编辑分享{/if}</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#base">基础信息</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#reward">分享奖励</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content p-0">
			<div class="tab-pane p-3 fade show active" id="base">
				<div class="form-group">
					<label class="font-weight-bold">标题</label>
					<input type="text" class="form-control" name="subject" value="{$share['subject']??''}">
				</div>
				<div class="form-group">
					<label class="font-weight-bold">附件来源</label>
					<input type="text" class="form-control" name="from_url" value="{$share['from_url']??''}">
				</div>
				<div class="mb-2 d-flex justify-content-start">
					<button class="btn btn-danger upload-file" type="button">选择附件</button>
					<div class="upload-progress-box w-75 ml-5"></div>
				</div>
				{if !empty($share['attach'])}
					<div class="small mb-3">当前附件保存位置 <strong class="text-danger">{$share['attach']['savename']}</strong></div>
				{/if}
				<div class="mb-2 d-flex justify-content-start">
					<button class="btn btn-info upload-cover" type="button">选择封面</button>
					<div class="upload-progress-box2 w-75 ml-5"></div>
				</div>
				{if !empty($share['cover'])}
					<div class="small mb-3">当前附件保存位置 <strong class="text-info">{$share['cover']}</strong></div>
				{/if}
				<div class="form-group">
					<label class="font-weight-bold">所属来源</label>
					<select class="form-control" name="site_id">
						<option value="">请选择站点</option>
						{foreach $web_site_list as $web_site}
							<option value="{$web_site['site_id']}" {if !empty($share) && $share['attach']['site_id'] == $web_site['site_id']}selected{/if}>{$web_site['title']}</option>
						{/foreach}
					</select>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">来源标识</label>
					<input type="text" class="form-control" name="site_code" value="{$share['attach']['site_code']??''}">
				</div>
				<div class="form-group">
					<label class="font-weight-bold">来源类型</label>
					<input type="text" class="form-control" name="site_code_type" value="{$share['attach']['site_code_type']??''}">
				</div>
				<div class="form-group">
					<label class="font-weight-bold">内容详情</label>
					<div class="editor-box"><textarea class="editor d-none" name="message">{$share['message']??''}</textarea></div>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">状态</label>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="-1" {if !empty($share['status']) && $share['status'] == -1}checked{/if}>
						<label class="custom-control-label">禁用</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="0" {if empty($share['status'])}checked{/if}>
						<label class="custom-control-label">隐藏</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="1" {if !empty($share['status'])}checked{/if}>
						<label class="custom-control-label">显示</label>
					</div>
				</div>
			</div>
			<div class="tab-pane p-3 fade" id="reward">
				<div class="alert alert-danger">奖励一旦设置无法撤销或更改，请谨慎操作</div>
				<div class="form-group">
					<label class="font-weight-bold">奖励余额：</label>
					<input type="text" class="form-control" name="reward[balance]" {if !empty($share['reward'])}readonly{/if} value="{$share['reward']['balance']??0}">
				</div>
				<div class="form-group">
					<label class="font-weight-bold">奖励下载次数：</label>
				</div>
				<table class="table table-hover">
					<tr>
						<th class="text-right">站点</th>
						<th>下载次数</th>
						<th>过期时间(当下载次数大于0时，时间填0表示永不过期，单位小时)</th>
					</tr>
					{foreach $web_site_list as $web_site}
						<tr>
							<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
							<td><input type="number" class="form-control form-control-sm d-inline" {if !empty($share['reward'])}readonly{/if} name="reward[download][{$web_site['site_id']}][times]" placeholder="下载次数数" value="{$share['reward']['download'][$web_site['site_id']]['times']??0}"></td>
							<td><input type="number" class="form-control form-control-sm d-inline" {if !empty($share['reward'])}readonly{/if} name="reward[download][{$web_site['site_id']}][out_time]" placeholder="过期时间" value="{$share['reward']['download'][$web_site['site_id']]['out_time']??0}"></td>
						</tr>
					{/foreach}
				</table>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">提交保存</button>
		</div>
	</div>
</form>
<script type="text/javascript" src="static/js/upload.js"></script>
<script type="text/javascript">
	$('.upload-file').uploadFile({
		'fileLimit':1,
		'container':'.upload-progress-box',
		succeed:function(file,s){
			$('input[name="attach_id"]').val(s.data.attach_id);
		},
		removeFile:function(file){
			$('input[name="attach_id"]').val('0');
		}
	});
	$('.upload-cover').uploadFile({
		'fileLimit':1,
		'container':'.upload-progress-box2',
		succeed:function(file,s){
			console.log(s);
			$('input[name="cover"]').val(s.data.savename);
		},
		removeFile:function(file){
			$('input[name="cover"]').val('');
		}
	});
</script>

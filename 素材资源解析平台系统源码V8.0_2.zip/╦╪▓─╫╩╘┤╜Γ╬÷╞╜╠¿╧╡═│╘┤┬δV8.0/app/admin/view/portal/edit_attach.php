<form method="post" autocomplete="off">
	{if !empty($attach)}
		<input type="hidden" name="attach_id" value="{$attach['attach_id']}">
	{/if}
	<div class="card">
		<div class="card-header">编辑附件信息</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">所属来源</label>
				<select class="form-control" name="site_id">
					<option value="">请选择站点</option>
					{foreach $web_site_list as $web_site}
						<option value="{$web_site['site_id']}" {if !empty($attach) && $attach['site_id'] == $web_site['site_id']}selected{/if}>{$web_site['title']}</option>
					{/foreach}
				</select>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">请求地址</label>
				<input type="text" class="form-control" name="request_url" value="{$attach['request_url']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">下载地址</label>
				<input type="text" class="form-control" name="response_url" value="{$attach['response_url']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">素材标识</label>
				<input type="text" class="form-control" name="site_code" value="{$attach['site_code']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">素材类型</label>
				<input type="text" class="form-control" name="site_code_type" value="{$attach['site_code_type']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">下载文件名</label>
				<input type="text" class="form-control" name="filename" value="{$attach['filename']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">文件大小(字节)</label>
				<input type="text" class="form-control" name="filesize" value="{$attach['filesize']??''}">
			</div>
			<div class="form-group">
				<label class="font-weight-bold">按钮名称</label>
				<input type="text" class="form-control" name="button_name" value="{$attach['button_name']??''}">
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">提交保存</button>
		</div>
	</div>
</form>

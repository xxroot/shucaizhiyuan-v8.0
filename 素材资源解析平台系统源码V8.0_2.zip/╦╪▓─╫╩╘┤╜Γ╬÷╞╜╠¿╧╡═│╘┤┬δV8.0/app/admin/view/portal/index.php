<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		文章管理
		<a class="btn btn-success btn-sm" href="{:url('admin/portal/add_article')}">新增文章</a>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<tr>
					<th width="80">ID</th>
					<th>文章标题</th>
					<th>发布时间</th>
					<th width="80">浏览次数</th>
					<th width="80">状态</th>
					<th width="100"></th>
				</tr>
			</thead>
			<tbody>
				{foreach $article_list as $article}
					<tr>
						<td>{$article['article_id']}</td>
						<td><a href="{:url('index/portal/view',['article_id'=>$article['article_id']])}" target="_blank">{$article['subject']}</a></td>
						<td>{$article['create_time']}</td>
						<td width="80">{$article['views']}</td>
						<td width="80">{$article['status_text']}</td>
						<td width="100">
							<a href="{:url('admin/portal/edit_article',['article_id'=>$article['article_id']])}">编辑</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/portal/delete_article',['article_id'=>$article['article_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if $page}<div class="card-footer">{$page|raw}</div>{/if}
</div>

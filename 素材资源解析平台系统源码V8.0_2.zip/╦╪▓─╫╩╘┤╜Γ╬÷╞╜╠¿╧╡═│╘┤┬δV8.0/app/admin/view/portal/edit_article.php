<form method="post" autocomplete="off">
	{if !empty($article)}
		<input type="hidden" name="article_id" value="{$article['article_id']}">
	{/if}
	<div class="card">
		<div class="card-header">
			{if empty($article)}新增文章{else}编辑文章{/if}
		</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">文章标题</label>
				<input type="text" class="form-control" name="subject" value="{$article['subject']??''}">
				<small class="form-text text-muted">文章的标题，80字以内</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">文章内容</label>
				<div class="editor-box"><textarea class="editor d-none" name="message">{$article['message']??''}</textarea></div>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">状态</label>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="1" {if !empty($article['status'])}checked{/if}>
					<label class="custom-control-label">显示</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="0" {if empty($article['status'])}checked{/if}>
					<label class="custom-control-label">隐藏</label>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">提交保存</button>
		</div>
	</div>
</form>

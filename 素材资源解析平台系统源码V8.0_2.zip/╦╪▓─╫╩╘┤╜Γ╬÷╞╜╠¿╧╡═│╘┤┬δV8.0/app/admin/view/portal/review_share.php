{__NOLAYOUT__}
<form class="modal fade" tabindex="-1" role="dialog" id="reviewModal" action="{:url('admin/portal/review_share',['share_id'=>$share['share_id']])}">
	<input type="hidden" name="review" value="1">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<div class="modal-title">审核分享：<strong class="text-info">{$share['subject']}</strong></div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<p>Modal body text goes here.111111111111</p>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-success ajax-post">保存</button>
				<button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
			</div>
		</div>
	</div>
</form>

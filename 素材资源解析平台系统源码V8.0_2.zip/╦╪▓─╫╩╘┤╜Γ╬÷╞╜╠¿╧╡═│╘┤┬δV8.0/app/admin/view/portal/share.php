<div class="card">
    <div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
        用户分享
    </div>
    <div class="card-body p-0">
        <table class="table table-striped table-hover table-card mb-0">
            <thead>
                <tr>
                    <th scope="col">用户</th>
                    <th scope="col">标题</th>
                    <th scope="col">文件大小</th>
                    <th scope="col">创建时间</th>
                    <th scope="col">状态</th>
                    <th scope="col">操作</th>
                </tr>
            </thead>
            <tbody>
                {volist name="share_list" id="share"}
                    <tr>
                        <td>{$share['user']['username']}</td>
                        <td>{$share['subject']}</td>
                        <td>{:format_bytes($share['attach']['filesize'])}</td>
                        <td>{$share['create_time']}</td>
                        <td>{$share['status_text']}</td>
                        <td>
                            <a href="{:url('admin/portal/edit_share',['share_id'=>$share['share_id']])}">编辑</a>
                            <a class="ajax-link" data-mode="confirm" href="{:url('admin/portal/delete',['share_id'=>$share['share_id']])}">删除</a>
                        </td>
                    </tr>
                {/volist}
            </tbody>
        </table>
    </div>
    {if $page}
        <div class="card-footer">{$page|raw}</div>
    {/if}
</div>
<script type="text/javascript">
    function review_share(obj,s){
        $('#reviewModal').remove();
        $('body').append(s);
        $('#reviewModal').modal('show')
        return false;
    }
</script>

<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link disabled" href="#" tabindex="-1">{if empty($user)}单个新增用户{else}编辑用户{/if}</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#profile">基础信息</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#permission">权限设置</a>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled text-danger edit-all font-weight-bold" href="#" tabindex="-1">批量修改已关闭（按下ALT+B开启）</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content p-0">
			<div class="tab-pane p-3 fade show active" id="profile">
				<div class="form-group">
					<label class="font-weight-bold">用户名</label>
					<input type="text" class="form-control" name="username" value="{$user['username']??''}">
					<small class="form-text text-muted">用户登陆网站时唯一名称</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户类型</label>
					<select class="form-control" name="type">
						<option value="member" {if !empty($user) && $user['type'] == 'member'}selected{/if}>普通会员</option>
						<option value="proxy" {if !empty($user) && $user['type'] == 'proxy'}selected{/if}>代理用户</option>
						<option value="system" {if !empty($user) && $user['type'] == 'system'}selected{/if}>管理员</option>
					</select>
					<small class="form-text text-muted">账户类型</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">登陆密码</label>
					<input type="text" class="form-control" name="password" value="">
					<small class="form-text text-muted">用户登录网站时使用的密码 {if !empty($user)}<strong class="text-danger">不修改请留空</strong>{/if}</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">绑定手机号</label>
					<input type="text" class="form-control" name="mobile" value="{$user['mobile']??''}">
					<small class="form-text text-muted">可用于登陆网站和找回密码，不可重复</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">绑定邮箱</label>
					<input type="email" class="form-control" name="email" value="{$user['email']??''}">
					<small class="form-text text-muted">可用于登陆网站和找回密码，不可重复</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户余额</label>
					<input type="number" class="form-control" name="balance" value="{$user['balance']??''}">
					<small class="form-text text-muted">用户账户余额</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">QQ号码</label>
					<input type="text" class="form-control" name="qq" value="{$user['qq']??''}">
					<small class="form-text text-muted">用户的QQ号</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">微信号</label>
					<input type="text" class="form-control" name="weixin" value="{$user['weixin']??''}">
					<small class="form-text text-muted">用户微信号</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">折扣力度</label>
					<input type="number" class="form-control" name="discount" value="{$user['discount']??'10'}">
					<small class="form-text text-muted">购买套餐时在原价基础上的折扣力度，范围0-10，0表示免费购买，10表示原价。8.5表示原价的8.5折，既：原价X8.5X.01</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大解析次数</label>
					<input type="number" class="form-control" name="parse_max_times" value="{$user['parse_max_times']??'0'}">
					<small class="form-text text-muted">所有站点的解析次数之和大于这个值后将不能解析</small>
				</div>
				<div class="form-group mb-0">
					<label class="font-weight-bold">状态</label>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="-1" {if !empty($user) && $user['status'] == -1}checked{/if}>
						<label class="custom-control-label">禁止访问</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="0" {if !empty($user) && $user['status'] == 0}checked{/if}>
						<label class="custom-control-label">待审核</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="1" {if (!empty($user) && $user['status'] == 1) || empty($user)}checked{/if}>
						<label class="custom-control-label">正常使用</label>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="permission">
				<table class="table table-hover mb-0">
					<thead>
						<tr>
							<th class="border-top-0" width="100">站点名称</th>
							<th class="border-top-0">日解析次数</th>
							<th class="border-top-0">周解析次数</th>
							<th class="border-top-0">月解析次数</th>
							<th class="border-top-0">年解析次数</th>
							<th class="border-top-0">最大解析次数</th>
							<th class="border-top-0">有效期</th>
						</tr>
					</thead>
					<tbody>
						<tr class="text-success text-center">
							<td colspan="7">所有参数中<strong class="px-2 text-danger">-1</strong>表示无权限，<strong class="px-2 text-info">0</strong>表示无限制或永久有效，大于0的整数表示限制条件，<strong class="text-danger">任何一项参数为-1则表示该站点无解析权限</strong></td>
						</tr>
						{foreach $web_site_list as $web_site}
							{php}
								if(request()->action() == 'add_user' || empty($site_access[$web_site['site_id']])){
									$out_time = 0;
								}else{
									if($site_access[$web_site['site_id']]->getData('out_time')>999999999){
										$out_time = $site_access[$web_site['site_id']]['out_time'];
									}else{
										$out_time = $site_access[$web_site['site_id']]->getData('out_time');
									}
								}
							{/php}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="day" name="day_times[{$web_site['site_id']}]" placeholder="日解析次数" value="{$site_access[$web_site['site_id']]['day_times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="week" name="week_times[{$web_site['site_id']}]" placeholder="周解析次数" value="{$site_access[$web_site['site_id']]['week_times']??0}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="month" name="month_times[{$web_site['site_id']}]" placeholder="月解析次数" value="{$site_access[$web_site['site_id']]['month_times']??0}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="year" name="year_times[{$web_site['site_id']}]" placeholder="年解析次数" value="{$site_access[$web_site['site_id']]['year_times']??0}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="max" name="max_times[{$web_site['site_id']}]" placeholder="最大解析次数" value="{$site_access[$web_site['site_id']]['max_times']??0}"></td>
								<td><input type="text" class="form-control form-control-sm d-inlin access-edit" data-type="out" name="out_time[{$web_site['site_id']}]" placeholder="有效期" value="{$out_time}"></td>
							</tr>
						{/foreach}
					</tbody>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">提交保存</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	var editAll = false;
	$(function(){
		$(document)
			.on('keydown',function(e){
				if(e.keyCode == 66 && e.altKey){
					if(editAll == false){
						editAll = true;
						$('.edit-all').addClass('text-success').removeClass('text-danger').html('批量修改已开启（按下ALT+B关闭）');
					}else{
						editAll = false;
						$('.edit-all').addClass('text-danger').removeClass('text-success').html('批量修改已关闭（按下ALT+B启用）');
					}
					return false;
				}
			})
			.on('keyup keypress change keydown','.access-edit',function(){
				if(editAll == true){
					var val = $(this).val();
					var type = $(this).data('type');
					$('.access-edit[data-type="'+type+'"]').val(val);
				}
			})
	})
</script>

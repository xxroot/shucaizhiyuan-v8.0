<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">搜索会员数据</div>
		<div class="card-body">
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">账户类型：</div>
				<select class="custom-select" name="type">
					<option value="">不限</option>
					<option value="system">管理员</option>
					<option value="proxy">代理用户</option>
					<option value="member">普通会员</option>
				</select>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">UID介于：</div>
				<input type="number" class="form-control" name="start_uid" value="">
				<div class="px-3">-</div>
				<input type="number" class="form-control" name="end_uid" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">余额介于：</div>
				<input type="number" class="form-control" name="start_balance" value="">
				<div class="px-3">-</div>
				<input type="number" class="form-control" name="end_balance" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">注册时间介于：</div>
				<input type="text" class="form-control" name="start_register_time" value="">
				<div class="px-3">-</div>
				<input type="text" class="form-control" name="end_register_time" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">已解析次数介于：</div>
				<input type="number" class="form-control" name="start_parse_times" value="">
				<div class="px-3">-</div>
				<input type="number" class="form-control" name="end_parse_times" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">总解析次数介于：</div>
				<input type="number" class="form-control" name="start_parse_max_time" value="">
				<div class="px-3">-</div>
				<input type="number" class="form-control" name="end_parse_max_times" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">用户名：</div>
				<input type="text" class="form-control" name="username" value="" placeholder="支持模糊匹配">
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">QQ号：</div>
				<input type="number" class="form-control" name="qq" value="" placeholder="支持模糊匹配">
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">微信号：</div>
				<input type="text" class="form-control" name="weixin" value="" placeholder="支持模糊匹配">
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">邮箱：</div>
				<input type="email" class="form-control" name="email" value="" placeholder="支持模糊匹配">
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">手机号：</div>
				<input type="number" class="form-control" name="mobile" value="" placeholder="支持模糊匹配">
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success" type="submit">搜索会员</button>
		</div>
	</div>
</form>

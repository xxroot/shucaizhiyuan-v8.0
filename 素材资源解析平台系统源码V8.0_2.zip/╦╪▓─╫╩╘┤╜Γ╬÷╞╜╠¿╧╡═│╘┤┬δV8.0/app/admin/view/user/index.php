<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		<div>总计共有<strong class="text-danger px-2">{$count['all']}</strong>位用户 {if $is_search}有<strong class="text-danger px-2">{$count['search']}</strong>位用户符合搜索条件{/if}</div>
		<div>
			<a class="btn btn-success btn-sm" href="{:url('admin/user/add_user')}">新增用户</a>
			<a class="btn btn-info btn-sm" href="{:url('admin/user/batch_add')}">批量创建</a>
		</div>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<tr>
					<th width="80">UID</th>
					<th>用户名</th>
					<th width="80">账户余额</th>
					<th width="160">最后登录</th>
					<th>角色</th>
					<th width="80">价格折扣</th>
					<th>
						累计解析
						<svg data-toggle="tooltip" data-html="true" data-placement="right" data-title="已解析次数/最大可解析次数" class="text-info iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#icon-bangzhu"></use>
						</svg>
					</th>
					<th>
						站点权限
						<svg data-toggle="tooltip" data-html="true" data-placement="right" data-title="日/周/月/年/最大次数限制" class="text-info iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#icon-bangzhu"></use>
						</svg>
					</th>
					<th width="100"></th>
				</tr>
			</thead>
			<tbody>
				{foreach $user_list as $user}
					<tr>
						<td>{$user['uid']}</td>
						<td>{$user['username']}</td>
						<td>{$user['balance']}</td>
						<td>{$user['last_time']}</td>
						<td>{$user['type_text']}</td>
						<td class="text-danger">{$user['discount']}</td>
						<td>{$user['parse_times']}/{$user['parse_max_times_text']}</td>
						<td class="text-info" data-toggle="tooltip" data-html="true" data-placement="right" data-title="
						{volist name="$user['site_access']" id="site_access"}
						{php}
							if(empty($web_site[$site_access['site_id']]) || $site_access['day_times'] < 0 || $site_access['week_times'] < 0 || $site_access['month_times'] < 0 || $site_access['year_times'] < 0 || $site_access['max_times'] < 0){
								continue;
							}
						{/php}
						{$web_site[$site_access['site_id']]['title']} : &lt;strong class=&quot;text-success&quot;&gt;{$site_access['day_times']}&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;{$site_access['week_times']}&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;{$site_access['month_times']}&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;{$site_access['year_times']}&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;{$site_access['max_times']}&lt;/strong&gt;
						&lt;br&gt;{/volist}
						">查看权限</td>
						<td class="text-right">
							<a href="{:url('admin/user/edit_user',['uid'=>$user['uid']])}">编辑</a>
							{if !in_array($user['uid'], config('app.founder'))}
								<a class="ajax-link" data-mode="confirm" href="{:url('admin/user/delete_user',['uid'=>$user['uid']])}">删除</a>
							{/if}
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if $page}<div class="card-footer">{$page|raw}</div>{/if}
</div>

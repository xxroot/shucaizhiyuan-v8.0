<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link disabled" href="#" tabindex="-1">批量创建用户</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#profile">基础信息</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#permission">权限设置</a>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled text-danger edit-all font-weight-bold" href="#" tabindex="-1">批量修改已关闭（按下ALT+B开启）</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content p-0">
			<div class="tab-pane p-3 fade show active" id="profile">
				<div class="form-group">
					<label class="font-weight-bold">用户名</label>
					<input type="text" class="form-control" name="username">
					<small class="form-text text-muted">"@"代表任意随机英文字符，"#"代表任意随机数字，"*"代表任意英文或数字</small>
					<small class="form-text text-muted">规则样本：<strong class="text-success">@@@@@#####*****</strong></small>
					<small class="form-text text-muted">注意：规则位数过小会造成用户名生成重复概率增大，过多的重复用户名会造成用户名生成终止</small>
					<small class="form-text text-muted">用户名规则中不能带有中文及其他特殊符号</small>
					<small class="form-text text-muted">为了避免用户名重复，随机位数最好不要少于8位</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">登陆密码</label>
					<input type="text" class="form-control" name="password">
					<small class="form-text text-muted">"@"代表任意随机英文字符，"#"代表任意随机数字，"*"代表任意英文或数字</small>
					<small class="form-text text-muted">规则样本：<strong class="text-success">@@@@@#####*****</strong></small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">生成数量</label>
					<input type="text" class="form-control" name="numbers" value="10">
					<small class="form-text text-muted">每次生成数据建议在100以内</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户类型</label>
					<select class="form-control" name="type">
						<option value="member" selected>普通会员</option>
						<option value="proxy">代理用户</option>
						<option value="system">管理员</option>
					</select>
					<small class="form-text text-muted">账户类型</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户余额</label>
					<input type="number" class="form-control" name="balance" value="0">
					<small class="form-text text-muted">用户账户余额</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">折扣力度</label>
					<input type="number" class="form-control" name="discount" value="10">
					<small class="form-text text-muted">购买套餐时在原价基础上的折扣力度，范围0-10，0表示免费购买，10表示原价。8.5表示原价的8.5折，既：原价X8.5X.01</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大解析次数</label>
					<input type="number" class="form-control" name="parse_max_times" value="0">
					<small class="form-text text-muted">所有站点的解析次数之和大于这个值后将不能解析</small>
				</div>
				<div class="form-group mb-0">
					<label class="font-weight-bold">状态</label>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="-1">
						<label class="custom-control-label">禁止访问</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="0">
						<label class="custom-control-label">待审核</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="status" type="radio" class="custom-control-input" value="1" checked>
						<label class="custom-control-label">正常使用</label>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="permission">
				<table class="table table-hover mb-0">
					<thead>
						<tr>
							<th class="border-top-0" width="100">站点名称</th>
							<th class="border-top-0">日解析次数</th>
							<th class="border-top-0">周解析次数</th>
							<th class="border-top-0">月解析次数</th>
							<th class="border-top-0">年解析次数</th>
							<th class="border-top-0">最大解析次数</th>
							<th class="border-top-0">有效期</th>
						</tr>
					</thead>
					<tbody>
						<tr class="text-success text-center">
							<td colspan="7">所有参数中<strong class="px-2 text-danger">-1</strong>表示无权限，<strong class="px-2 text-info">0</strong>表示无限制或永久有效，大于0的整数表示限制条件，<strong class="text-danger">任何一项参数为-1则表示该站点无解析权限</strong></td>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="day" name="day_times[{$web_site['site_id']}]" placeholder="日解析次数" value="-1"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="week" name="week_times[{$web_site['site_id']}]" placeholder="周解析次数" value="0"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="month" name="month_times[{$web_site['site_id']}]" placeholder="月解析次数" value="0"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="year" name="year_times[{$web_site['site_id']}]" placeholder="年解析次数" value="0"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="max" name="max_times[{$web_site['site_id']}]" placeholder="最大解析次数" value="0"></td>
								<td><input type="text" class="form-control form-control-sm d-inline access-edit" data-type="out" name="out_time[{$web_site['site_id']}]" placeholder="有效期" value="0"></td>
							</tr>
						{/foreach}
					</tbody>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">批量生成用户</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	var editAll = false;
	$(function(){
		$(document)
			.on('keydown',function(e){
				if(e.keyCode == 66 && e.altKey){
					if(editAll == false){
						editAll = true;
						$('.edit-all').addClass('text-success').removeClass('text-danger').html('批量修改已开启（按下ALT+B关闭）');
					}else{
						editAll = false;
						$('.edit-all').addClass('text-danger').removeClass('text-success').html('批量修改已关闭（按下ALT+B启用）');
					}
					return false;
				}
			})
			.on('keyup keypress change keydown','.access-edit',function(){
				if(editAll !== true){
					var val = $(this).val();
					var type = $(this).data('type');
					$('.access-edit[data-type="'+type+'"]').val(val);
				}
			})
	})
</script>

<form method="post" autocomplete="off">
	{if !empty($meal)}
		<input type="hidden" name="meal_id" value="{$meal['meal_id']}">
	{/if}
	<div class="card">
		<div class="card-header">
			{if empty($meal)}新增套餐{else}编辑套餐{/if}
		</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">套餐名称</label>
				<input type="text" class="form-control" name="title" value="{$meal['title']??''}">
				<small class="form-text text-muted">用户购买时选项</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">套餐说明</label>
				<textarea class="form-control" name="summary">{$meal['summary']??''}</textarea>
				<small class="form-text text-muted">针对套餐的详细说明</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">售价</label>
				<input type="number" class="form-control" name="price" value="{$meal['price']??''}">
				<small class="form-text text-muted">套餐直销售价，代理用户会在此基础上进行相应的折扣</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">状态</label>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="1" {if empty($meal) || !empty($meal['status'])}checked{/if}>
					<label class="custom-control-label">显示</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="0" {if !empty($meal) && empty($meal['status'])}checked{/if}>
					<label class="custom-control-label">隐藏</label>
				</div>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">类型</label>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="vip" {if !empty($meal['type']) && $meal['type'] == 'vip'}checked{/if}>
					<label class="custom-control-label">账户VIP升级</label>
				</div>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="download" {if empty($meal['type']) || $meal['type'] == 'download'}checked{/if}>
					<label class="custom-control-label">下载次数购买</label>
				</div>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="proxy" {if empty($meal['type']) || $meal['type'] == 'proxy'}checked{/if}>
					<label class="custom-control-label">代理开户套餐</label>
				</div>
				<small class="form-text text-muted">VIP升级套餐是将用户的账户VIP权限永久提升，下载次数套餐购买后在有效时间内均可下载，不受日/月/年下载次数限制</small>
			</div>
			<div class="type-custom type-vip {if empty($meal['type']) || $meal['type'] != 'vip'}d-none{/if}">
				<div class="mx-3 bg-light">
					<table class="table table-hover mb-0">
						<tr>
							<th class="text-center text-success" colspan="7">小于0表示不操作，0表示提升为无限制权限，正数为增加的下载次数</th>
						</tr>
						<tr>
							<th class="text-right">站点</th>
							<th>日解析上限</th>
							<th>周解析上限</th>
							<th>月解析上限</th>
							<th>年解析上限</th>
							<th>最大解析上限</th>
							<th>站点VIP过期时间(单位小时)</th>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][day_times]" value="{$meal['vip_access'][$web_site['site_id']]['day_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][week_times]" value="{$meal['vip_access'][$web_site['site_id']]['week_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][month_times]" value="{$meal['vip_access'][$web_site['site_id']]['month_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][year_times]" value="{$meal['vip_access'][$web_site['site_id']]['year_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][max_times]" value="{$meal['vip_access'][$web_site['site_id']]['max_times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][out_time]" value="{$meal['vip_access'][$web_site['site_id']]['out_time']??-1}"></td>
							</tr>
						{/foreach}
					</table>
				</div>
			</div>
			<div class="type-custom type-download {if empty($meal['type']) || $meal['type'] != 'download'}d-none{/if}">
				<div class="mx-3 bg-light">
					<table class="table table-hover mb-0">
						<tr>
							<th class="text-center text-success" colspan="3">大于0的参数为有效参数</th>
						</tr>
						<tr>
							<th class="text-right">站点</th>
							<th>下载次数</th>
							<th>有效期(单位小时)</th>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="download_times[{$web_site['site_id']}][times]" value="{$meal['download_times'][$web_site['site_id']]['times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline" name="download_times[{$web_site['site_id']}][out_time]" value="{$meal['download_times'][$web_site['site_id']]['out_time']??-1}"></td>
							</tr>
						{/foreach}
					</table>
				</div>
			</div>
			<div class="type-custom type-proxy {if !empty($meal['type']) && $meal['type'] != 'proxy'}d-none{/if}">
				<div class="mx-3 bg-light">
					<table class="table table-hover mb-0">
						<tr>
							<th class="text-center text-success" colspan="7">任何负数参数均指该站点无解析权限，该功能针对代理用户开设账户时可选加入的套餐，用户无法自助购买</th>
						</tr>
						<tr>
							<th class="text-right">站点</th>
							<th>日解析上限</th>
							<th>周解析上限</th>
							<th>月解析上限</th>
							<th>年解析上限</th>
							<th>最大解析上限</th>
							<th>站点VIP过期时间(单位小时)</th>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][day_times]" value="{$meal['proxy_access'][$web_site['site_id']]['day_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][week_times]" value="{$meal['proxy_access'][$web_site['site_id']]['week_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][month_times]" value="{$meal['proxy_access'][$web_site['site_id']]['month_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][year_times]" value="{$meal['proxy_access'][$web_site['site_id']]['year_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][max_times]" value="{$meal['proxy_access'][$web_site['site_id']]['max_times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline" name="proxy_access[{$web_site['site_id']}][out_time]" value="{$meal['proxy_access'][$web_site['site_id']]['out_time']??-1}"></td>
							</tr>
						{/foreach}
					</table>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">提交保存</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	function meal_type(input,data){
		$('.type-custom').addClass('d-none');
		$('.type-'+input.val()).removeClass('d-none')
	}
</script>

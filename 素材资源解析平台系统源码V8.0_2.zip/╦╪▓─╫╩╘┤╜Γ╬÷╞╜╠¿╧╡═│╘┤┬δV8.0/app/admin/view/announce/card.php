<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		<div>账户充值卡</div>
		<div>
			<a class="btn btn-success btn-sm" href="{:url('admin/announce/card_add')}">新增</a>
			<a class="btn btn-danger btn-sm" href="{:url('admin/announce/card_export')}">导出</a>
			<a class="btn btn-info btn-sm" href="{:url('admin/announce/card_search')}">搜索</a>
		</div>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<th>卡号</th>
				<th>类型</th>
				<th>余额</th>
				<th>有效期</th>
				<th>状态</th>
				<th>操作</th>
			</thead>
			<tbody>
				{foreach $card_list as $card}
					<tr class="{if $card['status'] == 1}{if $card['out_time']<=0 || $card['out_time'] > $Request.time}text-success{else}text-info{/if}{elseif $card['status'] == 0}text-danger{/if}">
						<td>{$card['card_id']}</td>
						<td>{$card['type_text']}</td>
						<td>{$card['balance']}</td>
						<td>{$card['out_time_format']}</td>
						<td>
							{if $card['out_time']<=0 || $card['out_time'] > $Request.time}
								{$card['status_text']}
							{else}
								无效
							{/if}
						</td>
						<td>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/announce/card_delete',['card_id'=>$card['card_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if !empty($page)}<div class="card-footer">{$page|raw}</div>{/if}
</div>

<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">创建充值卡</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">卡号规则</label>
				<input type="text" class="form-control" name="card_id">
				<small class="form-text text-muted">"@"代表任意随机英文字符，"#"代表任意随机数字，"*"代表任意英文或数字</small>
				<small class="form-text text-muted">规则样本：<strong class="text-success">@@@@@#####*****</strong></small>
				<small class="form-text text-muted">注意：规则位数过小会造成充值卡生成重复概率增大，过多的重复充值卡会造成充值卡生成终止</small>
				<small class="form-text text-muted">充值卡规则中不能带有中文及其他特殊符号</small>
				<small class="form-text text-muted">为了避免充值卡重复，随机位数最好不要少于8位</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">过期时间</label>
				<input type="text" class="form-control" name="out_time">
				<small class="form-text text-muted">0表示永不过期或填写时间，例如：2019-12-12 23:59:59</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">生成数量</label>
				<input type="text" class="form-control" name="numbers" value="10">
				<small class="form-text text-muted">每次生成数据建议在100以内</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">类型</label>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="balance" checked>
					<label class="custom-control-label">账户余额</label>
				</div>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="vip">
					<label class="custom-control-label">账户VIP升级</label>
				</div>
				<div class="custom-control custom-radio" data-after="meal_type">
					<input name="type" type="radio" class="custom-control-input" value="download">
					<label class="custom-control-label">下载次数购买</label>
				</div>
				<small class="form-text text-muted">VIP升级套餐是将用户的账户VIP权限永久提升，下载次数套餐购买后在有效时间内均可下载，不受日/月/年下载次数限制</small>
			</div>
			<div class="type-custom type-balance">
				<div class="form-group">
					<label class="font-weight-bold">增加的余额</label>
					<input type="text" class="form-control" name="balance" value="0">
					<small class="form-text text-muted">为账户增加的余额</small>
				</div>
			</div>
			<div class="type-custom type-vip d-none">
				<div class="mx-3 bg-light">
					<table class="table table-hover mb-0">
						<tr>
							<th class="text-center text-success" colspan="7">小于0表示不操作，0表示提升为无限制权限，正数为增加的下载次数</th>
						</tr>
						<tr>
							<th class="text-right">站点</th>
							<th>日解析上限</th>
							<th>周解析上限</th>
							<th>月解析上限</th>
							<th>年解析上限</th>
							<th>最大解析上限</th>
							<th>站点VIP过期时间(单位小时)</th>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][day_times]" value="{$meal['vip_access'][$web_site['site_id']]['day_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][week_times]" value="{$meal['vip_access'][$web_site['site_id']]['week_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][month_times]" value="{$meal['vip_access'][$web_site['site_id']]['month_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][year_times]" value="{$meal['vip_access'][$web_site['site_id']]['year_times']??-1}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][max_times]" value="{$meal['vip_access'][$web_site['site_id']]['max_times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline" name="vip_access[{$web_site['site_id']}][out_time]" value="{$meal['vip_access'][$web_site['site_id']]['out_time']??-1}"></td>
							</tr>
						{/foreach}
					</table>
				</div>
			</div>
			<div class="type-custom type-download {if empty($meal['type']) || $meal['type'] != 'download'}d-none{/if}">
				<div class="mx-3 bg-light">
					<table class="table table-hover mb-0">
						<tr>
							<th class="text-center text-success" colspan="3">大于0的参数为有效参数</th>
						</tr>
						<tr>
							<th class="text-right">站点</th>
							<th>下载次数</th>
							<th>有效期(单位小时)</th>
						</tr>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="download_times[{$web_site['site_id']}][times]" value="{$meal['download_times'][$web_site['site_id']]['times']??-1}"></td>
								<td><input type="text" class="form-control form-control-sm d-inline" name="download_times[{$web_site['site_id']}][out_time]" value="{$meal['download_times'][$web_site['site_id']]['out_time']??-1}"></td>
							</tr>
						{/foreach}
					</table>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success ajax-post" type="submit">生成充值卡</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	function meal_type(input,data){
		$('.type-custom').addClass('d-none');
		$('.type-'+input.val()).removeClass('d-none')
	}
</script>

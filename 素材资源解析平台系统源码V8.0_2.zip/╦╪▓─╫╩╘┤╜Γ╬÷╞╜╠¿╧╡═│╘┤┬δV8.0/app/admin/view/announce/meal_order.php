<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">套餐订单</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<th width="320">流水号</th>
				<th>套餐名称</th>
				<th>操作用户</th>
				<th>提交时间</th>
				<th>充值金额</th>
				<th>付款方式</th>
				<th width="90"></th>
			</thead>
			<tbody>
				{foreach $order_list as $order}
					<tr class="{$order['text_color']}">
						<td>[{$order['status_text']}] {$order['order_id']}</td>
						<td>[{$order['type_text']}] {$order['title']}</td>
						<td>{$order['user']['username']}</td>
						<td>{$order['create_time']}</td>
						<td class="font-weight-bold">{$order['price']}</td>
						<td>{$order['pay_type']}</td>
						<td>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/announce/meal_order_delete',['order_id'=>$order['order_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if !empty($page)}<div class="card-footer">{$page|raw}</div>{/if}
</div>

<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">用户充值</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<th width="320">流水号</th>
				<th>操作用户</th>
				<th>提交时间</th>
				<th>充值金额</th>
				<th>付款方式</th>
				<th width="90"></th>
			</thead>
			<tbody>
				{foreach $recharge_list as $recharge}
					<tr class="{$recharge['text_color']}">
						<td>[{$recharge['status_text']}] {$recharge['recharge_id']}</td>
						<td>{$recharge['user']['username']}</td>
						<td>{$recharge['create_time']}</td>
						<td class="font-weight-bold">{$recharge['price']}</td>
						<td>{$recharge['pay_type']}</td>
						<td>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/announce/recharge_delete',['recharge_id'=>$recharge['recharge_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if !empty($page)}<div class="card-footer">{$page|raw}</div>{/if}
</div>

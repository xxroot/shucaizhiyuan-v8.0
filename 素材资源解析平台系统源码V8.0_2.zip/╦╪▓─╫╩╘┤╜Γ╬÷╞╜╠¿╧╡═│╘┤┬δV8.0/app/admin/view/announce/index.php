<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		<div>直销套餐</div>
		<div>
			<a class="btn btn-success btn-sm" href="{:url('admin/announce/add_meal')}">新增套餐</a>
		</div>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<th>套餐名称</th>
				<th>类型</th>
				<th>价格</th>
				<th>状态</th>
				<th>操作</th>
			</thead>
			<tbody>
				{foreach $meal_list as $meal}
					<tr>
						<td>{$meal['title']}</td>
						<td>{$meal['type_text']}</td>
						<td>{$meal['price']}</td>
						<td>{$meal['status_text']}</td>
						<td>
							<a href="{:url('admin/announce/edit_meal',['meal_id'=>$meal['meal_id']])}">编辑</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/announce/delete_meal',['meal_id'=>$meal['meal_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
	{if !empty($page)}<div class="card-footer">{$page|raw}</div>{/if}
</div>

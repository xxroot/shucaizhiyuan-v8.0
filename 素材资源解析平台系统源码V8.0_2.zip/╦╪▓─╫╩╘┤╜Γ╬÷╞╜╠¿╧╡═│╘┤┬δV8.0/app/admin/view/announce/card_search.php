<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">搜索充值卡</div>
		<div class="card-body">
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">卡密类型：</div>
				<select class="custom-select" name="type">
					<option value="">不限</option>
					<option value="balance">余额充值</option>
					<option value="vip">VIP升级</option>
					<option value="download">下载次数</option>
				</select>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">卡密状态：</div>
				<select class="custom-select" name="status">
					<option value="">不限</option>
					<option value="-1">已过期</option>
					<option value="0">已使用</option>
					<option value="1">未使用</option>
				</select>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">生成时间介于：</div>
				<input type="text" class="form-control" name="start_create_time" value="">
				<div class="px-3">-</div>
				<input type="text" class="form-control" name="end_create_time" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">过期时间介于：</div>
				<input type="number" class="form-control" name="start_out_time" value="">
				<div class="px-3">-</div>
				<input type="number" class="form-control" name="end_out_time" value="">
				<div class="pl-3">之间</div>
			</div>
			<div class="form-inline mb-3">
				<div class="" style="min-width:150px;text-align:right">卡号：</div>
				<input type="text" class="form-control" name="card_id" value="" placeholder="支持模糊匹配">
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-success" type="submit">搜索</button>
		</div>
	</div>
</form>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="{:request()->setting['version']}">
	<title>管理中心</title>
	<base href="{:request()->domain()}">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

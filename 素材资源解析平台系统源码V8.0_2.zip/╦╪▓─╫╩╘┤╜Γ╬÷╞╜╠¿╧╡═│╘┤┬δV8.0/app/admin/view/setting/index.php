<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">基础设置</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">站点名称</label>
				<input type="text" class="form-control" name="setting[site_name]" value="{$_G['setting']['site_name']}">
				<small class="form-text text-muted">显示在浏览器标题栏，用户收藏时默认名称</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">客服QQ</label>
				<input type="text" class="form-control" name="setting[site_qq]" value="{$_G['setting']['site_qq']}">
				<small class="form-text text-muted">客服QQ，显示在前台方便客户联系</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">解析间隔时间</label>
				<input type="text" class="form-control" name="setting[parse_space_time]" value="{$_G['setting']['parse_space_time']}">
				<small class="form-text text-muted">两次解析间隔时间，合理设置时间有效防止用户频繁解析</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">素材搜索</label>
				<div class="custom-control custom-radio">
					<input name="setting[search_resources]" type="radio" class="custom-control-input" value="0" {if empty($_G['setting']['search_resources'])}checked{/if}>
					<label class="custom-control-label">关闭搜索</label>
				</div>
				<div class="custom-control custom-radio" data-after="search_resources">
					<input name="setting[search_resources]" type="radio" class="custom-control-input" value="1" {if !empty($_G['setting']['search_resources'])}checked{/if}>
					<label class="custom-control-label">启用搜索</label>
				</div>
				<small class="form-text text-muted">启用后可搜索全网素材</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">关闭站点</label>
				<div class="custom-control custom-radio" data-after="site_close">
					<input name="setting[site_close]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['site_close']}checked{/if}>
					<label class="custom-control-label">启用站点</label>
				</div>
				<div class="custom-control custom-radio" data-after="site_close">
					<input name="setting[site_close]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['site_close']}checked{/if}>
					<label class="custom-control-label">关闭站点</label>
				</div>
				<small class="form-text text-muted">关闭站点后非管理员无法登录网站</small>
			</div>
			<div class="form-group site_close {if !$_G['setting']['site_close']}d-none{/if}">
				<label class="font-weight-bold">站点关闭提示信息</label>
				<div class="editor-box"><textarea class="editor d-none" name="setting[site_close_tip]">{$_G['setting']['site_close_tip']}</textarea></div>
				<small class="form-text text-muted">站点关闭后给用户的提示信息</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

<script type="text/javascript">
	function site_close(input,data){
		$('.site_close').addClass('d-none');
		if(input.val() == 1){
			$('.site_close').removeClass('d-none');
		}
	}
</script>

<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">注册与访问</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">自助注册帐号</label>
				<div class="custom-control custom-radio">
					<input name="setting[allow_register]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['allow_register']}checked{/if}>
					<label class="custom-control-label">允许注册</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="setting[allow_register]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['allow_register']}checked{/if}>
					<label class="custom-control-label">禁止注册</label>
				</div>
				<small class="form-text text-muted">是否允许用户在前台自助注册帐号</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">强制用户登录</label>
				<div class="custom-control custom-radio">
					<input name="setting[must_login]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['must_login']}checked{/if}>
					<label class="custom-control-label">启用强制登录</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="setting[must_login]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['must_login']}checked{/if}>
					<label class="custom-control-label">禁用强制登录</label>
				</div>
				<small class="form-text text-muted">启用强制登陆后，用户必须要登陆后才能进入网站</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">是否审核新用户</label>
				<div class="custom-control custom-radio">
					<input name="setting[register_review]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['register_review']}checked{/if}>
					<label class="custom-control-label">审核新用户</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="setting[register_review]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['register_review']}checked{/if}>
					<label class="custom-control-label">无需审核</label>
				</div>
				<small class="form-text text-muted">用户前台自助注册是否需要审核</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">是否允许同时在线</label>
				<div class="custom-control custom-radio">
					<input name="setting[allow_same_login]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['allow_same_login']}checked{/if}>
					<label class="custom-control-label">允许同时在线</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="setting[allow_same_login]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['allow_same_login']}checked{/if}>
					<label class="custom-control-label">禁止同时在线</label>
				</div>
				<small class="form-text text-muted">是否允许用户在不同地方登陆账号</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

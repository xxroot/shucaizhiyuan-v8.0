<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">邮箱设置</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">验证码有效期</label>
				<input type="text" class="form-control" name="setting[verify_code_time]" value="{$_G['setting']['verify_code_time']}">
				<small class="form-text text-muted">单位：分钟</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件HOST</label>
				<input type="text" class="form-control" name="setting[email_host]" value="{$_G['setting']['email_host']}">
				<small class="form-text text-muted">邮件发送服务器HOST，QQ邮箱为：smtp.qq.com，腾讯企业邮箱：smtp.exmail.qq.com</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件发送端口</label>
				<input type="text" class="form-control" name="setting[email_port]" value="{$_G['setting']['email_port']}">
				<small class="form-text text-muted">一般为25或465</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮箱用户名</label>
				<input type="text" class="form-control" name="setting[email_username]" value="{$_G['setting']['email_username']}">
				<small class="form-text text-muted">登陆邮箱的用户名，例如：12345678@qq.com</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮箱授权码</label>
				<input type="text" class="form-control" name="setting[email_password]" value="{$_G['setting']['email_password']}">
				<small class="form-text text-muted">企业邮箱请填写邮箱密码，个人邮箱<a class="pl-1 text-success" href="https://service.mail.qq.com/cgi-bin/help?subtype=1&&no=1001256&&id=28" target="_blank">点击这里查看如何获取授权码</a></small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件来源名称</label>
				<input type="text" class="form-control" name="setting[email_fromname]" value="{$_G['setting']['email_fromname']}">
				<small class="form-text text-muted">可填写站点名称</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件自助注册</label>
				<div class="custom-control custom-radio" data-after="email_register">
					<input name="setting[email_register]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['email_register']}checked{/if}>
					<label class="custom-control-label">启用邮箱自助注册帐号</label>
				</div>
				<div class="custom-control custom-radio" data-after="email_register">
					<input name="setting[email_register]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['email_register']}checked{/if}>
					<label class="custom-control-label">禁用邮箱自助注册帐号</label>
				</div>
				<small class="form-text text-muted">启用后前台用户需通过邮箱才能自助注册帐号</small>
			</div>
			<div class="form-group email_register_content {if !$_G['setting']['email_register']}d-none{/if}">
				<label class="font-weight-bold">自助注册帐号邮件内容</label>
				<div class="editor-box"><textarea class="editor d-none" name="setting[email_register_content]">{$_G['setting']['email_register_content']}</textarea></div>
				<small class="form-text text-muted">用户注册时收到的邮件内容，内容中必须包含<strong class="px-2 text-success">[REGISTER_CODE]</strong>代码，该代码会被替换成验证码（不限次数）</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件找回密码</label>
				<div class="custom-control custom-radio" data-after="email_reset_password">
					<input name="setting[email_reset_password]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['email_reset_password']}checked{/if}>
					<label class="custom-control-label">启用邮件找回密码</label>
				</div>
				<div class="custom-control custom-radio" data-after="email_reset_password">
					<input name="setting[email_reset_password]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['email_reset_password']}checked{/if}>
					<label class="custom-control-label">禁用邮件找回密码</label>
				</div>
				<small class="form-text text-muted">启用后用户可通过邮件自助重置密码（仅针对已绑定邮箱的用户）</small>
			</div>
			<div class="form-group email_reset_content {if !$_G['setting']['email_reset_password']}d-none{/if}">
				<label class="font-weight-bold">密码重置邮件内容</label>
				<div class="editor-box"><textarea class="editor d-none" name="setting[email_reset_content]">{$_G['setting']['email_reset_content']}</textarea></div>
				<small class="form-text text-muted">用户自助找回密码时收到的邮件内容，内容中必须包含<strong class="px-2 text-success">[RESET_CODE]</strong>代码，该代码会被替换成验证码（不限次数）</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	function email_register(input,data){
		$('.email_register_content').addClass('d-none');
		if(input.val() == 1){
			$('.email_register_content').removeClass('d-none');
		}
	}
	function email_reset_password(input,data){
		$('.email_reset_content').addClass('d-none');
		if(input.val() == 1){
			$('.email_reset_content').removeClass('d-none');
		}
	}
</script>

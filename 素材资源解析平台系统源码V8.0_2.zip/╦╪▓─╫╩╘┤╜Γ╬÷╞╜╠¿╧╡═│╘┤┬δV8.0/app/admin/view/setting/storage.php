<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">存储设置</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">AccessKeyId</label>
				<input type="text" class="form-control" name="setting[AccessKeyId]" value="{$_G['setting']['AccessKeyId']}">
				<small class="form-text text-muted">此参数为阿里云OSS存储服务接口参数，<a class="px-1 text-success" href="https://usercenter.console.aliyun.com" target="_blank">获取该参数</a></small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">AccessKeySecret</label>
				<input type="text" class="form-control" name="setting[AccessKeySecret]" value="{$_G['setting']['AccessKeySecret']}">
				<small class="form-text text-muted">此参数为阿里云OSS存储服务接口参数，<a class="px-1 text-success" href="https://usercenter.console.aliyun.com" target="_blank">获取该参数</a></small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">Bucket</label>
				<input type="text" class="form-control" name="setting[Bucket]" value="{$_G['setting']['Bucket']}">
				<small class="form-text text-muted">此参数为阿里云OSS存储服务接口参数，<a class="px-1 text-success" href="https://oss.console.aliyun.com" target="_blank">获取该参数</a></small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">Endpoint</label>
				<input type="text" class="form-control" name="setting[Endpoint]" value="{$_G['setting']['Endpoint']}">
				<small class="form-text text-muted">此参数为阿里云OSS存储服务接口参数，<a class="px-1 text-success" href="https://oss.console.aliyun.com" target="_blank">获取该参数</a>请注意该参数需与上面的BUCKET相对应</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">解析附件自动存储</label>
				<select class="custom-select d-block w-100" name="setting[auto_save_type]">
					<option value="" {if !$_G['setting']['auto_save_type']}selected{/if}>不自动存储附件</option>
					<option value="local" {if $_G['setting']['auto_save_type'] == 'local'}selected{/if}>将附件自动存储到服务器</option>
					<option value="oss" {if $_G['setting']['auto_save_type'] == 'oss'}selected{/if}>将附件自动存储到OSS</option>
					<option value="local_oss" {if $_G['setting']['auto_save_type'] == 'local_oss'}selected{/if}>将附件自动存储到本地和OSS</option>
				</select>
				<small class="form-text text-muted">如果要将附件存储到OSS需要配置上面四项参数</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#alipay">支付宝</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#wxpay">微信支付</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#qqpay">QQ支付</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#other">其他配置</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content">
			<div class="tab-pane fade show active" id="alipay">
				<div class="form-group">
					<label class="font-weight-bold">启用支付宝</label>
					<div class="custom-control custom-radio">
						<input name="setting[alipay_switch]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['alipay_switch']}checked{/if}>
						<label class="custom-control-label">启用支付宝支付</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="setting[alipay_switch]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['alipay_switch']}checked{/if}>
						<label class="custom-control-label">禁用支付宝支付</label>
					</div>
					<small class="form-text text-muted">禁用后用户无法通过支付宝方式付款</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">支付宝APPID</label>
					<input type="text" class="form-control" name="setting[alipay_app_id]" value="{$_G['setting']['alipay_app_id']}">
					<small class="form-text text-muted">企业支付宝APPID</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">商户私钥</label>
					<textarea class="form-control" name="setting[alipay_merchant_private_key]">{$_G['setting']['alipay_merchant_private_key']}</textarea>
					<small class="form-text text-muted">由商户自行生成的私钥</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">支付宝公钥</label>
					<textarea class="form-control" name="setting[alipay_alipay_public_key]">{$_G['setting']['alipay_alipay_public_key']}</textarea>
					<small class="form-text text-muted">支付宝公钥</small>
				</div>
			</div>
			<div class="tab-pane fade" id="wxpay">
				<div class="form-group">
					<label class="font-weight-bold">启用微信支付</label>
					<div class="custom-control custom-radio">
						<input name="setting[wxpay_switch]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['wxpay_switch']}checked{/if}>
						<label class="custom-control-label">启用微信支付</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="setting[wxpay_switch]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['wxpay_switch']}checked{/if}>
						<label class="custom-control-label">禁用微信支付</label>
					</div>
					<small class="form-text text-muted">禁用后用户无法通过微信支付方式付款</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">微信公众号APPID</label>
					<input type="text" class="form-control" name="setting[wxpay_app_id]" value="{$_G['setting']['wxpay_app_id']}">
					<small class="form-text text-muted">关联微信支付的公众号APPID</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">微信商户ID</label>
					<input type="text" class="form-control" name="setting[wxpay_merchant_id]" value="{$_G['setting']['wxpay_merchant_id']}">
					<small class="form-text text-muted">开通微信商户支付时收到的商户ID号</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">商户自定义KEY</label>
					<input type="text" class="form-control" name="setting[wxpay_key]" value="{$_G['setting']['wxpay_key']}">
					<small class="form-text text-muted">微信支付商户平台自定义32位KEY</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">微信公众号SECRET</label>
					<input type="text" class="form-control" name="setting[wxpay_app_secret]" value="{$_G['setting']['wxpay_app_secret']}">
					<small class="form-text text-muted">公众号中的APP_SECRET</small>
				</div>
			</div>
			<div class="tab-pane fade" id="qqpay">
				<div class="form-group">
					<label class="font-weight-bold">启用QQ支付</label>
					<div class="custom-control custom-radio">
						<input name="setting[qqpay_switch]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['qqpay_switch']}checked{/if}>
						<label class="custom-control-label">启用QQ支付</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="setting[qqpay_switch]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['qqpay_switch']}checked{/if}>
						<label class="custom-control-label">禁用QQ支付</label>
					</div>
					<small class="form-text text-muted">禁用后用户无法通过QQ支付方式付款</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">QQ商户ID</label>
					<input type="text" class="form-control" name="setting[qqpay_mch_id]" value="{$_G['setting']['qqpay_mch_id']}">
					<small class="form-text text-muted">开通QQ商户平台时收到的商户ID</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">QQ支付自定义KEY</label>
					<input type="text" class="form-control" name="setting[qqpay_key]" value="{$_G['setting']['qqpay_key']}">
					<small class="form-text text-muted">QQ商户平台中自定义32位自定义KEY</small>
				</div>
			</div>
			<div class="tab-pane fade" id="other">
				<div class="form-group">
					<label class="font-weight-bold">最低充值</label>
					<input type="text" class="form-control" name="setting[min_recharge_price]" value="{$_G['setting']['min_recharge_price']}">
					<small class="form-text text-muted">单次充值最低充值金额</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最高充值</label>
					<input type="text" class="form-control" name="setting[max_recharge_price]" value="{$_G['setting']['max_recharge_price']}">
					<small class="form-text text-muted">单次充值最高充值金额</small>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

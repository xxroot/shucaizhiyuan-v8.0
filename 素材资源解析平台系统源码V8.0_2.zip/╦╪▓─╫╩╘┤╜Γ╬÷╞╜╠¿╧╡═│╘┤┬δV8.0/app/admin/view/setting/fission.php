<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#setting">裂变设置</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#reward">推广奖励</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content p-0">
			<div class="tab-pane fade p-3 show active" id="setting">
				<div class="form-group">
					<label class="font-weight-bold">裂变推广</label>
					<div class="custom-control custom-radio">
						<input name="setting[user_fission]" type="radio" class="custom-control-input" value="1" {if $_G['setting']['user_fission']}checked{/if}>
						<label class="custom-control-label">启用裂变推广</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="setting[user_fission]" type="radio" class="custom-control-input" value="0" {if !$_G['setting']['user_fission']}checked{/if}>
						<label class="custom-control-label">禁用裂变推广</label>
					</div>
					<small class="form-text text-muted">启用裂变推广后用户将拥有唯一推广链接地址，通过该推广地址注册的会员将会成为其下属会员</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">裂变推广链接时效</label>
					<input type="number" class="form-control" name="setting[user_fission_time]" value="{$_G['setting']['user_fission_time']}">
					<small class="form-text text-muted">新用户访问推广链接多长时间内注册有效成为推广者下属会员，单位：小时</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大裂变级数</label>
					<input type="number" class="form-control" name="setting[user_fission_lv]" value="{$_G['setting']['user_fission_lv']}">
					<small class="form-text text-muted">用户最大裂变等级数，-1为关闭裂变，0为不限制，不建议开启无限制级数裂变，且裂变级数需大于奖励层级数</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大奖励层级</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_lv]" value="{$_G['setting']['user_fission_reward_lv']}">
					<small class="form-text text-muted">裂变推广注册的会员会无限向上级会员赠送下面设置的解析次数</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">单日内最大奖励次数</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_day_times]" value="{$_G['setting']['user_fission_reward_day_times']}">
					<small class="form-text text-muted">同一用户通过推广单日内获得最大奖励次数，0为不限制，任何负数表示禁止</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户最大奖励次数</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_max_times]" value="{$_G['setting']['user_fission_reward_max_times']}">
					<small class="form-text text-muted">同一用户通过推广可获得最大的奖励次数，0为不限制，任何负数表示禁止</small>
				</div>
			</div>
			<div class="tab-pane fade" id="reward">
				<table class="table table-hover mb-0">
					<thead>
						<tr>
							<th class="border-top-0" width="100">站点名称</th>
							<th class="border-top-0">奖励解析次数</th>
							<th class="border-top-0">有效期(小时/0-无限)</th>
						</tr>
					</thead>
					<tbody>
						{foreach $web_site_list as $web_site}
							<tr>
								<td><div class="mt-1 text-right">{$web_site['title']}</div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="setting[user_fission_reward][times][{$web_site['site_id']}]" value="{$_G['setting']['user_fission_reward']['times'][$web_site['site_id']]??0}"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="setting[user_fission_reward][out_time][{$web_site['site_id']}]" value="{$_G['setting']['user_fission_reward']['out_time'][$web_site['site_id']]??0}"></td>
							</tr>
						{/foreach}
					</tbody>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

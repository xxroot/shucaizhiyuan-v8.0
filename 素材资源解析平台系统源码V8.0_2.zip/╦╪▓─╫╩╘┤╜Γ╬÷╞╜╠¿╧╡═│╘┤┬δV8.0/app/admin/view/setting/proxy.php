<form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">代理设置</div>
		<div class="card-body">
			<div class="form-group">
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>

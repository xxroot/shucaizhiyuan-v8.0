{include file="admin@common/header"}
<body>
    <style type="text/css">html,body {height: 100%;}</style>
    <div class="d-flex justify-content-center d-flex align-items-center h-100 w-100">
        <form autocomplete="off" class="card" style="width: 400px;">
            <h5 class="card-header text-center">管理员登陆</h5>
            <div class="card-body">
                <div class="form-group">
                    <input type="text" class="form-control" name="account" placeholder="会员账号" required autofocus>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" placeholder="登陆密码" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text p-0"><img class="captcha" src="{:url('index/captcha/index')}" style="height: 36px;cursor: pointer;"></span>
                    </div>
                    <input type="text" class="form-control" name="verify_code">
                </div>
                <button class="btn btn-success btn-block ajax-post" type="submit">登 录</button>
            </div>
			<div>&#26356;&#22810;&#20146;&#27979;&#28304;&#30721;&#35831;&#21040;&#22244;&#20027;&#39064;&#119;&#119;&#119;&#46;&#116;&#122;&#104;&#117;&#116;&#105;&#46;&#99;&#111;&#109;
</div>

        </form>
    </div>
</body>
{include file="admin@common/footer"}

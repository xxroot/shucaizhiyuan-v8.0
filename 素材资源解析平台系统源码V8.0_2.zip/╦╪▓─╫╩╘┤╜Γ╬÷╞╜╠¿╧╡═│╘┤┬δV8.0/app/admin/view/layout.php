{include file="admin@common/header"}
<body>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<nav class="d-flex justify-content-between fixed-top admin-top bg-white">
		<div class="d-flex justify-content-start pl-3">
			{foreach $_G['admin_menu'] as $controller => $menu}
				<a class="px-3 {if $controller === $Request.controller}active{/if}" href="{:url(!empty($menu['url']) ? $menu['url'] : ($menu['sub_menu'][0]['url']??'#'))}">
					{if !empty($menu['icon'])}
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#{$menu['icon']}"></use>
						</svg>
					{/if}
					{$menu['name']}
				</a>
			{/foreach}
		</div>
		<div class="d-flex justify-content-end align-items-center pr-3">
			<a class="px-3" href="{:url('index/index/index')}" target="_blank">前台</a>
			<div class="px-3">欢迎您，{$_G['user']['username']}</div>
			<a class="px-3" href="{:url('admin/account/logout')}">
				<svg class="iconfont" aria-hidden="true">
				    <use xlink:href="#icon-logout"></use>
				</svg>
				退出
			</a>
		</div>
	</nav>
	<div class="left-bar">
		<h5>管理中心</h5>
		<div class="left-nav">
			{foreach $_G['admin_menu'][$Request.controller]['sub_menu'] as $sub_menu}
				<a class="{if in_array($Request.action,$sub_menu['active_list'])}active{/if}" href="{:url($sub_menu['url'])}" {notempty name="sub_menu.target"}target="{$sub_menu['target']}"{/notempty}>
					{if !empty($sub_menu['icon'])}
						<svg class="iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#{$sub_menu['icon']}"></use>
						</svg>
					{/if}
					{$sub_menu['name']}
				</a>
			{/foreach}
			<a class="text-warning d-none new-version-nav" href="{:url('admin/tools/upgrade')}">
				<svg class="iconfont mr-2" aria-hidden="true">
				    <use xlink:href="#icon-nav"></use>
				</svg>
				发现新版本
			</a>
		</div>
	</div>
	<div class="admin-content p-3">{__CONTENT__}</div>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'{:url('admin/tools/check_new_version')}',
				success:function(s){
					if(s.code == 1){
						$('.new-version-nav').removeClass('d-none');
						{if empty(cookie('new_version_tip'))}
							dialog.open({
								type: 1,
								anim: 2,
								shadeClose: false,
								content: '<div class="p-3">发现程序新版本，请及时更新程序确保解析功能正常<br>新版本号：<strong class="text-danger">'+s.data.new_version+'</strong><br><a href="{:url('admin/tools/upgrade')}">前往升级</a></div>'
							});
							{php}cookie('new_version_tip',1,86400);{/php}
						{/if}
					}
				}
			})
			$.ajax({
				url:'{:url('index/job/index')}',
				success:function(s){
					console.log(s);
				}
			})
		})
	</script>
</body>
{include file="admin@common/footer"}

<form method="post" autocomplete="off">
	<input type="hidden" name="site_id" value="{$web_site['site_id']??0}">
	<div class="card">
		<div class="card-header">
			{if empty($rule)}为{$web_site['title']}站点新增COOKIE{else}编辑COOKIE{/if}
		</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">Cookie名称</label>
				<input type="text" class="form-control" name="title" value="{$cookie['title']??''}">
				<small class="form-text text-muted">仅方便管理记录</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">Cookie内容</label>
				<textarea class="form-control" name="content">{$cookie['content']??''}</textarea>
				<small class="form-text text-muted">Cookie详细内容，只有正确的Cookie才能获取素材下载地址</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">日最大使用次数</label>
				<input type="text" class="form-control" name="day_max" value="{$cookie['day_max']??'0'}">
				<small class="form-text text-muted">每日可调用的最大次数{if !empty($cookie)}<strong class="text-danger">今日已使用 {$cookie['day_used']} 次</strong>{/if}</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">总使用次数</label>
				<input type="text" class="form-control" name="all_max" value="{$cookie['all_max']??'0'}">
				<small class="form-text text-muted">可调用的最大总次数{if !empty($cookie)}<strong class="text-danger">总计已使用 {$cookie['all_used']} 次</strong>{/if}</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">状态</label>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="1" {if !empty($cookie['status'])}checked{/if}>
					<label class="custom-control-label">启用</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="0" {if empty($cookie['status'])}checked{/if}>
					<label class="custom-control-label">禁用</label>
				</div>
				<small class="form-text text-muted">禁用后无法调用该Cookie</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">提交保存</button>
		</div>
	</div>
</form>

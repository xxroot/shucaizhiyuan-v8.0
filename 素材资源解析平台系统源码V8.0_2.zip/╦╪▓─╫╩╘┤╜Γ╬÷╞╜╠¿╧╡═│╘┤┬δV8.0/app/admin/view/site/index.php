<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		<div>素材站点列表</div>
		<div>
			<a class="btn btn-success btn-sm" href="{:url('admin/site/add_site')}">新增站点</a>
		</div>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<tr>
					<th>站点名称</th>
					<th>官网地址</th>
					<th>特征码</th>
					<th data-toggle="tooltip" data-html="true" data-title="可用/总数">COOKIE状态</th>
					<th>状态</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				{foreach $web_site_list as $web_site}
					<tr>
						<td>{$web_site['title']}</td>
						<td>{$web_site['url']}</td>
						<td>{$web_site['url_regular']}</td>
						{if empty($web_site['cookies_count'])}
							<td data-toggle="tooltip" data-html="true" data-title="未配置cookie">未配置
						{else}
							<td data-toggle="tooltip" data-html="true" data-title="可用/总数"><strong class="text-success">{$web_site['cookies_count']['available']??0}</strong> / <strong class="text-info">{$web_site['cookies_count']['all']??0}</strong></td>
						{/if}
						<td>{$web_site['status_text']}</td>
						<td>
							<a href="{:url('admin/site/cookie',['site_id'=>$web_site['site_id']])}">Cookie</a>
							<a href="{:url('admin/site/edit_site',['site_id'=>$web_site['site_id']])}">编辑</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/site/delete_site',['site_id'=>$web_site['site_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
</div>

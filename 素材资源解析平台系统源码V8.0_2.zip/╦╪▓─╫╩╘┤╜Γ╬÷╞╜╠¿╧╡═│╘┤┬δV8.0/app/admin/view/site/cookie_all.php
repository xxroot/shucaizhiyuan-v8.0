<div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		全部Cookie列表
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<tr>
					<th>Cookie名称</th>
					<th>所属站点</th>
					<th>今日已用次数</th>
					<th>单日可用次数</th>
					<th>总使用次数</th>
					<th>最大用次数</th>
					<th>状态</th>
					<th>可用</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				{foreach $cookie_list as $cookie}
					<tr class="font-weight-bold {$cookie['available_class']}">
						<td>{$cookie['title']}</td>
						<td>{$cookie['web_site']['title']}</td>
						<td>{$cookie['day_used']}</td>
						<td>{$cookie['day_max']}</td>
						<td>{$cookie['all_used']}</td>
						<td>{$cookie['all_max']}</td>
						<td>{$cookie['status_text']}</td>
						<td>{$cookie['available_text']}</td>
						<td>
							<a href="{:url('admin/site/edit_cookie',['cookie_id'=>$cookie['cookie_id']])}">编辑</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('admin/site/delete_cookie',['cookie_id'=>$cookie['cookie_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
			</tbody>
		</table>
	</div>
</div>

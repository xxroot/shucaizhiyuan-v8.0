<form method="post" autocomplete="off">
	<input type="hidden" name="param[]" value="">
	<div class="card">
		<div class="card-header">
			{if empty($rule)}新增站点{else}编辑站点{/if}
		</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">站点名称</label>
				<input type="text" class="form-control" name="title" value="{$web_site['title']??''}">
				<small class="form-text text-muted">素材站点的名称，例如：昵图网</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">官网地址</label>
				<input type="text" class="form-control" name="url" value="{$web_site['url']??''}">
				<small class="form-text text-muted">站点官网地址，方便用户浏览</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">解析示例</label>
				<input type="text" class="form-control" name="demo_url" value="{$web_site['demo_url']??''}">
				<small class="form-text text-muted">解析示例地址</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">特征码</label>
				<input type="text" class="form-control" name="url_regular" value="{$web_site['url_regular']??''}">
				<small class="form-text text-muted">网站来源特征码，用于区分是什么素材站</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">状态</label>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="1" {if !empty($web_site['status'])}checked{/if}>
					<label class="custom-control-label">启用</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="status" type="radio" class="custom-control-input" value="0" {if empty($web_site['status'])}checked{/if}>
					<label class="custom-control-label">关闭</label>
				</div>
				<small class="form-text text-muted">禁用后前台不可见</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">提交保存</button>
		</div>
	</div>
</form>

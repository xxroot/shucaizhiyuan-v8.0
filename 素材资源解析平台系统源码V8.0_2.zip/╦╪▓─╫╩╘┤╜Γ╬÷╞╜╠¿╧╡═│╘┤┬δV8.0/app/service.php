<?php

return [
    \app\common\service\PaginatorService::class,
    \think\queue\Service::class,
];

<?php
namespace app\index\controller;

use app\common\model\AttachMain;
use app\common\model\PortalArticle;
use app\common\model\PortalShare;
use app\common\model\UserDownloadCount;
use app\common\model\UserDownloadLog;
use app\common\model\UserDownloadTimes;
use app\common\model\UserMain;
use app\common\model\UserSiteAccess;
use app\common\model\WebSite;
use app\common\model\WebSiteCookie;
use app\index\controller\Base;
use think\facade\App;
use think\facade\Db;
use think\facade\Request;
use think\facade\View;
use think\Resource;

class Index extends Base
{

    private function info_tpl($param = [])
    {
        return View::assign($param)->display('{__NOLAYOUT__}<div class="d-flex justify-content-start py-2">
        <div class="text-muted">素材名称：</div>
        <div class="text-info">{$title}</div>
    </div>
    <div class="d-flex justify-content-start py-2 border-top">
        <div class="text-muted">网站名称：</div>
        <div class="text-info">{$web_site[\'title\']}</div>
    </div>
    <div class="d-flex justify-content-start py-2 border-top">
        <div class="text-muted">素材地址：</div>
        <div class="text-info">{$link}</div>
    </div>');
    }

    private function download_count()
    {
        global $_G;
        if (empty($_G['uid'])) {
            return [];
        }
        $result = [];
        foreach (UserDownloadCount::where('uid', '=', $_G['uid'])->select() as $data) {
            $result[$data['site_id']] = $data;
        }
        return $result;
    }

    public function index()
    {
        global $_G;
        $site_access = [];
        if (!empty($_G['uid'])) {
            foreach ($_G['user']['site_access'] as $access) {
                $site_access[$access['site_id']] = $access;
            }
        }
        return View::assign([
            'web_site_list'  => WebSite::where('status', '=', 1)->order('site_id', 'desc')->select(),
            'site_access'    => $site_access,
            'download_count' => $this->download_count(),
            'article_list'   => PortalArticle::where([['status', '=', 1]])->limit(5)->order('create_time', 'desc')->select(),
            'user_nav'       => $this->user_nav(),
        ])->fetch();
    }

    public function parse($link = '', $verify_code = '')
    {
        global $_G;
        if (!Request::isPost() || !Request::isAjax()) {
            return redirect('index/index/index');
        }
        if (empty($link)) {
            return show_error('缺少素材解析地址');
        }
        if (empty($_G['uid'])) {
            return show_error('请先登陆后再使用此功能');
        }
        $last_log = UserDownloadLog::where('uid', '=', $_G['uid'])->order('log_id', 'desc')->find();
        if (!empty($_G['setting']['parse_space_time']) && intval($_G['setting']['parse_space_time']) > 0 && !empty($last_log)) {

            $has_time = intval($_G['setting']['parse_space_time']) - (intval(Request::time()) - $last_log->getData('create_time'));
            if ($has_time > 0) {
                return show_error('操作过于频繁，请 <strong class="text-danger">' . $has_time . '</strong> 秒后后再试');
            }
        }

        $web_site = [];
        foreach (WebSite::where('status', '=', 1)->order('site_id', 'desc')->select() as $data) {
            if (stripos($link, $data['url_regular']) !== false) {
                $web_site = $data;
                break;
            }
        }
        if (empty($web_site)) {
            return show_error('暂不支持该网址解析');
        }
        $site_access = UserSiteAccess::where([['uid', '=', $_G['uid']], ['site_id', '=', $web_site['site_id']]])->find();

        $error = '';
        if ($_G['user']['parse_max_times'] < 0) {
            $error = '您的账户没有解析权限';
        }
        if (!$error && $_G['user']['parse_max_times'] > 0 && $_G['user']['parse_times'] >= $_G['user']['parse_max_times']) {
            $error = '您的账户解析次数已达上限，请充值';
        }
        if (!$error && empty($site_access)) {
            $error = '您尚未开通该站点的解析权限';
        }
        if (!$error && ($site_access['day_times'] < 0 || $site_access['week_times'] < 0 || $site_access['month_times'] < 0 || $site_access['year_times'] < 0 || $site_access['max_times'] < 0 || $site_access->getData('out_time') < 0)) {
            $error = '该站点权限已被禁用，请升级账户权限';
        }
        if (!$error && $site_access->getData('out_time') > 0 && $site_access->getData('out_time') < Request::time()) {
            $error = '该站点解析权限已过期';
        }

        $download_count = $this->download_count();
        if (!empty($download_count[$web_site['site_id']])) {
            if (!$error && $site_access['day_times'] > 0 && $download_count[$web_site['site_id']]['day_used_time'] >= $site_access['day_times']) {
                $error = '该站点今日解析次数已达上限，请明日再来或升级帐号权限';
            }
            if (!$error && $site_access['week_times'] > 0 && $download_count[$web_site['site_id']]['week_used_time'] >= $site_access['week_times']) {
                $error = '该站点本周解析次数已达上限，请下周再来或升级帐号权限';
            }
            if (!$error && $site_access['month_times'] > 0 && $download_count[$web_site['site_id']]['month_used_time'] >= $site_access['month_times']) {
                $error = '该站点本月解析次数已达上限，请下月再来或升级帐号权限';
            }
            if (!$error && $site_access['year_times'] > 0 && $download_count[$web_site['site_id']]['year_used_time'] >= $site_access['year_times']) {
                $error = '该站点今年解析次数已达上限，请明年再来或升级帐号权限';
            }
        }
        if (!$error && $site_access['max_times'] > 0 && $site_access['parse_times'] >= $site_access['max_times']) {
            $error = '该站点总解析次数已达上限，请升级账号权限';
        }
        if (!empty($error)) {
            $download_times = UserDownloadTimes::where([['uid', '=', $_G['uid']], ['site_id', '=', $web_site['site_id']], ['status', '=', 1]])->whereColumn('times', '>', 'used_times')->find();
            if (empty($download_times)) {
                return show_error($error);
            }
        }
        $action   = 'get_' . str_replace('.', '_', $web_site['url_regular']);
        $Resource = new Resource($web_site, $link);
        if (method_exists($Resource, $action)) {
            $cache = $Resource->$action();
            if ($cache !== false) {
                $result = [
                    'code'      => 200,
                    'msg'       => $cache['download'],
                    'info'      => $cache['info'],
                    'title'     => '',
                    'area'      => '',
                    'content'   => '',
                    'no_button' => '',
                    'cache'     => 1,
                ];
            }
        }
        if (empty($result)) {
            $result = http_post('parse', ['verify_code' => $verify_code, 'link' => $link]);
        }
        $return_msg = [];
        switch ($result['code']) {
            case 200:
                $result['info'] = $this->info_tpl($result['info']);

                if (empty($result['cache'])) {
                    WebSiteCookie::where('cookie_id', '=', $result['cookie_id'])->update([
                        'use_time' => Request::time(),
                        'day_used' => Db::raw('day_used+1'),
                        'all_used' => Db::raw('all_used+1'),
                    ]);
                    foreach ($result['msg'] as $button_name => $response_url) {
                        $attach = AttachMain::create([
                            'uid'            => $_G['uid'],
                            'site_id'        => $web_site['site_id'],
                            'request_url'    => $link,
                            'response_url'   => $response_url,
                            'site_code_type' => $result['site_code_type'] ?? '',
                            'site_code'      => $result['site_code'],
                            'button_name'    => $button_name,
                            'queue_error'    => '',
                            'cookie_id'      => $result['cookie_id'],
                            'status'         => 0,
                        ]);
                        if (!empty($result['sync'])) {
                            if (!is_dir(App::getConfigPath() . '/site_cookie')) {
                                create_dir(App::getConfigPath() . '/site_cookie');
                            }
                            file_put_contents(App::getConfigPath() . '/site_cookie/cookie_' . $attach->attach_id, $result['cookie_content']);
                            $return_msg[$button_name] = url('index/download/index', ['attach_id' => $attach->attach_id]);
                        } else {
                            $return_msg[$button_name] = $response_url;
                        }
                    }
                } else {
                    $return_msg = $result['msg'];
                }
                UserDownloadLog::create([
                    'uid'       => $_G['uid'],
                    'site_id'   => $web_site['site_id'],
                    'parse_url' => $link,
                    'type'      => empty($download_times) ? 'vip' : 'download-times',
                    'use_times' => 1,
                    'status'    => 1,
                ]);

                if (!empty($download_times)) {
                    if (($download_times->used_times + 1) >= $download_times->times) {
                        $download_times->status = 0;
                    }
                    $download_times->used_times = Db::raw('used_times+1');
                    $download_times->save();
                } else {
                    UserMain::where('uid', '=', $_G['uid'])->update(['parse_times' => Db::raw('parse_times+1')]);
                    $count = UserDownloadCount::where([['uid', '=', $_G['uid']], ['site_id', '=', $web_site['site_id']]])->find();
                    if (!empty($count)) {
                        $count->day_used_time   = Db::raw('day_used_time+1');
                        $count->week_used_time  = Db::raw('week_used_time+1');
                        $count->month_used_time = Db::raw('month_used_time+1');
                        $count->year_used_time  = Db::raw('year_used_time+1');
                        $count->save();
                    } else {
                        UserDownloadCount::create([
                            'uid'                => $_G['uid'],
                            'site_id'            => $web_site['site_id'],
                            'day_used_time'      => 1,
                            'week_used_time'     => 1,
                            'month_used_time'    => 1,
                            'year_used_time'     => 1,
                            'day_refresh_time'   => date('Ymd'),
                            'week_refresh_time'  => date('W'),
                            'month_refresh_time' => date('Ym'),
                            'year_refresh_time'  => date('Y'),
                        ]);
                    }
                    if (!empty($site_access)) {
                        $site_access->parse_times = Db::raw('parse_times+1');
                        $site_access->save();
                    }
                }
                break;

            case -404:
                $return_msg = '获取失败，请检查网址是否输入有误';
                break;

            case -405:
                $return_msg = '缺少素材解析地址';
                break;

            case -406:
                $return_msg = '暂不支持该网址解析';
                break;

            case -407:
                $return_msg = '该站点尚未开放解析';
                break;

            case -408:
                $return_msg = '该网址解析系统维护中';
                break;

            case -500:
                $return_msg = '解析失败，请联系管理员';
                break;

            default:
                $return_msg = $result['msg'] ?? '解析失败';
                break;
        }
        return json([
            'code'      => $result['code'],
            'msg'       => $return_msg,
            'info'      => $result['info'] ?? '',
            'title'     => $result['title'] ?? '',
            'area'      => $result['area'] ?? '',
            'content'   => $result['content'] ?? '',
            'no_button' => $result['no_button'] ?? '',
        ]);
    }

    public function search($keywork = '')
    {
        $keywork = trim($keywork);
        if (Request::isPost()) {
            if (empty(Request::post('keywork/s'))) {
                return show_error('请输入关键字');
            }
            return redirect('index/index/search', ['keywork' => Request::post('keywork/s')]);
        }
        $search_list = !empty($keywork) ? PortalShare::where('status', '>', 0)->whereLike('subject', '%' . $keywork . '%')->paginate([
            'list_rows' => 32,
            'query'     => ['keywork' => $keywork],
        ]) : [];
        $page = !empty($search_list) ? $search_list->render() : '';
        return View::assign([
            'search_list' => $search_list,
            'page'        => $page,
            'keywork'     => $keywork,
        ])->fetch();
    }

    public function jump($download_url = '')
    {
        return View::assign(['download_url' => $download_url])->fetch();
    }

    public function redirect($download_url = '')
    {
        return View::assign(['download_url' => $download_url])->fetch();
    }

    private function user_nav()
    {
        global $_G;
        $result = [
            [
                'name' => '个人中心',
                'icon' => 'icon-user',
                'url'  => url('index/user/index'),
            ],
        ];
        if (!empty($_G['setting']['search_resources'])) {
            $result[] = [
                'name' => '搜索素材',
                'icon' => 'icon-search',
                'url'  => url('index/index/search'),
            ];
        }
        if (!empty($_G['user']) && in_array($_G['user']['type'], ['system', 'proxy'])) {
            $result[] = [
                'name' => '商家代理',
                'icon' => 'icon-users',
                'url'  => url('index/user/proxy'),
            ];
        }
        $result[] = [
            'name' => '账户充值',
            'icon' => 'icon-balance',
            'url'  => url('index/user/recharge'),
        ];
        $result[] = [
            'name' => '升级账户',
            'icon' => 'icon-buytimes',
            'url'  => url('index/user/buy_times'),
        ];
        if ($_G['setting']['user_fission']) {
            $result[] = [
                'name' => '推广赚钱',
                'icon' => 'icon-tuiguang',
                'url'  => url('index/user/spread'),
            ];
        }
        $result[] = [
            'name' => '分享素材',
            'icon' => 'icon-circle',
            'url'  => url('index/user/share'),
        ];
        if (empty($_G['uid'])) {
            $result[] = [
                'name' => '用户登录',
                'icon' => 'icon-tuiguang',
                'url'  => url('index/account/login'),
            ];
            $result[] = [
                'name' => '注册账号',
                'icon' => 'icon-bangzhu',
                'url'  => url('index/account/register'),
            ];
        } else {
            $result[] = [
                'name' => '修改密码',
                'icon' => 'icon-mima',
                'url'  => url('index/user/password'),
            ];
            $result[] = [
                'name' => '安全退出',
                'icon' => 'icon-logout',
                'url'  => url('index/account/logout'),
            ];
        }
        return $result;
    }
}

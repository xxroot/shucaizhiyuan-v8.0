<?php
namespace app\index\controller;

use think\facade\Config;
use think\facade\Request;

class Base
{

    public function __construct()
    {
        global $_G;
        if (Request::controller() == 'User' && empty($_G['uid'])) {
            return redirect('index/account/login');
        }
        if (Request::controller() == 'Index' && empty($_G['uid']) && !empty($_G['setting']['must_login'])) {
            return redirect('index/account/login');
        }
        if (Request::controller() != 'Error' && $_G['setting']['site_close'] && !in_array($_G['uid'], Config::get('app.founder'))) {
            return redirect('index/error/site_close');
        }
        if (!empty($_G['uid']) && $_G['user']['status'] == 0) {
            return redirect('index/error/wait_review');
        }
    }
}

<?php
namespace app\index\controller;

class Caiji
{
    public function index()
    {

    }
}

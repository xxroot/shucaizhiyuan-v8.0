<?php
namespace app\index\controller;

use app\common\model\PortalArticle;
use app\index\controller\Base;
use think\facade\Db;
use think\facade\View;

class Portal extends Base
{

    public function index()
    {
        $article_list = PortalArticle::where('status', '=', 1)->order('article_id', 'desc')->paginate(30);
        return View::assign([
            'article_list' => $article_list,
            'page'         => $article_list->render(),
        ])->fetch();
    }

    public function view($article_id = 0)
    {
        $article = PortalArticle::where([
            ['article_id', '=', $article_id],
            ['status', '=', 1],
        ])->find();
        if (!empty($article)) {
            $article->views = Db::raw('views+1');
            $article->save();
        }
        return View::assign([
            'article' => $article,
        ])->fetch();
    }
}

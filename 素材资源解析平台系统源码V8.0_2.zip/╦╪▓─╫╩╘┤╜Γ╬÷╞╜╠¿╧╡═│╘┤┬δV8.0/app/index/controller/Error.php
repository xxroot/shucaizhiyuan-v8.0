<?php
namespace app\index\controller;

use think\facade\View;

class Error
{

    public function wait_review()
    {
        global $_G;
        if (empty($_G['uid'])) {
            return redirect('index/account/login');
        }
        if ($_G['user']['status'] != 0) {
            return redirect('index/user/index');
        }
        return View::fetch();
    }

    public function site_close()
    {
        global $_G;
        if (empty($_G['setting']['site_close'])) {
            return redirect('index/index/index');
        }
        return View::fetch();
    }
}

<?php
namespace app\index\controller;

use app\common\model\RequestCore;
use OSS\Core\OssException;
use OSS\Core\OssUtil;
use OSS\OssClient;

class Caiji
{
    public function xia()
    {
        //ob_end_clean();
        //header('Content-type: application/octet-stream');
        //header('Content-Transfer-Encoding: binary');
        //header('Accept-Ranges: bytes');
        //header('Content-Disposition: attachment; filename="xxx.zip"');

        $curl = new RequestCore('');
        $curl->set_write_file('xxxxx.zip');
        $curl->register_streaming_write_callback(function ($curl_handle, $written_total, $data) use ($curl) {
            //echo $data;
        })->send_request();

        var_dump($curl->get_response_header());
    }

    public function index()
    {
        global $_G;
        $object     = "waewaewaeawewa.txt";
        $uploadFile = "index.php";

        try {
            $ossClient = new OssClient($_G['setting']['AccessKeyId'], $_G['setting']['AccessKeySecret'], $_G['setting']['Endpoint']);

            $ossClient->uploadFile($_G['setting']['Bucket'], $object, $uploadFile);
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }
        print(__FUNCTION__ . ": OK" . "\n");
    }

    public function fen()
    {
        global $_G;
        $object     = "waewaewaeawewa.txt";
        $uploadFile = "index.php";

        try {
            $ossClient = new OssClient($_G['setting']['AccessKeyId'], $_G['setting']['AccessKeySecret'], $_G['setting']['Endpoint']);
            $uploadId  = $ossClient->initiateMultipartUpload($_G['setting']['Bucket'], $object);
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": initiateMultipartUpload FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }
        $partSize           = 10 * 1024 * 1024;
        $uploadFileSize     = filesize($uploadFile);
        $pieces             = $ossClient->generateMultiuploadParts($uploadFileSize, $partSize);
        $responseUploadPart = [];
        $uploadPosition     = 0;
        $isCheckMd5         = true;
        foreach ($pieces as $i => $piece) {
            $fromPos   = $uploadPosition + (integer) $piece[$ossClient::OSS_SEEK_TO];
            $toPos     = (integer) $piece[$ossClient::OSS_LENGTH] + $fromPos - 1;
            $upOptions = [
                $ossClient::OSS_FILE_UPLOAD => $uploadFile,
                $ossClient::OSS_PART_NUM    => ($i + 1),
                $ossClient::OSS_SEEK_TO     => $fromPos,
                $ossClient::OSS_LENGTH      => $toPos - $fromPos + 1,
                $ossClient::OSS_CHECK_MD5   => $isCheckMd5,
            ];
            if ($isCheckMd5) {
                $contentMd5                             = OssUtil::getMd5SumForFile($uploadFile, $fromPos, $toPos);
                $upOptions[$ossClient::OSS_CONTENT_MD5] = $contentMd5;
            }
            try {
                $responseUploadPart[] = $ossClient->uploadPart($_G['setting']['Bucket'], $object, $uploadId, $upOptions);
            } catch (OssException $e) {
                printf(__FUNCTION__ . ": initiateMultipartUpload, uploadPart - part#{$i} FAILED\n");
                printf($e->getMessage() . "\n");
                return;
            }
        }
        $uploadParts = [];
        foreach ($responseUploadPart as $i => $eTag) {
            $uploadParts[] = [
                'PartNumber' => ($i + 1),
                'ETag'       => $eTag,
            ];
        }
        try {
            $ossClient->completeMultipartUpload($_G['setting']['Bucket'], $object, $uploadId, $uploadParts);
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": completeMultipartUpload FAILED\n");
            printf($e->getMessage() . "\n");
            return;
        }
        return '上传完成';
    }
}

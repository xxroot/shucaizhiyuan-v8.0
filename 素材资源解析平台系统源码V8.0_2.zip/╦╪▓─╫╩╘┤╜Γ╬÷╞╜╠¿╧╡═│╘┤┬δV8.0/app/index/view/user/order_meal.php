<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">流水号</th>
				<th class="border-top-0 border-bottom">创建时间</th>
				<th class="border-top-0 border-bottom">套餐名称</th>
				<th class="border-top-0 border-bottom">金额</th>
				<th class="border-top-0 border-bottom">状态</th>
				<th class="border-top-0 border-bottom"></th>
			</thead>
			<tbody>
				{foreach $order_list as $order}
					<tr class="{$order['text_color']}">
						<td>{$order['order_id']}</td>
						<td>{$order['create_time']}</td>
						<td>{$order['title']}</td>
						<td class="font-weight-bold">{$order['all_price']}</td>
						<td>{$order['status_text']}</td>
						<td>
							<a href="{:url('index/user/buy_meal_pay',['order_id'=>$order['order_id']])}">{if $order['status'] == 0}立即支付{else}查看详情{/if}</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('index/user/buy_meal_delete',['order_id'=>$order['order_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="5"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

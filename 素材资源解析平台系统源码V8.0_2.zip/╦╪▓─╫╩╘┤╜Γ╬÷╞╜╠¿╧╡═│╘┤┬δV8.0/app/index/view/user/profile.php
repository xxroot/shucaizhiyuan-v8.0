<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-5">
		<form autocomplete="off">
			<div class="form-group">
				<div>用 户 名：<span class="text-muted">{$_G['user']['username']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(不可修改)</span></div>
			</div>
			<div class="form-group">
				<label>邮箱地址</label>
				<input type="email" name="email" class="form-control" value="{$_G['user']['email']}">
			</div>
			<div class="form-group">
				<label>手 机 号</label>
				<input type="text" name="mobile" class="form-control" value="{$_G['user']['mobile']}">
			</div>
			<div class="form-group">
				<label>联系QQ</label>
				<input type="text" name="qq" class="form-control" value="{$_G['user']['qq']}">
			</div>
			<div class="form-group">
				<label>微信号</label>
				<input type="text" name="weixin" class="form-control" value="{$_G['user']['weixin']}">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success ajax-post">保存设置</button>
			</div>
		</form>
	</div>
</div>

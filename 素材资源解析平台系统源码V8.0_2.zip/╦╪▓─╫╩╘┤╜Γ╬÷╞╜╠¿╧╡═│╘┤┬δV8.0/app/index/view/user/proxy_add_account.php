<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-5">
		<form autocomplete="off">
			<div class="form-group">
				<label>用户名：</label>
				<input type="text" name="username" class="form-control">
				<small class="text-info">登录账户名，不能使用邮箱或手机号作为用户名</small>
			</div>
			<div class="form-group">
				<label>密码：</label>
				<input type="text" name="password" class="form-control">
				<small class="text-info">登录密码，设置成功后无法查看，请务必牢记</small>
			</div>
			<div class="form-group">
				<label>账户余额：</label>
				<input type="number" name="balance" class="form-control" value="0">
				<small class="text-danger">给用户增加余额会扣除本账号相同额度的余额，请谨慎操作</small>
			</div>
			<div class="form-group">
				<label>账户折扣：</label>
				<input type="number" name="discount" class="form-control">
				<small class="text-success">值范围：{:floatval($_G['user']['discount'])} - 10</small>
			</div>
			<div class="form-group">
				<label>套餐：</label>
				<select class="form-control" name="meal_id">
					<option value="-1">请选择套餐</option>
					{php}$meal_prices=[];{/php}
					{foreach $meal_list as $meal}
						{php}$meal_prices[$meal['meal_id']]=$meal['price'];{/php}
						<option value="{$meal['meal_id']}">{$meal['title']}</option>
					{/foreach}
				</select>
			</div>
			<div class="form-group">
				<div class="custom-control custom-radio">
					<input name="type" type="radio" class="custom-control-input" value="member" checked>
					<label class="custom-control-label">普通用户</label>
				</div>
				<div class="custom-control custom-radio">
					<input name="type" type="radio" class="custom-control-input" value="proxy">
					<label class="custom-control-label">代理用户</label>
				</div>
			</div>
			<div class="form-group">本次开户需支付<strong class="text-danger px-2 need-price">0 元</strong></div>
			<div class="form-group">
				<button type="submit" class="btn btn-success ajax-post" data-before="need_price">确定开户</button>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	$(document)
		.on('change','select[name="meal_id"]',function(){
			var meal_id = $(this).val();
			need_price();
		})
		.on('keyup change','input[name="balance"]',function(e){
			if (!String.fromCharCode(e.keyCode).match(/[0-9\.]/) && e.keyCode !=38 && e.keyCode != 40) {
				return false;
			}
			var balance = $(this).val();
			if(balance < 0){
				$(this).val('0');
				return dialog.msg({'code':-1,'msg':'余额输入错误'});
			}
			need_price();
		})
	function need_price(){
		var balance = $('input[name="balance"]').val();
		var meal_id = $('select[name="meal_id"]').val();
		var meal_prices = {:json_encode($meal_prices)};
		if(meal_id>0){
			balance = parseFloat(balance)+parseFloat(meal_prices[meal_id]);
		}
		$('.need-price').html(balance+' 元');
	}
</script>

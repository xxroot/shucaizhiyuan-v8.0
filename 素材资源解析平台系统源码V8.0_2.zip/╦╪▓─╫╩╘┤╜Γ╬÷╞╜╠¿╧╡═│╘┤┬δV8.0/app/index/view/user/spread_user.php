<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">用户名</th>
				<th class="border-top-0 border-bottom">邮箱</th>
				<th class="border-top-0 border-bottom" width="160">下级层数</th>
				<th class="border-top-0 border-bottom" width="180">注册时间</th>
			</thead>
			<tbody>
				{foreach $fission_list as $fission}
					<tr>
						<td>{:cutstr($fission['spread_user']['username'],4,'***')}</td>
						<td>{:cutstr(substr($fission['spread_user']['email'],0,stripos($fission['spread_user']['email'],'@')),3,'')}***{:substr($fission['spread_user']['email'],stripos($fission['spread_user']['email'],'@'))}</td>
						<td>{$fission['floor']}</td>
						<td>{$fission['create_time']}</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="3"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

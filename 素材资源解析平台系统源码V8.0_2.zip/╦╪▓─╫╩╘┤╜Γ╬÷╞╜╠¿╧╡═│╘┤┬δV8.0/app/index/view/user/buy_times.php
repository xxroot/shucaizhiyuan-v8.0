<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		{if $meal_list->isEmpty()}
			<div class="text-center h1 text-muted p-5">暂无可升级的套餐，请联系管理员处理</div>
		{else}
			{foreach $meal_list as $meal}
				<div class="media py-3 px-4 d-flex align-items-center justify-content-between border-bottom">
					<div class="media-body">
						<h5 class="mt-0">{$meal['title']}</h5>
						<p>{$meal['summary']}</p>
					</div>
					<div class="text-danger font-weight-bold mr-5">
						{if floatval($_G['user']['discount']) > 0 && floatval($_G['user']['discount']) < 10}
							<strong style="text-decoration:line-through">￥{$meal['price']}</strong>
							<strong class="pl-3 text-success">￥{$meal['price']*floatval($_G['user']['discount'])*0.1}</strong>
						{else}
							￥{$meal['price']}
						{/if}
					</div>
					{if $meal['type'] == 'vip'}
						<a class="btn btn-danger" href="{:url('index/user/buy_meal',['meal_id'=>$meal['meal_id']])}">升级 VIP</a>
					{elseif $meal['type'] == 'download'}
						<a class="btn btn-success" href="{:url('index/user/buy_meal',['meal_id'=>$meal['meal_id']])}">购买套餐</a>
					{/if}
				</div>
			{/foreach}
			{if $page}
				<div class="d-flex align-items-center justify-content-center m-3">{$page|raw}</div>
			{/if}
		{/if}
	</div>
</div>

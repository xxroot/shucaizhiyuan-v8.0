<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-5">
		<form autocomplete="off">
			<div class="form-group">
				<div>用 户 名：<span class="text-muted">{$_G['user']['username']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(不可修改)</span></div>
			</div>
			<div class="form-group">
				<label>当前密码</label>
				<input type="password" name="oldpassword" class="form-control">
			</div>
			<div class="form-group">
				<label>新 密 码</label>
				<input type="password" name="password" class="form-control">
			</div>
			<div class="form-group">
				<label>重复新密码</label>
				<input type="password" name="password_confirm" class="form-control">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-danger ajax-post">确认修改</button>
			</div>
		</form>
	</div>
</div>

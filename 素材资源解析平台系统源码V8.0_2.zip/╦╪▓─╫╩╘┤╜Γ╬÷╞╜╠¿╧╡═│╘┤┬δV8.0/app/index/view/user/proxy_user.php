<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">用户名</th>
				<th class="border-top-0 border-bottom">创建时间</th>
				<th class="border-top-0 border-bottom">最后登录</th>
				<th class="border-top-0 border-bottom">状态</th>
			</thead>
			<tbody>
				{foreach $user_list as $user}
					<tr class="{$user['text_color']}">
						<td>{$user['username']}</td>
						<td>{$user['register_time']}</td>
						<td>{$user['last_time']}</td>
						<td>{$user['status_text']}</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="4"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

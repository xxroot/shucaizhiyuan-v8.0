<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-5">
		<form method="post" data-after="create_order">
			<div class="form-group">
				<div>当前账户：<strong class="text-success">{$_G['user']['username']}</strong></div>
			</div>
			<div class="form-group">
				<div>账户余额：<strong class="text-danger">{$_G['user']['balance']}</strong></div>
			</div>
			<div class="form-group">
				<label>充值金额：</label>
				<input type="number" name="price" class="form-control" value="{$_G['setting']['min_recharge_price']??10}">
			</div>
			<div class="form-group">
				<button class="btn btn-success ajax-post" type="submit">立即充值</button>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	function create_order(from,s,btn){
		if(s.code == 1){
			location.href = s.url;
			return false;
		}
	}
</script>

<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-3">
		<form method="post" data-after="create_order">
			<div class="form-group">
				<div>当前账户：<strong class="text-success">{$_G['user']['username']}</strong></div>
			</div>
			<div class="form-group">
				<div>账户余额：<strong class="text-danger">{$_G['user']['balance']}</strong></div>
			</div>
			<div class="form-group">
				<div>所购套餐：<strong class="text-danger">{$meal['title']}</strong><a class="ml-3" href="{:url('index/user/buy_times')}">切换</a></div>
			</div>
			{if floatval($_G['user']['discount']) > 0 && floatval($_G['user']['discount']) < 10}
				<div class="form-group">
					<div>套餐原价：<strong class="text-danger" style="text-decoration:line-through">￥{$meal['price']}</strong></div>
				</div>
				<div class="form-group">
					<div>折扣价格：<strong class="text-success">￥{$meal['price']*floatval($_G['user']['discount'])*0.1}</strong></div>
				</div>
			{else}
				<div class="form-group">
					<div>套餐价格：<strong class="text-danger">￥{$meal['price']}</strong></div>
				</div>
			{/if}
			{if $meal['type'] == 'download'}
				<div class="form-group">
					<label>购买份数：</label>
					<input type="number" name="buy_number" class="form-control" value="1">
				</div>
			{/if}
			<div class="form-group">
				<button class="btn btn-success ajax-post" type="submit">立即购买</button>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	function create_order(from,s,btn){
		if(s.code == 1){
			location.href = s.url;
			return false;
		}
	}
</script>

<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">站点</th>
				<th class="border-top-0 border-bottom">获得时间</th>
				<th class="border-top-0 border-bottom">奖励次数</th>
				<th class="border-top-0 border-bottom">说明</th>
				<th class="border-top-0 border-bottom">过期时间</th>
				<th class="border-top-0 border-bottom">状态</th>
			</thead>
			<tbody>
				{foreach $reward_list as $reward}
					<tr>
						<td>{$reward['web_site']['title']}</td>
						<td>{$reward['create_time']}</td>
						<td>{$reward['times']}</td>
						<td>{$reward['summary']}</td>
						<td>{$reward['out_time']?:'永久有效'}</td>
						<td>{$reward['status_text']}</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="6"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

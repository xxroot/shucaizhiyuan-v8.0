<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-5">
		<form autocomplete="off">
			<input type="hidden" name="attach_id" value="0">
			<input type="hidden" name="cover" value="">
			<div class="form-group">
				<label>素材标题</label>
				<input type="text" name="subject" class="form-control">
			</div>
			<div class="form-group">
				<label>来源地址</label>
				<input type="text" name="from_url" class="form-control">
			</div>
			<div class="form-group d-flex justify-content-start">
				<button class="btn btn-danger upload-file" type="button">选择附件</button>
				<div class="upload-progress-box w-75 ml-5"></div>
			</div>
			<div class="form-group d-flex justify-content-start">
				<button class="btn btn-info upload-cover" type="button">选择封面</button>
				<div class="upload-progress-box2 w-75 ml-5"></div>
			</div>
			<div class="form-group">
				<label>附件描述</label>
				<textarea class="form-control" name="message"></textarea>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success ajax-post">立即分享</button>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript" src="static/js/upload.js"></script>
<script type="text/javascript">
	$('.upload-file').uploadFile({
		'fileLimit':1,
		'container':'.upload-progress-box',
		succeed:function(file,s){
			$('input[name="attach_id"]').val(s.data.attach_id);
		},
		removeFile:function(file){
			$('input[name="attach_id"]').val('0');
		}
	});
	$('.upload-cover').uploadFile({
		'fileLimit':1,
		'fileAccept':'image/*',
		'container':'.upload-progress-box2',
		succeed:function(file,s){
			$('input[name="cover"]').val(s.data.savename);
		},
		removeFile:function(file){
			$('input[name="cover"]').val('');
		}
	});
</script>

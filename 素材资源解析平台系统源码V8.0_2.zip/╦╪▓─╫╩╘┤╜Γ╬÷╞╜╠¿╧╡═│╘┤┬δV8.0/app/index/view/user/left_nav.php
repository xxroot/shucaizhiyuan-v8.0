<div class="user-left">
	<div class="user-nav mb-3">
		<a class="d-block bg-success text-white" href="{:url('index/index/index')}">返回首页</a>
		<a class="d-block {if $Request.controller == 'User' && $Request.action == 'index'}active{/if}" href="{:url('index/user/index')}">账户概览</a>
	</div>
	<h6 class="p-3 text-black-50">个人中心</h6>
	<div class="user-nav mb-3">
		<a class="d-block {if $Request.action == 'profile'}active{/if}" href="{:url('index/user/profile')}">资料设置</a>
		<a class="d-block {if in_array($Request.action,['card'])}active{/if}" href="{:url('index/user/card')}">充值卡充值</a>
		<a class="d-block {if in_array($Request.action,['recharge','recharge_pay'])}active{/if}" href="{:url('index/user/recharge')}">账户充值</a>
		<a class="d-block {if in_array($Request.action,['buy_times','buy_meal','buy_meal_pay'])}active{/if}" href="{:url('index/user/buy_times')}">购买次数</a>
		<a class="d-block {if in_array($Request.action,['order'])}active{/if}" href="{:url('index/user/order')}">充值订单</a>
		<a class="d-block {if in_array($Request.action,['order_meal'])}active{/if}" href="{:url('index/user/order_meal')}">套餐订单</a>
		<a class="d-block {if in_array($Request.action,['reward_all'])}active{/if}" href="{:url('index/user/reward_all')}">下载次数</a>
		<a class="d-block {if in_array($Request.action,['download_log'])}active{/if}" href="{:url('index/user/download_log')}">下载记录</a>
		<a class="d-block {if $Request.action == 'password'}active{/if}" href="{:url('index/user/password')}">更改密码</a>
	</div>
	{if $_G['user']['type'] == 'system' || $_G['user']['type'] == 'proxy'}
		<h6 class="p-3 text-black-50">商家代理</h6>
		<div class="user-nav mb-3">
			<a class="d-block {if $Request.action == 'proxy'}active{/if}" href="{:url('index/user/proxy')}">代理中心</a>
			<a class="d-block {if $Request.action == 'proxy_add_account'}active{/if}" href="{:url('index/user/proxy_add_account')}">新增开户</a>
			<a class="d-block {if $Request.action == 'proxy_user'}active{/if}" href="{:url('index/user/proxy_user')}">代理用户</a>
		</div>
	{/if}
	{if $_G['setting']['user_fission']}
		<h6 class="p-3 text-black-50">推广赚钱</h6>
		<div class="user-nav mb-3">
			<a class="d-block {if $Request.action == 'spread'}active{/if}" href="{:url('index/user/spread')}">推广链接</a>
			<a class="d-block {if $Request.action == 'spread_user'}active{/if}" href="{:url('index/user/spread_user')}">推广统计</a>
			<a class="d-block {if $Request.action == 'spread_reward'}active{/if}" href="{:url('index/user/spread_reward')}">推广奖励</a>
		</div>
	{/if}
	<h6 class="p-3 text-black-50">分享素材</h6>
	<div class="user-nav mb-3">
		<a class="d-block {if $Request.action == 'share'}active{/if}" href="{:url('index/user/share')}">我的分享</a>
		<a class="d-block {if $Request.action == 'share_now'}active{/if}" href="{:url('index/user/share_now')}">立即分享</a>
	</div>
	<h6 class="p-3 text-black-50">帮助文档</h6>
	<div class="user-nav mb-3">
		<a class="d-block {if $Request.controller == 'Portal'}active{/if}" href="{:url('index/portal/index')}">文档大全</a>
	</div>
</div>

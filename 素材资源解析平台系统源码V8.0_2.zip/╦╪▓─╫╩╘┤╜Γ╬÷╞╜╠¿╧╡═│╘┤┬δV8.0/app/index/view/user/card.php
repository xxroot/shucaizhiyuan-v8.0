<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<form class="px-5 pt-5 pb-3" autocomplete="off">
			<div class="form-group">
				<div>用 户 名：<span class="text-muted">{$_G['user']['username']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(不可修改)</span></div>
			</div>
			<div class="form-group">
				<input type="text" name="card_id" class="form-control" placeholder="请输入充值卡号">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success ajax-post">兑换充值卡</button>
			</div>
		</form>
		<table class="table">
			<tr>
				<th colspan="4" class="text-center text-success bg-light">我的兑换记录</th>
			</tr>
			<tr>
				<th>充值卡号</th>
				<th>类型</th>
				<th>余额</th>
				<th>兑换日期</th>
			</tr>
			{foreach $card_list as $card}
				<tr>
					<td>{$card['card_id']}</td>
					<td>{$card['type_text']}</td>
					<td>{$card['balance']}</td>
					<td>{$card['update_time']}</td>
				</tr>
			{/foreach}
		</table>
	</div>
</div>

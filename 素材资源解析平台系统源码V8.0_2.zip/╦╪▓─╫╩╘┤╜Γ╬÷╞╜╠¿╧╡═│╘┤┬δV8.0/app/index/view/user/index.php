<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<div class="p-3">
			<div class="form-group row pt-5">
				<label class="col-sm-3 text-right">用 户 名：</label>
				<div class="col-sm-9">{$_G['user']['username']}</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">账户余额：</label>
				<div class="col-sm-9"><strong class="text-danger">{$_G['user']['balance']}</strong><a class="ml-3" href="{:url('index/user/recharge')}">充值</a></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">绑定 QQ：</label>
				<div class="col-sm-9">{$_G['user']['qq']}<a class="ml-3" href="{:url('index/user/profile')}">{if $_G['user']['qq']}更换{else}填写{/if}</a></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">绑定微信：</label>
				<div class="col-sm-9">{$_G['user']['weixin']}<a class="ml-3" href="{:url('index/user/profile')}">{if $_G['user']['weixin']}更换{else}填写{/if}</a></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">绑定邮箱：</label>
				<div class="col-sm-9">{$_G['user']['email']}<a class="ml-3" href="{:url('index/user/profile')}">{if $_G['user']['email']}更换{else}填写{/if}</a></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">绑定手机：</label>
				<div class="col-sm-9">{$_G['user']['mobile']}<a class="ml-3" href="{:url('index/user/profile')}">{if $_G['user']['mobile']}更换{else}填写{/if}</a></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">加入时间：</label>
				<div class="col-sm-9">{$_G['user']['register_time']}</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">上次登录：</label>
				<div class="col-sm-9">{$_G['user']['last_time']}</div>
			</div>
		</div>
		<table class="table">
			<tr>
				<th>站点</th>
				<th>日上限</th>
				<th>周上限</th>
				<th>月上限</th>
				<th>年上限</th>
				<th>最大次数</th>
				<th>过期时间</th>
			</tr>
			{foreach $web_site_list as $web_site}
				<tr>
					<td>{$web_site['title']}</td>
					{foreach ['day_times'=>'day_used_time','week_times'=>'week_used_time','month_times'=>'month_used_time','year_times'=>'year_used_time','max_times'=>'max_times'] as $t=>$c}
						<td>
							{if empty($site_access[$web_site['site_id']]) || $site_access[$web_site['site_id']][$t] < 0}
								无权限
							{else}
								{if $site_access[$web_site['site_id']][$t] == 0}
									无限制
								{else}
									{$site_access[$web_site['site_id']][$t]}次
								{/if}
							{/if}
						</td>
					{/foreach}
					<td>
						{if empty($site_access[$web_site['site_id']]) || $site_access[$web_site['site_id']]->getData('out_time') < 0}
							无权限
						{else}
							{if $site_access[$web_site['site_id']]->getData('out_time') == 0}
								永久有效
							{else}
								{$site_access[$web_site['site_id']]['out_time']}
							{/if}
						{/if}
					</td>
				</tr>
			{/foreach}
		</table>
	</div>
</div>

<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">标题</th>
				<th class="border-top-0 border-bottom">时间</th>
				<th class="border-top-0 border-bottom">文件大小</th>
				<th class="border-top-0 border-bottom">状态</th>
				<th class="border-top-0 border-bottom"></th>
			</thead>
			<tbody>
				{foreach $share_list as $share}
					<tr class="{$share['text_color']}">
						<td>{$share['subject']}</td>
						<td>{$share['create_time']}</td>
						<td>{:format_bytes($share['attach']['filesize'])}</td>
						<td>{$share['status_text']}</td>
						<td>
							<a class="ajax-link" data-mode="confirm" href="{:url('index/user/share_delete',['share_id'=>$share['share_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="4"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

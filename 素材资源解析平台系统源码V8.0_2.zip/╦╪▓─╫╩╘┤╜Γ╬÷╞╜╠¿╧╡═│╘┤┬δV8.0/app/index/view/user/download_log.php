<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">站点</th>
				<th class="border-top-0 border-bottom">时间</th>
				<th class="border-top-0 border-bottom">请求地址</th>
				<th class="border-top-0 border-bottom">消耗次数</th>
				<th class="border-top-0 border-bottom">状态</th>
			</thead>
			<tbody>
				{foreach $log_list as $log}
					<tr>
						<td>{$log['web_site']['title']}</td>
						<td>{$log['create_time']}</td>
						<td>{$log['parse_url']}</td>
						<td>{$log['use_times']}</td>
						<td>{$log['status_text']}</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="4"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

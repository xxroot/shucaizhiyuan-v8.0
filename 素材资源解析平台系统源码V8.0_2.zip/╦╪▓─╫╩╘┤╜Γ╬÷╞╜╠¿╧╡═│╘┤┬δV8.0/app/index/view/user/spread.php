<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<div class="px-5 pt-5">
			<div class="form-group row">
				<label class="col-sm-3 text-right">我的链接：</label>
				<div class="col-sm-9"><strong class="Clipboard text-success" data-toggle="tooltip" data-placement="top" data-original-title="点击复制推广链接" data-clipboard-text="推荐一个非常好用的素材解析网站
	{:request()->domain()}/?f={$_G['uid']}">{:request()->domain()}/?f={$_G['uid']}</strong></div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">累计推广注册人数：</label>
				<div class="col-sm-9"><strong class="text-success">{$spread_users}</strong> 次</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-3 text-right">获得下载奖励次数：</label>
				<div class="col-sm-9"><strong class="text-success">{$spread_rewards}</strong> 次</div>
			</div>
			<div class="alert alert-success">点击推广链接发送给朋友或群聊里，用户通过推广链接注册后您将获得相应奖励，当有用户通过您的链接注册后可获得相应奖励</div>
		</div>
		<table class="table mb-0">
			{foreach $_G['setting']['user_fission_reward']['times'] as $site_id=>$times}
				{if $times > 0 && $_G['setting']['user_fission_reward']['out_time'][$site_id] > 0 && !empty($web_site_list[$site_id]['title'])}
					<tr>
						<td>{$web_site_list[$site_id]['title']}</td>
						<td>{$times} 次</td>
						<td>{$_G['setting']['user_fission_reward']['out_time'][$site_id]} 小时</td>
					</tr>
				{/if}
			{/foreach}
		</table>
	</div>
</div>

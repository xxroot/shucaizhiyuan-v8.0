<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100 p-3">
		<div class="form-group row pt-5">
			<label class="col-sm-3 text-right">下级用户：</label>
			<div class="col-sm-9"><strong class="text-danger">{$proxy_count}</strong> 位</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-3 text-right">当前折扣：</label>
			<div class="col-sm-9"><strong class="text-danger">{:floatval($_G['user']['discount'])}</strong> 折</div>
		</div>
	</div>
</div>

<div class="d-flex align-items-stretch user-box">
	{include file="user/left_nav"}
	<div class="user-content w-100">
		<table class="table table-hover">
			<thead>
				<th class="border-top-0 border-bottom">流水号</th>
				<th class="border-top-0 border-bottom">创建时间</th>
				<th class="border-top-0 border-bottom">交易金额</th>
				<th class="border-top-0 border-bottom">状态</th>
				<th class="border-top-0 border-bottom"></th>
			</thead>
			<tbody>
				{foreach $recharge_list as $recharge}
					<tr class="{$recharge['text_color']}">
						<td>{$recharge['recharge_id']}</td>
						<td>{$recharge['create_time']}</td>
						<td class="font-weight-bold">{$recharge['price']}</td>
						<td>{$recharge['status_text']}</td>
						<td>
							<a href="{:url('index/user/recharge_pay',['recharge_id'=>$recharge['recharge_id']])}">{if $recharge['status'] == 0}立即支付{else}查看详情{/if}</a>
							<a class="ajax-link" data-mode="confirm" href="{:url('index/user/recharge_delete',['recharge_id'=>$recharge['recharge_id']])}">删除</a>
						</td>
					</tr>
				{/foreach}
				{if $page}
					<tr>
						<td colspan="5"><div class="d-flex justify-content-center">{$page|raw}</div></td>
					</tr>
				{/if}
			</tbody>
		</table>
	</div>
</div>

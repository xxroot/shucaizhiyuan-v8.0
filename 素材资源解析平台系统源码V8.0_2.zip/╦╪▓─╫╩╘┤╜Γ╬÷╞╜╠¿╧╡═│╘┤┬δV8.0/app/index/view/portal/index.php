{if !$article_list->isEmpty()}
	<div class="bg-white border border-top-0">
		<table class="table table-hover mb-0">
			{foreach $article_list as $article}
				<tr>
					<td><a href="{:url('index/portal/view',['article_id'=>$article['article_id']])}">{$article['subject']}</a></td>
					<td width="160">{$article['update_time']}</td>
				</tr>
			{/foreach}
		</table>
	</div>
{else}
	<div class="card">
		<div class="card-body">暂无数据</div>
	</div>
{/if}
{if $page}
	<div class="d-flex justify-content-center mt-3">{$page|raw}</div>
{/if}

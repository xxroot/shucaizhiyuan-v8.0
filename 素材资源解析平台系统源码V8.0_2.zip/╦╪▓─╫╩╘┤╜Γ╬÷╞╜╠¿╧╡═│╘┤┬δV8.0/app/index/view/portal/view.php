<style type="text/css">.article-message img {max-width:100%;}</style>
<div class="card">
	<div class="card-header text-center">
		{$article ? $article['subject'] : '文章不存在'}
	</div>
	<div class="card-body article-message">{$article ? $article['message']|raw : '文章不存在'}</div>
	{if $article }
		<div class="card-footer d-flex justify-content-between">
			<a href="{:url('index/portal/index')}"><<返回</a>
			<span>更新时间：{$article['update_time']}</span>
		</div>
	{/if}
</div>

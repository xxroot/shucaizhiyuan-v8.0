{include file="index@common/header"}
<body>
	<style type="text/css">html,body {height: 100%;}</style>
	<div class="d-flex justify-content-center d-flex align-items-center h-100 w-100">
		{if empty($_G['setting']['allow_register'])}
			<div class="card text-center" style="width: 400px;">
			    <h5 class="card-header">阿哦~注册通道已关闭</h5>
			    <div class="card-body">
			    	<p>抱歉，目前暂时关闭自助注册通道。</p>
			    	{if $_G['setting']['site_qq']}
			    		<p>需要开户请联系QQ：<span class="badge badge-success">{$_G['setting']['site_qq']}</span></p>
			    	{/if}
			    </div>
	            <div class="card-footer d-flex justify-content-between">
	                <a href="{:url('index/index/index')}">返回首页</a>
	                <a href="{:url('index/account/login')}">前往登录</a>
	            </div>
			</div>
		{else}
			<form autocomplete="off" class="card" style="width: 400px;">
				<h3 class="card-header text-center">用户注册</h3>
				<div class="card-body">
					<div class="form-group">
						<input type="text" class="form-control" name="username" placeholder="账号名称" required autofocus>
					</div>
					{if $_G['setting']['email_register']}
						<div class="form-group">
							<input type="email" class="form-control" name="email" placeholder="邮箱地址" required>
						</div>
						<div class="input-group mb-3">
							<input type="text" class="form-control" name="verify_code" placeholder="验证码">
							<div class="input-group-append">
								<button class="btn input-group-text get-verify-code" type="button">获取验证码</button>
							</div>
						</div>
					{/if}
					<div class="form-group">
						<input type="password" class="form-control" name="password" placeholder="登录密码" required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control" name="password_confirm" placeholder="重复密码" required>
					</div>
					<button class="btn btn-danger btn-block ajax-post" type="submit">注 册</button>
				</div>
				<div class="card-footer d-flex justify-content-between">
					<a href="{:url('index/account/login')}">立即登录</a>
					<a href="{:url('index/account/reset_password')}">找回密码</a>
				</div>
			</form>
			<script type="text/javascript">
				var time_i = 0,time_set;
				function send_timeout(){
					clearTimeout(time_set);
					if(time_i <= 0){
						return $('.get-verify-code').removeClass('disabled').prop('disabled',false).html('获取验证码');
					}
					time_i--;
					$('.get-verify-code').addClass('disabled').prop('disabled',true).html(time_i+' 秒后重发');
					time_set = setTimeout(function(){
						send_timeout();
					},1000);
				}
				$(function(){
					$(document)
						.on('click','.get-verify-code',function(){
							var email = $('input[name="email"]').val();
							if(!$.trim(email)){
								return dialog.msg('请输入绑定邮箱');
							}
							$('.get-verify-code').addClass('disabled').prop('disabled',true).html('发送中');
							$.post(
								'{:url('index/account/get_verify_code')}',
								{email:email,type:'register'},
								function(s){
									if(s.code == 1){
										time_i = 60;
										send_timeout();
									}else{
										dialog.msg(s);
										return $('.get-verify-code').removeClass('disabled').prop('disabled',false).html('获取验证码');
									}
								},
								'json'
							)
						})
				})
			</script>
		{/if}
	</div>
</body>
{include file="index@common/footer"}

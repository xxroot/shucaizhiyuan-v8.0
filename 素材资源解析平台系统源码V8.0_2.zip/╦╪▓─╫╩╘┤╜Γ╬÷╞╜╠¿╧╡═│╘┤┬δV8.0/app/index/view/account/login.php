{include file="index@common/header"}
<body>
	<style type="text/css">html,body {height: 100%;}</style>
	<div class="d-flex justify-content-center d-flex align-items-center h-100 w-100 text-center">
		<form autocomplete="off" class="card" style="width: 400px;">
			<h3 class="card-header text-center">会员登录</h3>
			<div class="card-body">
				<div class="form-group">
					<input type="text" class="form-control" name="account" placeholder="会员账号" required autofocus>
				</div>
				<div class="form-group">
					<input type="password" class="form-control" name="password" placeholder="登陆密码" required>
				</div>
				<div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text p-0"><img src="{:url('index/captcha/index')}" style="height: 36px;cursor: pointer;" onclick='this.src="{:url('index/captcha/index')}?t="+Math.random();'></span>
					</div>
					<input type="text" name="verify_code" class="form-control">
				</div>
				<button class="btn btn-success btn-block ajax-post" type="submit">登 录</button>
			</div>
			<div class="card-footer d-flex justify-content-between">
				<a href="{:url('index/account/register')}">注册账号</a>
				<a href="{:url('index/account/reset_password')}">找回密码</a>
			</div>
		</form>
	</div>
</body>
{include file="index@common/footer"}

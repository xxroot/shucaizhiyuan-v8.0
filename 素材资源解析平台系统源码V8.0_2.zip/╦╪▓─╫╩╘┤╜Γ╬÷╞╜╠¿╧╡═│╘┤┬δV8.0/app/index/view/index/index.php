<div class="input-group input-group-lg parse-form">
	<input type="text" class="form-control parse-link" placeholder="请输入需要下载的资源页面地址">
	<div class="input-group-append">
		<button class="btn input-group-text parse-btn" type="submit">获取资源</button>
	</div>
</div>
<div class="card mt-3 d-none parse-result">
	<div class="card-header">资源解析结果</div>
	<div class="card-body">资源获取中，请稍后...</div>
	<div class="card-footer d-none"></div>
</div>
<div class="row mt-3">
	<div class="col-9">
		{if !$_G['uid']}
			<div class="alert alert-danger">您需要先登陆后才能使用解析功能</div>
		{else}
			<div class="alert alert-success">欢迎您，{$_G['user']['username']}。</div>
		{/if}
		<div class="row m-0 border border-left-0 bg-white">
			{php}$empty_tb = 4 - count($web_site_list)%4;{/php}
			{volist name="web_site_list" id="web_site" key="i"}
				{php}$site_id = $web_site['site_id'];{/php}
				{if empty($_G['uid'])}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="无解析权限">{$web_site['title']}：请先登录</div>
				{elseif empty($site_access[$site_id]) || $site_access[$site_id]['day_times'] < 0 || $site_access[$site_id]['week_times'] < 0 || $site_access[$site_id]['month_times'] < 0 || $site_access[$site_id]['year_times'] < 0 || $site_access[$site_id]['max_times'] < 0}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="无解析权限">{$web_site['title']}：无权限</div>
				{elseif $site_access[$site_id]->getData('out_time') > 0 && $site_access[$site_id]->getData('out_time') <= $Request.time}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="解析权限已过期">{$web_site['title']}：已过期</div>
				{elseif $site_access[$site_id]['day_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['day_times'] <= $download_count[$site_id]['day_used_time']}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="今日解析次数已达上限">{$web_site['title']}：今日上限</div>
				{elseif $site_access[$site_id]['week_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['week_times'] <= $download_count[$site_id]['week_used_time']}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="本周解析次数已达上限">{$web_site['title']}：本周上限</div>
				{elseif $site_access[$site_id]['month_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['month_times'] <= $download_count[$site_id]['month_used_time']}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="本月解析次数已达上限">{$web_site['title']}：本月上限</div>
				{elseif $site_access[$site_id]['year_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['year_times'] <= $download_count[$site_id]['year_used_time']}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="今年解析次数已达上限">{$web_site['title']}：今年上限</div>
				{elseif $site_access[$site_id]['max_times'] > 0 && $site_access[$site_id]['max_times'] <= $site_access[$site_id]['parse_times']}
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="可解析总次数已用完">{$web_site['title']}：次数用完</div>
				{else}
					{php}
						$last = [];
						foreach(['day_times'=>'day_used_time','week_times'=>'week_used_time','month_times'=>'month_used_time','year_times'=>'year_used_time'] as $t => $c){
							if($site_access[$site_id][$t] == 0){
								$last[$t] = '无限';
							}else{
								$last[$t] = $site_access[$site_id][$t] - (!empty($download_count[$site_id]) ? $download_count[$site_id][$c] : 0);
							}
						}
					{/php}
					<div class="col-3 p-3 border-left text-center" data-toggle="tooltip" data-placement="right" data-html="true" data-original-title="
					今日剩余：{$last['day_times']}次<br>
					本周剩余：{$last['week_times']}次<br>
					本月剩余：{$last['month_times']}次<br>
					今年剩余：{$last['year_times']}次<br>
					总数剩余：{$site_access[$site_id]['max_times'] ? ($site_access[$site_id]['max_times'] - $site_access[$site_id]['parse_times']).'次' : '无限次'}">{$web_site['title']}：{$last['day_times']}/{$site_access[$site_id]['day_times']?:'无限'}次</div>
				{/if}
				{if $i % 4 == 0}
					</div>
					<div class="row m-0 border-right border-bottom bg-white">
				{/if}
			{/volist}
			{if $empty_tb > 0 && $empty_tb != 4}
				{for start="0" end="$empty_tb" name="e_i"}
					<div class="col-3 p-3 border-left text-center">&nbsp;</div>
				{/for}
			{/if}
		</div>
	</div>
	<div class="col-3 pl-0">
		<div class="index-user-bar bg-white border border-bottom-0">
			<div class="d-flex justify-content-start align-items-center">
			{volist name="user_nav" id="nav" key="n_i"}
				<a class="w-50 text-center p-3 {if $n_i % 2 != 0}border-right{/if}" href="{$nav['url']}">
					<div>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#{$nav['icon']}"></use>
						</svg>
					</div>
					<div>{$nav['name']}</div>
				</a>
				{if $n_i % 2 == 0}
					</div>
					<div class="d-flex justify-content-start align-items-center border-top">
				{/if}
			{/volist}
			</div>
		</div>
		<div class="card mt-3">
			<div class="card-header d-flex justify-content-between">
			 	<div>帮助中心</div>
			 	<a href="{:url('index/portal/index')}">更多>></a>
			</div>
			<div class="card-body px-0 py-1">
				{foreach $article_list as $article}
					<a class="d-block px-2 py-1" href="{:url('index/portal/view',['article_id'=>$article['article_id']])}">{$article['subject']}</a>
				{/foreach}
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(function(){
		$(document)
			.on('click','.download-btn',function(){
	            var url = '/index/index/redirect.html#!'+ encodeURI($(this).attr('href'));
	            $('body').append('<iframe class="d-none" src="'+url+'"></iframe>');
	            return false;
			})
			.on('click','.parse-btn',function(){
				if($('.parse-btn').hasClass('disabled')){
					return false;
				}
				var link = $.trim($('.parse-link').val());
				if(!link){
					$('.parse-link').focus();
					return dialog.msg('请输入需要解析的网址');
				}
				parse_link(link);
			})
	})
	function parse_link(link,verify_code){
		$('.parse-btn').addClass('disabled').html('获取中...');
		$('.parse-result').removeClass('d-none');
		$.ajax({
			url:'{:url('index/index/parse')}',
			data:{link:link,verify_code:verify_code},
			dataType:'json',
			type:'POST',
			timeout:120000,
			success:function(result){
				if(result.code <= 0){
					$('.parse-result .card-body').html(result.msg);
					$('.parse-result .card-footer').addClass('d-none');
					return dialog.msg(result);
				}else if(result.code == 200){
					var download_html = '';
					$.each(result.msg,function(button_name,download_url){
						download_html += '<a class="btn download-btn btn-danger '+(download_html != '' ? 'ml-3' : '')+'" href="'+download_url+'" >'+button_name+'</a>';
					})
					$('.parse-result .card-footer').removeClass('d-none').html(download_html);
					$('.parse-result .card-body').html(result.info);
				}else if(result.code == 'verify'){
					var op = {
						type: 1,
						title: result.title,
						closeBtn: false,
						area: result.area,
						shade: 0.3,
						id: 'LAY_layuipro',
						resize: false,
						btn: ['确定提交', '取消输入'],
						btnAlign: 'c',
						moveType: 1,
						content: result.content,
						yes: function(){
							dialog.closeAll();
							var verify_code = $('#verify_code').val();
							parse_link(link,verify_code);
						},
						btn2: function(){
							dialog.closeAll();
						}
					};
					if(result.no_button == 1){
						op.btn = false;
					}
					dialog.open(op);
					$('.verify-img-box img').off('click').on('click',function(){
						var verify_code = $(this).data('key');
						dialog.closeAll();
						parse_link(link,verify_code);
					})
					return false;
				}
			},
            complete:function(request, status){
                $('.parse-btn').removeClass('disabled').html('获取资源');
                if(status == 'error'){
                    dialog.msg('页面错误，请联系管理员！');
                }else if(status == 'timeout'){
                    dialog.msg('数据提交超时，请重试！');
                }
            }
		})
	}
</script>

<form class="input-group input-group-lg parse-form" method="post">
	<input type="text" class="form-control" name="keywork" placeholder="请输入关键字" value="{$keywork}">
	<div class="input-group-append">
		<button class="btn input-group-text" type="submit">搜索资源</button>
	</div>
</form>
<div class="row mx-n2">
	{volist name="search_list" id="search" key="i"}
		<div class="col-3 px-2">
			<div class="card mt-3">
				<a class="d-block" href="{$search['from_url']}" target="_blank" style="width: 100%;height: 170px;background-color:#fbfbfb;background-image: url({$search['cover_url']});background-size: 250px;background-position: center;background-repeat: no-repeat;"></a>
				<div class="card-body">
					<a class="card-title d-block mb-0 overflow-hidden text-break" href="{$search['from_url']}" target="_blank" style="height: 42px;">{:str_replace($keywork,'<strong class="text-danger px-1">'.$keywork.'</strong>',$search['subject'])}</a>
				</div>
			</div>
		</div>
	{/volist}
</div>
{if $page}
	<div class="d-flex justify-content-center mt-4">{$page|raw}</div>
{/if}

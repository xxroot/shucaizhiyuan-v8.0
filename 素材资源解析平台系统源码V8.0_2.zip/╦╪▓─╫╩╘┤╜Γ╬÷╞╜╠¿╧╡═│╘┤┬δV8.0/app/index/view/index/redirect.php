{__NOLAYOUT__}
<!DOCTYPE html>
<html>
<head>
	<meta name="referrer" content="never">
	<title></title>
</head>
<body>
<script type="text/javascript">
	var hash = location.hash;
	location.hash = '';
	if(hash.substring(0,2)==='#!') {
	    var url = decodeURI(hash.substring(2));
	    top.location.href = url;
	}
</script>
</body>
</html>

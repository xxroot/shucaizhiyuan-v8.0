{__NOLAYOUT__}
<!DOCTYPE html>
<html>
<head>
	<meta name="referrer" content="never">
	<title></title>
</head>
<body>
	<script type="text/javascript">
		window.location = '{:urldecode($download_url)}';
		setTimeout(function(){window.close();},1000)
	</script>
</body>
</html>

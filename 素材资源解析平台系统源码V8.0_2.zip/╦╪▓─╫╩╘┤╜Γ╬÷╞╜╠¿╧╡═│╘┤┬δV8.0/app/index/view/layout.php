{include file="index@common/header"}
<body class="d-flex flex-column h-100">
  	<div class="alert alert-danger text-center">需要自备服务器、自备素材站点VIP！！！</div>
	<div class="alert alert-danger text-center">测试站后台地址：<a href="{:url('admin/index/index')}">进入后台</a>，测试账号：<strong class="text-danger px-2">admin</strong>，测试密码：<strong class="text-danger px-2">admin888</strong>，测试解析功能需要自备VIP账号</div>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	{if $_G['setting']['site_close']}
		<div class="alert alert-danger">网站当前处于关闭状态，仅管理员可访问，给您带来不便请谅解</div>
	{/if}
	<a class="container d-flex justify-content-center my-5" href="{:request()->domain()}"><img src="static/images/logo.png" style="max-height: 100px;"></a>
	<div class="container mb-5">{__CONTENT__}</div>
	<footer class="p-3 mt-auto border-top">
		<div class="container">
			<p class="text-center">© 2019 - 2099</p>
			<p class="text-center">本站内容完全来自于互联网，并不对其进行任何编辑或修改。本站用户不能侵犯包括他人的著作权在内的知识产权以及其他权利</p>
		</div>
	</footer>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'{:url('index/job/index')}',
				success:function(s){}
			})
		})
	</script>
</body>
{include file="index@common/footer"}

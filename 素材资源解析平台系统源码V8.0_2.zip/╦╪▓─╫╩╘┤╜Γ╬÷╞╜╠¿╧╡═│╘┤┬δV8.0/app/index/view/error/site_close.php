<div class="card">
	<div class="card-header text-center">站点关闭提示</div>
	<div class="card-body">{if $_G['setting']['site_close_tip']}{$_G['setting']['site_close_tip']|raw}{else}网站更新维护中，请稍后访问...{/if}</div>
</div>

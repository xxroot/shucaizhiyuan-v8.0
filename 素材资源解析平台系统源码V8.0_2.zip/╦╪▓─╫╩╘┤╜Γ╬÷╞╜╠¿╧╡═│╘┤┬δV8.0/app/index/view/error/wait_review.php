<div class="card">
	<div class="card-header text-center">账户需要审核</div>
	<div class="card-body">抱歉，您的账户需要管理审核后方可使用，请耐心等待</div>
</div>

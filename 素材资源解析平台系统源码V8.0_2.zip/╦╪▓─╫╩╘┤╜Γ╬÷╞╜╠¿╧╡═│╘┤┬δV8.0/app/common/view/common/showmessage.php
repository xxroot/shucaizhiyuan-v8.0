<?php
switch ($code) {
    case -1:
        $show_class = 'error';
        break;
    case 2:
        $show_class = 'loading';
        break;
    case 1:
        $show_class = 'right';
        break;
    default:
        $show_class = 'info';
}
?>
<div class="container my-5">
    <div class="system-jump-box">
        <div class="system-jump-message system-jump-{$show_class} p-3">
            <h5>
                {switch $code}
	                {case -1}<svg class="iconfont" aria-hidden="true"><use xlink:href="#icon-show-error"></use></svg>{/case}
	                {case 2}<svg class="iconfont" aria-hidden="true"><use xlink:href="#icon-show-loading"></use></svg>{/case}
	                {case 1}<svg class="iconfont" aria-hidden="true"><use xlink:href="#icon-show-right"></use></svg>{/case}
	                {default}<svg class="iconfont" aria-hidden="true"><use xlink:href="#icon-show-info"></use></svg>
                {/switch}
                {:strip_tags($msg)}
            </h5>
            {if $code === 2}
                <div class="progress mb-2">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-success w-100"></div>
                </div>
            {/if}
            <div class="system-jump form-text text-muted">
                页面将在<b id="system-jump-wait">{$wait}</b>秒后跳转，<a id="system-jump-href" href="{$url}">点击这里快速跳转</a>
            </div>
        </div>
    </div>
    <script>
        $(function(){
            var wait = {$wait},
                href = $('#system-jump-href').attr('href');
            if(parseInt(wait) <= 0){
                location.href = href;
            }else{
                var interval = setInterval(function(){
                    wait--;
                    $('#system-jump-wait').html(wait);
                    if(wait <= 0) {
                        clearInterval(interval);
                        location.href = href;
                    };
                }, 1000);
            }
        })
    </script>
</div>

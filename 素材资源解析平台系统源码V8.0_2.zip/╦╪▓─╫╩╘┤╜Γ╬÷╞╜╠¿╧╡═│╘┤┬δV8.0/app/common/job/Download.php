<?php
namespace app\common\job;

use think\queue\Job;

class Download
{

    public function fire(Job $job, $data)
    {
    }

    public function failed($data)
    {
    }

}

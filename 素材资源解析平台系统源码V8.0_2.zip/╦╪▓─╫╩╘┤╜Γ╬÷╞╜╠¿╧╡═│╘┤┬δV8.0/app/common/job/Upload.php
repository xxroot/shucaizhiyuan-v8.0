<?php
namespace app\common\job;

use think\queue\Job;

class Upload
{

    public function fire(Job $job, $data)
    {
    }

    public function failed($data)
    {
    }

}

<?php
namespace app\common\job;

use app\common\model\WebSiteCookie;
use think\facade\Cache;
use think\queue\Job;

class Common
{

    public function fire(Job $job, $data)
    {
        $refresh_time = Cache::get('refresh_time');
        $now          = date('Y-m-d');
        if (empty($refresh_time) || $refresh_time != $now) {
            WebSiteCookie::chunk(100, function ($cookies) {
                $cookies->update(['day_used' => 0]);
            });
            Cache::set('refresh_time', $now);
        }
    }

    public function failed($data)
    {
    }

}

<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;

class UserDownloadTimes extends Model
{
    protected $pk   = 'id';
    protected $type = [
        'create_time' => 'timestamp',
        'update_time' => 'timestamp',
        'out_time'    => 'timestamp',
        'delete_time' => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '失效';
                break;
            case 1:
                return '有效';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function webSite()
    {
        return $this->belongsTo(WebSite::class, 'site_id');
    }
}

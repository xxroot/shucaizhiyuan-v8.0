<?php
namespace app\common\model;

use think\Model;

class UserDownloadCount extends Model
{
    protected $pk = 'count_id';

    public function user()
    {
        return $this->belongsTo(UserMain::class, 'uid');
    }
}

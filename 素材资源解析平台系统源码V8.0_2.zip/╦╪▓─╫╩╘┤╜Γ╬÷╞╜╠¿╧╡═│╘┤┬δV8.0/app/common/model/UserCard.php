<?php
namespace app\common\model;

use app\common\model\UserDownloadTimes;
use app\common\model\UserMain;
use app\common\model\UserSiteAccess;
use think\facade\Db;
use think\facade\Request;
use think\Model;

class UserCard extends Model
{
    protected $pk        = 'card_id';
    protected $json      = ['vip_access', 'download_times'];
    protected $jsonAssoc = true;
    protected $type      = [
        'create_time' => 'timestamp',
        'update_time' => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
        $data->status      = 1;
    }

    public function getTypeTextAttr($value, $data)
    {
        switch ($data['type']) {
            case 'vip':
                return 'VIP升级';
                break;
            case 'download':
                return '下载次数';
                break;
            case 'balance':
                return '账户余额';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function getOutTimeFormatAttr($value, $data)
    {
        if ($data['out_time'] <= 0) {
            return '永久';
        }
        return date('Y-m-d H:i:s', $data['out_time']);
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case -1:
                return '失效';
                break;
            case 0:
                return '已使用';
                break;
            case 1:
                return '可用';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function exchange_card($uid = 0)
    {
        if ($this->getAttr('type') == 'balance') {
            UserMain::where('uid', '=', $uid)->update([
                'balance' => Db::raw('balance+' . $this->getAttr('balance')),
            ]);
        } else if ($this->getAttr('type') == 'vip') {
            $vip_access = $this->getAttr('vip_access') ?: [];
            foreach (UserSiteAccess::where('uid', '=', $uid)->select() as $access) {
                if (empty($vip_access[$access['site_id']])) {
                    continue;
                }
                $is_update = false;
                foreach (['day_times', 'week_times', 'month_times', 'year_times', 'max_times', 'out_time'] as $key) {
                    if ($access->$key == 0 || !isset($vip_access[$access['site_id']][$key])) {
                        continue;
                    }
                    if ($vip_access[$access['site_id']][$key] == 0) {
                        $access->$key = 0;
                    } else if ($vip_access[$access['site_id']][$key] > 0) {
                        if ($key == 'out_time') {
                            $access->$key = ($access->$key <= Request::time() ? Request::time() : $access->$key) + $vip_access[$access['site_id']][$key] * 3600;
                        } else {
                            $access->$key = $access->$key < 0 ? $vip_access[$access['site_id']][$key] : $vip_access[$access['site_id']][$key] + $access->$key;
                        }
                    }
                    $is_update = true;
                }
                if ($is_update === true) {
                    $access->save();
                }
                unset($vip_access[$access['site_id']]);
            }
            if (!empty($vip_access)) {
                foreach ($vip_access as $site_id => $access) {
                    if (empty($site_id)) {
                        continue;
                    }
                    $av_times = [];
                    foreach (['day_times', 'week_times', 'month_times', 'year_times', 'max_times'] as $time_key) {
                        if (isset($access[$time_key]) && $access[$time_key] > 0) {
                            $av_times[] = $access[$time_key];
                        }
                    }

                    $int_times = empty($av_times) ? -1 : max($av_times);

                    $day_times = $week_times = $month_times = $year_times = $max_times = 0;
                    foreach (['day_times', 'week_times', 'month_times', 'year_times', 'max_times'] as $time_key) {

                        if (isset($access[$time_key])) {
                            if ($access[$time_key] < 0) {
                                ${$time_key} = $int_times;
                            } else if ($access[$time_key] > 0) {
                                ${$time_key} = $access[$time_key];
                            }
                        }
                    }
                    $out_time = 0;
                    if (isset($access['out_time'])) {
                        if ($access['out_time'] < 0) {
                            if ($int_times < 0) {
                                $out_time = -1;
                            } else if ($int_times > 0) {
                                $out_time = 72;
                            } else {
                                $out_time = 0;
                            }
                        } else if ($access['out_time'] > 0) {
                            $out_time = $access['out_time'];
                        }
                    }
                    UserSiteAccess::create([
                        'uid'         => $uid,
                        'site_id'     => $site_id,
                        'day_times'   => $day_times,
                        'week_times'  => $week_times,
                        'month_times' => $month_times,
                        'year_times'  => $year_times,
                        'max_times'   => $max_times,
                        'out_time'    => $out_time,
                    ]);
                }
            }
        } else if ($this->getAttr('type') == 'download') {
            $data           = [];
            $download_times = $this->getAttr('download_times') ?: [];
            foreach ($download_times as $site_id => $value) {
                if ($value['times'] > 0 && $value['out_time'] >= 0) {
                    $data[] = [
                        'uid'      => $uid,
                        'site_id'  => $site_id,
                        'times'    => $value['times'],
                        'from'     => 'buy',
                        'summary'  => '购买下载套餐',
                        'out_time' => $value['out_time'] == 0 ? 0 : (Request::time() + $value['out_time'] * 3600),
                        'status'   => 1,
                    ];
                }
            }
            if (!empty($data)) {
                (new UserDownloadTimes)->saveAll($data);
            }
        }
    }
}

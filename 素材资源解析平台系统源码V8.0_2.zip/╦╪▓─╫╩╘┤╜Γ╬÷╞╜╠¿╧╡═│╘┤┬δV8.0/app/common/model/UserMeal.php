<?php
namespace app\common\model;

use think\Model;

class UserMeal extends Model
{
    protected $pk        = 'meal_id';
    protected $json      = ['vip_access', 'download_times', 'proxy_access'];
    protected $jsonAssoc = true;

    public function getTypeTextAttr($value, $data)
    {
        switch ($data['type']) {
            case 'vip':
                return 'VIP升级';
                break;
            case 'download':
                return '下载次数';
                break;
            case 'proxy':
                return '代理开户';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '禁用';
                break;
            case 1:
                return '显示';
                break;

            default:
                return '未知';
                break;
        }
    }
}

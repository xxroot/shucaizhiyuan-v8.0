<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;
use think\model\concern\SoftDelete;

class AttachMain extends Model
{
    use SoftDelete;
    protected $pk                = 'attach_id';
    protected $deleteTime        = 'delete_time';
    protected $defaultSoftDelete = 0;
    protected $type              = [
        'create_time' => 'timestamp',
        'update_time' => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
        $data->local_file  = md5(Request::time() . random(10)) . '.temp';
    }

    public static function onBeforeUpdate($data)
    {
        $data->update_time = Request::time();
        $data->update_ip   = Request::ip();
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '新建';
                break;
            case 1:
                return '保存中';
                break;
            case 2:
                return '已保存';
                break;
            case 3:
                return '上传中';
                break;
            case 4:
                return '完成';
                break;

            default:
                return '未知';
                break;
        }
    }
}

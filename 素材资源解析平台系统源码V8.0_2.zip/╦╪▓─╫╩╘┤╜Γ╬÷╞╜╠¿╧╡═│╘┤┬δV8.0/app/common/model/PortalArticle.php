<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;
use think\model\concern\SoftDelete;

class PortalArticle extends Model
{
    use SoftDelete;
    protected $pk                = 'article_id';
    protected $deleteTime        = 'delete_time';
    protected $defaultSoftDelete = 0;
    protected $type              = [
        'create_time' => 'timestamp',
        'update_time' => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
    }

    public static function onBeforeUpdate($data)
    {
        $data->update_time = Request::time();
        $data->update_ip   = Request::ip();
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '隐藏';
                break;
            case 1:
                return '显示';
                break;

            default:
                return '未知';
                break;
        }
    }
}

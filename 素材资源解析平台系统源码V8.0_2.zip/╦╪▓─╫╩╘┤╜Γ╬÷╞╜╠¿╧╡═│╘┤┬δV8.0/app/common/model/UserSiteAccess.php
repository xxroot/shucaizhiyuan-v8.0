<?php
namespace app\common\model;

use think\Model;

class UserSiteAccess extends Model
{
    protected $type = [
        'out_time' => 'timestamp',
    ];
}

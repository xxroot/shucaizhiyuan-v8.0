<?php
namespace app\common\model;

use think\Model;

class WebSite extends Model
{
    protected $pk        = 'site_id';
    protected $json      = ['cookies_count', 'param'];
    protected $jsonAssoc = true;

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '禁用';
                break;
            case 1:
                return '启用';
                break;

            default:
                return '未知';
                break;
        }
    }
}

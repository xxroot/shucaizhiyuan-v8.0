<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;
use think\model\concern\SoftDelete;

class UserNotification extends Model
{
    use SoftDelete;
    protected $pk                = 'id';
    protected $deleteTime        = 'delete_time';
    protected $defaultSoftDelete = 0;

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
    }
}

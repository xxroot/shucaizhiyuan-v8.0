<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;

class VerifyCode extends Model
{
    protected $pk   = 'id';
    protected $type = [
        'create_time' => 'timestamp',
        'out_time'    => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->code        = random(6, 1);
    }

    public function getOutTimeAttr($value, $data)
    {
        global $_G;
        return $data['create_time'] + $_G['setting']['verify_code_time'] * 60;
    }
}

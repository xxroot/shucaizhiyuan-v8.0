<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;
use think\model\concern\SoftDelete;

class PortalShare extends Model
{
    use SoftDelete;
    protected $pk                = 'share_id';
    protected $deleteTime        = 'delete_time';
    protected $defaultSoftDelete = 0;
    protected $type              = [
        'create_time' => 'timestamp',
        'update_time' => 'timestamp',
        'delete_time' => 'timestamp',
    ];
    protected $json      = ['reward'];
    protected $jsonAssoc = true;

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case -1:
                return '禁止';
                break;
            case 0:
                return '待审核';
                break;
            case 1:
                return '有效';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function getCoverUrlAttr($value, $data)
    {
        return empty($data['cover']) ? 'static/images/nocover.jpg' : $data['cover'];
    }

    public function user()
    {
        return $this->belongsTo(UserMain::class, 'uid');
    }

    public function attach()
    {
        return $this->belongsTo(AttachMain::class, 'attach_id');
    }
}

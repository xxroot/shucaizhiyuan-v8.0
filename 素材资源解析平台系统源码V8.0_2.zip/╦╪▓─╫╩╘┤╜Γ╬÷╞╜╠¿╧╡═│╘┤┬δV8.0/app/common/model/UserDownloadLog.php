<?php
namespace app\common\model;

use think\facade\Request;
use think\Model;

class UserDownloadLog extends Model
{
    protected $pk   = 'log_id';
    protected $type = [
        'create_time' => 'timestamp',
    ];

    public static function onBeforeInsert($data)
    {
        $data->create_time = Request::time();
        $data->create_ip   = Request::ip();
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '失败';
                break;
            case 1:
                return '成功';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function webSite()
    {
        return $this->belongsTo(WebSite::class, 'site_id');
    }

    public function user()
    {
        return $this->belongsTo(UserMain::class, 'uid');
    }
}

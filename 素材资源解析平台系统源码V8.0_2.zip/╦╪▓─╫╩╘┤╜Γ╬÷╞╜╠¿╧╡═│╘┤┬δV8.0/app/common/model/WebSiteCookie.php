<?php
namespace app\common\model;

use think\Model;

class WebSiteCookie extends Model
{
    protected $pk = 'cookie_id';

    public function getAvailableTextAttr($value, $data)
    {
        switch ($data['available']) {
            case 0:
                return '失效';
                break;
            case 1:
                return '有效';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function getAvailableClassAttr($value, $data)
    {
        switch ($data['available']) {
            case 0:
                return 'text-danger';
                break;
            case 1:
                return 'text-success';
                break;

            default:
                return 'text-info';
                break;
        }
    }

    public function getStatusTextAttr($value, $data)
    {
        switch ($data['status']) {
            case 0:
                return '禁用';
                break;
            case 1:
                return '启用';
                break;

            default:
                return '未知';
                break;
        }
    }

    public function webSite()
    {
        return $this->belongsTo(WebSite::class, 'site_id');
    }
}

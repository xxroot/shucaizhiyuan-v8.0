<?php
namespace app\common\model;

use think\facade\Cache;
use think\Model;

class CommonSetting extends Model
{
    protected $pk = 'key';

    public function getAll()
    {
        $setting = [];
        foreach (self::select() as $data) {
            $value                 = json_decode($data['value'], true);
            $setting[$data['key']] = is_null($value) ? $data['value'] : $value;
        }
        $setting['alipay_switch'] = !empty($setting['alipay_switch']) && !empty($setting['alipay_app_id']) && !empty($setting['alipay_merchant_private_key']) && !empty($setting['alipay_alipay_public_key']);
        $setting['wxpay_switch']  = !empty($setting['wxpay_switch']) && !empty($setting['wxpay_app_id']) && !empty($setting['wxpay_merchant_id']) && !empty($setting['wxpay_key']);
        $setting['qqpay_switch']  = !empty($setting['qqpay_switch']) && !empty($setting['qqpay_mch_id']) && !empty($setting['qqpay_key']);
        Cache::set('common_setting', $setting);
        return $setting;
    }
}

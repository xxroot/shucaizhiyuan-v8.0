-- MySQL dump 10.13  Distrib 5.6.46, for Linux (x86_64)
--
-- Host: localhost    Database: lzdh.511f.cn
-- ------------------------------------------------------
-- Server version	5.6.46-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attach_main`
--

DROP TABLE IF EXISTS `attach_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attach_main` (
  `attach_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建者UID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '站点ID',
  `from` varchar(255) NOT NULL DEFAULT '' COMMENT '文件来源，share-用户分享，parse-解析获取',
  `request_url` varchar(2500) NOT NULL DEFAULT '' COMMENT '请求url地址',
  `response_url` varchar(2500) NOT NULL DEFAULT '' COMMENT '返回的下载地址',
  `site_code` varchar(1000) NOT NULL DEFAULT '' COMMENT '请求地址唯一标识',
  `site_code_type` varchar(1000) NOT NULL DEFAULT '' COMMENT '解析地址类型',
  `filename` varchar(2500) NOT NULL DEFAULT '' COMMENT '文件名称',
  `filesize` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `savename` varchar(2500) NOT NULL DEFAULT '' COMMENT '保存路径',
  `downloads` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '访问时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '访问ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后访问时间',
  `update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '最后访问ip',
  `local_file` varchar(255) NOT NULL DEFAULT '' COMMENT '本地文件',
  `download_time` varchar(20) NOT NULL DEFAULT '' COMMENT '下载耗时',
  `upload_time` varchar(20) NOT NULL DEFAULT '' COMMENT '上传耗时',
  `button_name` varchar(255) NOT NULL DEFAULT '' COMMENT '下载按钮名称',
  `queue_error` text NOT NULL COMMENT '队列执行错误信息',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `cookie_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '获取该数据使用的COOKIE_ID',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-新建，1-下载中，2-已下载，3-上传中，4-上传成功',
  PRIMARY KEY (`attach_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attach_main`
--

LOCK TABLES `attach_main` WRITE;
/*!40000 ALTER TABLE `attach_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `attach_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_queue`
--

DROP TABLE IF EXISTS `common_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `queue` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
  `payload` longtext NOT NULL COMMENT '执行任务文件',
  `attempts` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '已执行次数',
  `reserved` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '重发次数',
  `reserved_at` int(11) unsigned DEFAULT NULL COMMENT '上次执行时间',
  `available_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下次执行时间',
  `created_at` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='队列';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_queue`
--

LOCK TABLES `common_queue` WRITE;
/*!40000 ALTER TABLE `common_queue` DISABLE KEYS */;
INSERT INTO `common_queue` VALUES (1,'download','{\"job\":\"common\\/Download\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}',0,0,NULL,1561960408,1561960408,1),(2,'upload','{\"job\":\"common\\/Upload\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}',0,0,NULL,1561960408,1561960408,1),(3,'default','{\"job\":\"common\\/Common\",\"maxTries\":null,\"timeout\":null,\"data\":\"\"}',0,0,NULL,1561960408,1561960408,1);
/*!40000 ALTER TABLE `common_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_setting`
--

DROP TABLE IF EXISTS `common_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_setting` (
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '变量名',
  `value` mediumtext NOT NULL COMMENT '变量值',
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='全局设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_setting`
--

LOCK TABLES `common_setting` WRITE;
/*!40000 ALTER TABLE `common_setting` DISABLE KEYS */;
INSERT INTO `common_setting` VALUES ('site_name','百度一下'),('site_close','0'),('site_qq','892409995'),('site_close_tip','<p>网站维护中，请稍后再访问~</p>'),('allow_register','1'),('must_login','0'),('allow_same_login','0'),('verify_code_time','30'),('AccessKeyId',''),('AccessKeySecret',''),('Endpoint','http://oss-cn-shanghai.aliyuncs.com'),('Bucket',''),('auto_save_type',''),('parse_space_time','60'),('email_host','smtp.qq.com'),('email_port','465'),('email_username',''),('email_password',''),('email_fromname',''),('email_reset_password','0'),('email_reset_content','<p>您申请的重置账户登陆密码验证码：<span style=\"color: rgb(40, 167, 69); font-size: 11.2px; font-weight: bolder;\">[REGISTER_CODE]</span>，该验证码 30 分钟内有效。如非本人操作请忽略。</p>'),('email_register','0'),('email_register_content','<p>您申请的账户注册验证码：<span style=\"color: rgb(40, 167, 69); font-size: 11.2px; font-weight: bolder;\">[REGISTER_CODE]</span>，该验证码 30 分钟内有效。如非本人操作请忽略。</p>'),('user_fission','1'),('user_fission_time','48'),('user_fission_lv','3'),('user_fission_reward','{\"times\":{\"27\":\"1\",\"26\":\"1\",\"25\":\"1\",\"24\":\"1\",\"23\":\"1\",\"22\":\"1\",\"21\":\"1\",\"20\":\"1\",\"19\":\"1\",\"18\":\"1\",\"17\":\"1\",\"16\":\"1\",\"15\":\"1\",\"14\":\"1\",\"13\":\"1\",\"11\":\"1\",\"10\":\"1\",\"9\":\"1\",\"8\":\"1\",\"7\":\"1\",\"6\":\"1\",\"5\":\"1\",\"4\":\"1\",\"3\":\"1\",\"2\":\"1\",\"1\":\"1\"},\"out_time\":{\"27\":\"8760\",\"26\":\"8760\",\"25\":\"8760\",\"24\":\"8760\",\"23\":\"8760\",\"22\":\"8760\",\"21\":\"8760\",\"20\":\"8760\",\"19\":\"8760\",\"18\":\"8760\",\"17\":\"8760\",\"16\":\"8760\",\"15\":\"8760\",\"14\":\"8760\",\"13\":\"8760\",\"11\":\"8760\",\"10\":\"8760\",\"9\":\"8760\",\"8\":\"8760\",\"7\":\"8760\",\"6\":\"8760\",\"5\":\"8760\",\"4\":\"8760\",\"3\":\"8760\",\"2\":\"8760\",\"1\":\"8760\"}}'),('user_fission_reward_lv','3'),('user_fission_reward_day_times','10'),('user_fission_reward_max_times','20'),('api_domain','http://39.100.225.5/'),('recharge_all','0'),('withdraw_all','0'),('register_review','0'),('alipay_switch','1'),('alipay_app_id',''),('alipay_merchant_private_key',''),('alipay_alipay_public_key',''),('wxpay_switch','1'),('wxpay_app_id',''),('wxpay_merchant_id',''),('wxpay_key',''),('wxpay_app_secret',''),('qqpay_switch','1'),('qqpay_mch_id',''),('qqpay_key',''),('min_recharge_price','10'),('max_recharge_price','1000'),('search_resources','0'),('version','20191001002');
/*!40000 ALTER TABLE `common_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_article`
--

DROP TABLE IF EXISTS `portal_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_article` (
  `article_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'uid',
  `subject` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
  `message` text NOT NULL COMMENT '详细内容',
  `views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-隐藏，1-显示',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='门户文章';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_article`
--

LOCK TABLES `portal_article` WRITE;
/*!40000 ALTER TABLE `portal_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_share`
--

DROP TABLE IF EXISTS `portal_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_share` (
  `share_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'uid',
  `attach_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '附件ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '源素材站',
  `from_url` varchar(1000) NOT NULL DEFAULT '' COMMENT '文件来源地址',
  `subject` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
  `message` text NOT NULL COMMENT '分享内容',
  `reward` text NOT NULL COMMENT '奖励内容',
  `views` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-禁止，0-待审核，1-有效',
  PRIMARY KEY (`share_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件分享';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_share`
--

LOCK TABLES `portal_share` WRITE;
/*!40000 ALTER TABLE `portal_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_card`
--

DROP TABLE IF EXISTS `user_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_card` (
  `card_id` varchar(255) NOT NULL DEFAULT '' COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '生成者',
  `use_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '使用者',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
  `vip_access` text NOT NULL COMMENT 'VIP权限',
  `download_times` text NOT NULL COMMENT '下载权限',
  `balance` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '增加余额',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '使用ip',
  `out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1失效，0-已使用，1-可用',
  PRIMARY KEY (`card_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='充值卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_card`
--

LOCK TABLES `user_card` WRITE;
/*!40000 ALTER TABLE `user_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_download_count`
--

DROP TABLE IF EXISTS `user_download_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_download_count` (
  `count_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '站点ID',
  `day_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '今日解析次数',
  `week_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '本周解析次数',
  `month_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '本月解析次数',
  `year_used_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '今年解析次数',
  `day_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '日刷新时间',
  `week_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '周刷新时间',
  `month_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '月刷新时间',
  `year_refresh_time` varchar(255) NOT NULL DEFAULT '' COMMENT '年刷新时间',
  PRIMARY KEY (`count_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='解析统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_download_count`
--

LOCK TABLES `user_download_count` WRITE;
/*!40000 ALTER TABLE `user_download_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_download_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_download_log`
--

DROP TABLE IF EXISTS `user_download_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_download_log` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `site_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '站点ID',
  `parse_url` varchar(255) NOT NULL DEFAULT '' COMMENT '解析地址',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '解析时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '解析ip',
  `use_times` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '解析消耗次数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-解析失败，1-解析成功',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='解析记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_download_log`
--

LOCK TABLES `user_download_log` WRITE;
/*!40000 ALTER TABLE `user_download_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_download_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_download_times`
--

DROP TABLE IF EXISTS `user_download_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_download_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
  `site_id` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '奖励的站点',
  `times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '奖励次数',
  `used_times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '该奖励已使用次数',
  `from` varchar(50) NOT NULL DEFAULT '' COMMENT '奖励来源类型',
  `summary` varchar(255) NOT NULL DEFAULT '' COMMENT '奖励说明',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `update_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '更新ip',
  `out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-无效，1-有效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='奖励次数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_download_times`
--

LOCK TABLES `user_download_times` WRITE;
/*!40000 ALTER TABLE `user_download_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_download_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_fission`
--

DROP TABLE IF EXISTS `user_fission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_fission` (
  `spread_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '推广用户UID',
  `fission_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '裂变新用户UID',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '创建ip',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `floor` smallint(6) unsigned NOT NULL DEFAULT '1' COMMENT '层级数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='裂变推广绑定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_fission`
--

LOCK TABLES `user_fission` WRITE;
/*!40000 ALTER TABLE `user_fission` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_fission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_main`
--

DROP TABLE IF EXISTS `user_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_main` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'UID',
  `up_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级推广用户uid',
  `proxy_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级代理用户uid',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '登录密码',
  `password_see` varchar(255) NOT NULL DEFAULT '' COMMENT '登录密码',
  `qq` varchar(50) NOT NULL DEFAULT '' COMMENT 'QQ号',
  `weixin` varchar(50) NOT NULL DEFAULT '' COMMENT '微信号',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `email_verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未认证，1已认证',
  `mobile_verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未认证，1已认证',
  `balance` decimal(9,2) NOT NULL DEFAULT '0.00' COMMENT '账户余额',
  `new_notice` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '未读通知',
  `register_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `register_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '注册ip',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后访问时间',
  `last_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '最后访问IP',
  `parse_times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '已解析总次数',
  `parse_max_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '所有站点拥有解析总次数',
  `type` enum('system','proxy','member') NOT NULL DEFAULT 'member' COMMENT '账户类型',
  `discount` varchar(20) NOT NULL DEFAULT '10' COMMENT '购买折扣价格',
  `reset_times` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '权限刷新时间',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '-2-已注销，-1-禁止访问，0-待审核，1-正常',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='站点用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_main`
--

LOCK TABLES `user_main` WRITE;
/*!40000 ALTER TABLE `user_main` DISABLE KEYS */;
INSERT INTO `user_main` VALUES (1,0,0,'admin','$2y$10$xPsbuB41FV5NzFM.FRq2pORA1gz4CQt0s2Y/KX2BR4T/5pkeI.TRO','admin888','','xxxxx.com','admin@xxxxx.com','',0,0,0.00,0,1549782892,'::1',1576475926,'119.1.0.40',0,0,'system','0',0,0,1);
/*!40000 ALTER TABLE `user_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_meal`
--

DROP TABLE IF EXISTS `user_meal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_meal` (
  `meal_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
  `summary` varchar(500) NOT NULL DEFAULT '' COMMENT '说明',
  `price` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `vip_access` text NOT NULL COMMENT 'VIP权限',
  `download_times` text NOT NULL COMMENT '下载权限',
  `proxy_access` text NOT NULL COMMENT '代理开户套餐',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-禁用，1-启用',
  PRIMARY KEY (`meal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='运营套餐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_meal`
--

LOCK TABLES `user_meal` WRITE;
/*!40000 ALTER TABLE `user_meal` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_meal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_meal_order`
--

DROP TABLE IF EXISTS `user_meal_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_meal_order` (
  `order_id` varchar(50) NOT NULL DEFAULT '' COMMENT '流水号',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
  `body` varchar(500) NOT NULL DEFAULT '' COMMENT '说明',
  `buy_number` smallint(6) NOT NULL DEFAULT '0' COMMENT '购买份数',
  `price` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `vip_access` text NOT NULL COMMENT 'VIP权限',
  `download_times` text NOT NULL COMMENT '下载权限',
  `proxy_access` text NOT NULL COMMENT '代理开户套餐',
  `payinfo` text NOT NULL COMMENT '支付平台返回信息',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `pay_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-无效，0-待支付，1-已完成',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户套餐订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_meal_order`
--

LOCK TABLES `user_meal_order` WRITE;
/*!40000 ALTER TABLE `user_meal_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_meal_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification`
--

DROP TABLE IF EXISTS `user_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `from_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建用户id',
  `to_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收用户id',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型，system-系统通知,letter-私信',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `message` text NOT NULL COMMENT '详细内容',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发送ip',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  `read_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '阅读ip',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-已阅读，1-未读',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='消息通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification`
--

LOCK TABLES `user_notification` WRITE;
/*!40000 ALTER TABLE `user_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_recharge`
--

DROP TABLE IF EXISTS `user_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_recharge` (
  `recharge_id` varchar(255) NOT NULL DEFAULT '' COMMENT '主键',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
  `price` decimal(9,2) NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `subject` varchar(255) NOT NULL DEFAULT '' COMMENT '充值说明',
  `body` varchar(255) NOT NULL DEFAULT '' COMMENT '充值说明',
  `payinfo` text NOT NULL COMMENT '支付平台返回信息',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发生时间',
  `create_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '发生ip',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `out_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `pay_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `delete_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1-无效，0-待支付，1-已完成',
  PRIMARY KEY (`recharge_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户充值订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_recharge`
--

LOCK TABLES `user_recharge` WRITE;
/*!40000 ALTER TABLE `user_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reward`
--

DROP TABLE IF EXISTS `user_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_reward` (
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
  `day` varchar(50) NOT NULL DEFAULT '' COMMENT '日期',
  `times` smallint(6) NOT NULL DEFAULT '0' COMMENT '当日已获得奖励次数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='奖励统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reward`
--

LOCK TABLES `user_reward` WRITE;
/*!40000 ALTER TABLE `user_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_site_access`
--

DROP TABLE IF EXISTS `user_site_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_site_access` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'UID',
  `site_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '素材站id',
  `parse_times` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '已解析次数',
  `day_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '每日可解析次数',
  `week_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '每周可解析次数',
  `month_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '每月可解析次数',
  `year_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '每年可解析次数',
  `max_times` mediumint(8) NOT NULL DEFAULT '0' COMMENT '最大可解析次数',
  `out_time` varchar(20) NOT NULL DEFAULT '0' COMMENT '该站点权限过期时间,-1失效，0永久，时间参数表示过期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_site_id` (`uid`,`site_id`),
  KEY `uid` (`uid`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COMMENT='用户解析权限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_site_access`
--

LOCK TABLES `user_site_access` WRITE;
/*!40000 ALTER TABLE `user_site_access` DISABLE KEYS */;
INSERT INTO `user_site_access` VALUES (78,1,1,0,0,0,0,0,0,'1574197713'),(77,1,2,0,0,0,0,0,0,'0'),(76,1,3,0,0,0,0,0,0,'0'),(75,1,4,0,0,0,0,0,0,'0'),(74,1,5,0,0,0,0,0,0,'0'),(73,1,6,0,0,0,0,0,0,'0'),(72,1,7,0,0,0,0,0,0,'0'),(71,1,8,0,0,0,0,0,0,'0'),(70,1,9,0,0,0,0,0,0,'0'),(69,1,10,0,0,0,0,0,0,'0'),(68,1,11,0,0,0,0,0,0,'0'),(67,1,13,0,0,0,0,0,0,'0'),(66,1,14,0,0,0,0,0,0,'0'),(65,1,15,0,0,0,0,0,0,'0'),(64,1,16,0,0,0,0,0,0,'0'),(63,1,17,0,0,0,0,0,0,'0'),(62,1,18,0,0,0,0,0,0,'0'),(61,1,19,0,0,0,0,0,0,'0'),(60,1,20,0,0,0,0,0,0,'0'),(59,1,21,0,0,0,0,0,0,'0'),(58,1,22,0,0,0,0,0,0,'0'),(57,1,23,0,0,0,0,0,0,'0'),(56,1,24,0,0,0,0,0,0,'0'),(55,1,25,0,0,0,0,0,0,'0'),(54,1,26,0,0,0,0,0,0,'0'),(53,1,27,0,0,0,0,0,0,'0');
/*!40000 ALTER TABLE `user_site_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_code`
--

DROP TABLE IF EXISTS `verify_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'uid',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `mobile` varchar(255) NOT NULL DEFAULT '' COMMENT '手机号',
  `code` varchar(255) NOT NULL DEFAULT '' COMMENT '验证码代码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-无效，1-有效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='验证码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_code`
--

LOCK TABLES `verify_code` WRITE;
/*!40000 ALTER TABLE `verify_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `verify_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_site`
--

DROP TABLE IF EXISTS `web_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_site` (
  `site_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '网站名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '官网地址',
  `url_regular` varchar(255) NOT NULL DEFAULT '' COMMENT '特征码',
  `demo_url` varchar(255) NOT NULL DEFAULT '' COMMENT '下载地址',
  `cookies_count` varchar(255) NOT NULL DEFAULT '' COMMENT 'cookie统计',
  `param` text NOT NULL COMMENT '额外配置参数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-禁用，1-启用',
  PRIMARY KEY (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='资源站点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_site`
--

LOCK TABLES `web_site` WRITE;
/*!40000 ALTER TABLE `web_site` DISABLE KEYS */;
INSERT INTO `web_site` VALUES (1,'觅元素','http://www.51yuansu.com/','51yuansu.com','http://www.51yuansu.com/sc/lcvnlvrkig.html','{\"available\":0,\"all\":0}','[]',1),(2,'我图网','https://www.ooopic.com/','ooopic.com','https://www.ooopic.com/pic_27796570.html','{\"available\":0,\"all\":0}','[]',1),(3,'千图网','https://www.58pic.com/','58pic.com','http://www.58pic.com/newpic/33513860.html','{\"available\":0,\"all\":0}','[]',1),(4,'昵图网','http://www.nipic.com/','nipic.com','http://www.nipic.com/show/22717419.html','{\"available\":0,\"all\":0}','[]',1),(5,'90设计','http://90sheji.com/','90sheji.com','http://90sheji.com/sucai/22176591.html','{\"available\":0,\"all\":0}','[]',1),(6,'千库网','https://588ku.com/','588ku.com','https://588ku.com/ycpng/11716645.html','{\"available\":0,\"all\":0}','[]',1),(7,'包图网','https://ibaotu.com/','ibaotu.com','https://ibaotu.com/sucai/18002368.html','{\"available\":0,\"all\":0}','[]',1),(8,'摄图网','http://699pic.com/','699pic.com','http://699pic.com/tupian-501104528.html','{\"available\":0,\"all\":0}','[]',1),(9,'CSDN下载','https://download.csdn.net/','download.csdn.net','https://download.csdn.net/download/qgy879765368/10961370','{\"available\":0,\"all\":0}','[]',1),(10,'稻壳儿','http://www.docer.com/','docer.com','http://detail.docer.com/4512476.html','{\"available\":0,\"all\":0}','[]',1),(11,'百度文库','https://wenku.baidu.com/','wenku.baidu.com','https://wenku.baidu.com/view/72264a1b6d85ec3a87c24028915f804d2b16877f.html','{\"available\":0,\"all\":0}','[]',1),(13,'熊猫办公','http://www.tukuppt.com/','tukuppt.com','http://www.tukuppt.com/muban/pgxdkwmz.html','{\"available\":0,\"all\":0}','[]',1),(14,'92素材','http://www.92sucai.com/','92sucai.com','http://www.92sucai.com/ae/31712.html','{\"available\":0,\"all\":0}','[]',1),(15,'演界网','http://www.yanj.cn/','yanj.cn','http://www.yanj.cn/goods-177783.html','{\"available\":0,\"all\":0}','[]',1),(16,'彼岸图','http://pic.netbian.com/','pic.netbian.com','http://pic.netbian.com/tupian/23507.html','{\"available\":0,\"all\":0}','[]',1),(17,'绘艺素材','https://www.huiyi8.com/','huiyi8.com','https://www.huiyi8.com/sc/1100690.html','{\"available\":0,\"all\":0}','[]',1),(18,'图品汇','https://www.88tph.com/','88tph.com','https://www.88tph.com/sucai/12508222.html','{\"available\":0,\"all\":0}','[]',1),(19,'觅知网','https://www.51miz.com/','51miz.com','http://www.51miz.com/sucai/999440.html','{\"available\":0,\"all\":0}','[]',1),(20,'六图网','https://www.16pic.com/','16pic.com','https://www.16pic.com/pic/pic_8717237.html','{\"available\":0,\"all\":0}','[]',1),(21,'全图网','https://www.125pic.com/','125pic.com','http://www.125pic.com/sucai/104678','{\"available\":0,\"all\":0}','[]',1),(22,'风云办公','http://ppt.dwuva.com/','ppt.dwuva.com','http://ppt.dwuva.com/scb/a6b61897.html','{\"available\":0,\"all\":0}','[]',1),(23,'风云办公2','http://www.ppt118.com/','ppt118.com','http://www.ppt118.com/scb/a6b61897.html','{\"available\":0,\"all\":0}','[]',1),(24,'易图网','http://www.yipic.cn/','yipic.cn','http://www.yipic.cn/sucai/4413479.html','{\"available\":0,\"all\":0}','[]',1),(25,'图行天下','http://www.photophoto.cn/','photophoto.cn','http://www.photophoto.cn/pic/32218471.html','{\"available\":0,\"all\":0}','[]',1),(26,'万素网','http://669pic.com/','669pic.com','http://669pic.com/sc/173705.html','{\"available\":0,\"all\":0}','[]',1),(27,'快图网','http://www.kuaipng.com/','kuaipng.com','http://www.kuaipng.com/sucai/20889.html','{\"available\":0,\"all\":0}','[]',1);
/*!40000 ALTER TABLE `web_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_site_cookie`
--

DROP TABLE IF EXISTS `web_site_cookie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_site_cookie` (
  `cookie_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'cookie_id',
  `site_id` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '网站ID',
  `title` varchar(500) NOT NULL DEFAULT '' COMMENT '名称，方便自己查看',
  `content` text NOT NULL COMMENT 'cookie内容',
  `day_used` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '今日已使用次数',
  `day_max` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '该COOKIE每日可用次数',
  `all_used` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '总是用次数',
  `all_max` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '总可用次数',
  `use_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后使用时间',
  `available` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-失效，1-有效',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-禁用，1-启用',
  PRIMARY KEY (`cookie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='站点Cookie';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_site_cookie`
--

LOCK TABLES `web_site_cookie` WRITE;
/*!40000 ALTER TABLE `web_site_cookie` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_site_cookie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-16 14:00:05

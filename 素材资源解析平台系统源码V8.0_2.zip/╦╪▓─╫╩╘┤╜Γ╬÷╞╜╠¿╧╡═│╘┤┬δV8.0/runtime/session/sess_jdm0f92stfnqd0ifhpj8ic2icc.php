<?php
//000000000000
 exit();?>
a:1:{s:5:"login";a:4:{s:3:"uid";i:1;s:8:"password";s:32:"4d215f92ce3bc2c015c940557697870f";s:9:"last_time";i:1597573359;s:7:"last_ip";s:14:"171.223.89.115";}}
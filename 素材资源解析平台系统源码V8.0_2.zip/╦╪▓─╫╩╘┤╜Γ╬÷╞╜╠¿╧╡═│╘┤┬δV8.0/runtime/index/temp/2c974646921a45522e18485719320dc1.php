<?php /*a:4:{s:57:"/www/wwwroot/182.61.40.116/app/index/view/index/index.php";i:1569991696;s:52:"/www/wwwroot/182.61.40.116/app/index/view/layout.php";i:1576573536;s:59:"/www/wwwroot/182.61.40.116/app/index/view/common/header.php";i:1564986424;s:59:"/www/wwwroot/182.61.40.116/app/index/view/common/footer.php";i:1564986424;}*/ ?>
<!DOCTYPE html>
<html class="h-100">
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title><?php echo htmlentities($_G['setting']['site_name']); ?></title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body class="d-flex flex-column h-100">
  	<div class="alert alert-danger text-center">需要自备服务器、自备素材站点VIP！！！</div>
	<div class="alert alert-danger text-center">测试站后台地址：<a href="<?php echo url('admin/index/index'); ?>">进入后台</a>，测试账号：<strong class="text-danger px-2">admin</strong>，测试密码：<strong class="text-danger px-2">admin888</strong>，测试解析功能需要自备VIP账号</div>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<?php if($_G['setting']['site_close']): ?>
		<div class="alert alert-danger">网站当前处于关闭状态，仅管理员可访问，给您带来不便请谅解</div>
	<?php endif; ?>
	<a class="container d-flex justify-content-center my-5" href="<?php echo request()->domain(); ?>"><img src="static/images/logo.png" style="max-height: 100px;"></a>
	<div class="container mb-5"><div class="input-group input-group-lg parse-form">
	<input type="text" class="form-control parse-link" placeholder="请输入需要下载的资源页面地址">
	<div class="input-group-append">
		<button class="btn input-group-text parse-btn" type="submit">获取资源</button>
	</div>
</div>
<div class="card mt-3 d-none parse-result">
	<div class="card-header">资源解析结果</div>
	<div class="card-body">资源获取中，请稍后...</div>
	<div class="card-footer d-none"></div>
</div>
<div class="row mt-3">
	<div class="col-9">
		<?php if(!$_G['uid']): ?>
			<div class="alert alert-danger">您需要先登陆后才能使用解析功能</div>
		<?php else: ?>
			<div class="alert alert-success">欢迎您，<?php echo htmlentities($_G['user']['username']); ?>。</div>
		<?php endif; ?>
		<div class="row m-0 border border-left-0 bg-white">
			<?php $empty_tb = 4 - count($web_site_list)%4; if(is_array($web_site_list) || $web_site_list instanceof \think\Collection || $web_site_list instanceof \think\Paginator): $i = 0; $__LIST__ = $web_site_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$web_site): $mod = ($i % 2 );++$i;$site_id = $web_site['site_id']; if(empty($_G['uid'])): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="无解析权限"><?php echo htmlentities($web_site['title']); ?>：请先登录</div>
				<?php elseif(empty($site_access[$site_id]) || $site_access[$site_id]['day_times'] < 0 || $site_access[$site_id]['week_times'] < 0 || $site_access[$site_id]['month_times'] < 0 || $site_access[$site_id]['year_times'] < 0 || $site_access[$site_id]['max_times'] < 0): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="无解析权限"><?php echo htmlentities($web_site['title']); ?>：无权限</div>
				<?php elseif($site_access[$site_id]->getData('out_time') > 0 && $site_access[$site_id]->getData('out_time') <= app('request')->time()): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="解析权限已过期"><?php echo htmlentities($web_site['title']); ?>：已过期</div>
				<?php elseif($site_access[$site_id]['day_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['day_times'] <= $download_count[$site_id]['day_used_time']): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="今日解析次数已达上限"><?php echo htmlentities($web_site['title']); ?>：今日上限</div>
				<?php elseif($site_access[$site_id]['week_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['week_times'] <= $download_count[$site_id]['week_used_time']): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="本周解析次数已达上限"><?php echo htmlentities($web_site['title']); ?>：本周上限</div>
				<?php elseif($site_access[$site_id]['month_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['month_times'] <= $download_count[$site_id]['month_used_time']): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="本月解析次数已达上限"><?php echo htmlentities($web_site['title']); ?>：本月上限</div>
				<?php elseif($site_access[$site_id]['year_times'] > 0 && !empty($download_count[$site_id]) && $site_access[$site_id]['year_times'] <= $download_count[$site_id]['year_used_time']): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="今年解析次数已达上限"><?php echo htmlentities($web_site['title']); ?>：今年上限</div>
				<?php elseif($site_access[$site_id]['max_times'] > 0 && $site_access[$site_id]['max_times'] <= $site_access[$site_id]['parse_times']): ?>
					<div class="col-3 p-3 border-left text-center text-black-50" data-toggle="tooltip" data-placement="top" data-original-title="可解析总次数已用完"><?php echo htmlentities($web_site['title']); ?>：次数用完</div>
				<?php else: 
						$last = [];
						foreach(['day_times'=>'day_used_time','week_times'=>'week_used_time','month_times'=>'month_used_time','year_times'=>'year_used_time'] as $t => $c){
							if($site_access[$site_id][$t] == 0){
								$last[$t] = '无限';
							}else{
								$last[$t] = $site_access[$site_id][$t] - (!empty($download_count[$site_id]) ? $download_count[$site_id][$c] : 0);
							}
						}
					 ?>
					<div class="col-3 p-3 border-left text-center" data-toggle="tooltip" data-placement="right" data-html="true" data-original-title="
					今日剩余：<?php echo htmlentities($last['day_times']); ?>次<br>
					本周剩余：<?php echo htmlentities($last['week_times']); ?>次<br>
					本月剩余：<?php echo htmlentities($last['month_times']); ?>次<br>
					今年剩余：<?php echo htmlentities($last['year_times']); ?>次<br>
					总数剩余：<?php echo !empty($site_access[$site_id]['max_times']) ? ($site_access[$site_id]['max_times'] - $site_access[$site_id]['parse_times']).'次'  :  '无限次'; ?>"><?php echo htmlentities($web_site['title']); ?>：<?php echo htmlentities($last['day_times']); ?>/<?php echo !empty($site_access[$site_id]['day_times']) ? htmlentities($site_access[$site_id]['day_times']) : '无限'; ?>次</div>
				<?php endif; if($i % 4 == 0): ?>
					</div>
					<div class="row m-0 border-right border-bottom bg-white">
				<?php endif; ?>
			<?php endforeach; endif; else: echo "" ;endif; if($empty_tb > 0 && $empty_tb != 4): $__FOR_START_516105799__=0;$__FOR_END_516105799__=$empty_tb;for($e_i=$__FOR_START_516105799__;$e_i < $__FOR_END_516105799__;$e_i+=1){ ?>
					<div class="col-3 p-3 border-left text-center">&nbsp;</div>
				<?php } ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-3 pl-0">
		<div class="index-user-bar bg-white border border-bottom-0">
			<div class="d-flex justify-content-start align-items-center">
			<?php if(is_array($user_nav) || $user_nav instanceof \think\Collection || $user_nav instanceof \think\Paginator): $n_i = 0; $__LIST__ = $user_nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($n_i % 2 );++$n_i;?>
				<a class="w-50 text-center p-3 <?php if($n_i % 2 != 0): ?>border-right<?php endif; ?>" href="<?php echo htmlentities($nav['url']); ?>">
					<div>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($nav['icon']); ?>"></use>
						</svg>
					</div>
					<div><?php echo htmlentities($nav['name']); ?></div>
				</a>
				<?php if($n_i % 2 == 0): ?>
					</div>
					<div class="d-flex justify-content-start align-items-center border-top">
				<?php endif; ?>
			<?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
		</div>
		<div class="card mt-3">
			<div class="card-header d-flex justify-content-between">
			 	<div>帮助中心</div>
			 	<a href="<?php echo url('index/portal/index'); ?>">更多>></a>
			</div>
			<div class="card-body px-0 py-1">
				<?php foreach($article_list as $article): ?>
					<a class="d-block px-2 py-1" href="<?php echo url('index/portal/view',['article_id'=>$article['article_id']]); ?>"><?php echo htmlentities($article['subject']); ?></a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(function(){
		$(document)
			.on('click','.download-btn',function(){
	            var url = '/index/index/redirect.html#!'+ encodeURI($(this).attr('href'));
	            $('body').append('<iframe class="d-none" src="'+url+'"></iframe>');
	            return false;
			})
			.on('click','.parse-btn',function(){
				if($('.parse-btn').hasClass('disabled')){
					return false;
				}
				var link = $.trim($('.parse-link').val());
				if(!link){
					$('.parse-link').focus();
					return dialog.msg('请输入需要解析的网址');
				}
				parse_link(link);
			})
	})
	function parse_link(link,verify_code){
		$('.parse-btn').addClass('disabled').html('获取中...');
		$('.parse-result').removeClass('d-none');
		$.ajax({
			url:'<?php echo url('index/index/parse'); ?>',
			data:{link:link,verify_code:verify_code},
			dataType:'json',
			type:'POST',
			timeout:120000,
			success:function(result){
				if(result.code <= 0){
					$('.parse-result .card-body').html(result.msg);
					$('.parse-result .card-footer').addClass('d-none');
					return dialog.msg(result);
				}else if(result.code == 200){
					var download_html = '';
					$.each(result.msg,function(button_name,download_url){
						download_html += '<a class="btn download-btn btn-danger '+(download_html != '' ? 'ml-3' : '')+'" href="'+download_url+'" >'+button_name+'</a>';
					})
					$('.parse-result .card-footer').removeClass('d-none').html(download_html);
					$('.parse-result .card-body').html(result.info);
				}else if(result.code == 'verify'){
					var op = {
						type: 1,
						title: result.title,
						closeBtn: false,
						area: result.area,
						shade: 0.3,
						id: 'LAY_layuipro',
						resize: false,
						btn: ['确定提交', '取消输入'],
						btnAlign: 'c',
						moveType: 1,
						content: result.content,
						yes: function(){
							dialog.closeAll();
							var verify_code = $('#verify_code').val();
							parse_link(link,verify_code);
						},
						btn2: function(){
							dialog.closeAll();
						}
					};
					if(result.no_button == 1){
						op.btn = false;
					}
					dialog.open(op);
					$('.verify-img-box img').off('click').on('click',function(){
						var verify_code = $(this).data('key');
						dialog.closeAll();
						parse_link(link,verify_code);
					})
					return false;
				}
			},
            complete:function(request, status){
                $('.parse-btn').removeClass('disabled').html('获取资源');
                if(status == 'error'){
                    dialog.msg('页面错误，请联系管理员！');
                }else if(status == 'timeout'){
                    dialog.msg('数据提交超时，请重试！');
                }
            }
		})
	}
</script>
</div>
	<footer class="p-3 mt-auto border-top">
		<div class="container">
			<p class="text-center">© 2019 - 2099</p>
			<p class="text-center">本站内容完全来自于互联网，并不对其进行任何编辑或修改。本站用户不能侵犯包括他人的著作权在内的知识产权以及其他权利</p>
		</div>
	</footer>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'<?php echo url('index/job/index'); ?>',
				success:function(s){}
			})
		})
	</script>
</body>
</html>


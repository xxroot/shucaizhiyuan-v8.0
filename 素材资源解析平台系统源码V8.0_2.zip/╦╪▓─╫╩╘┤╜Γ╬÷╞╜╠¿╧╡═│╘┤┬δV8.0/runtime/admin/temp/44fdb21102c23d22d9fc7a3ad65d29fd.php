<?php /*a:4:{s:56:"/www/wwwroot/182.61.40.116/app/admin/view/user/index.php";i:1569991696;s:52:"/www/wwwroot/182.61.40.116/app/admin/view/layout.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/header.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/footer.php";i:1569991696;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title>管理中心</title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<nav class="d-flex justify-content-between fixed-top admin-top bg-white">
		<div class="d-flex justify-content-start pl-3">
			<?php foreach($_G['admin_menu'] as $controller => $menu): ?>
				<a class="px-3 <?php if($controller === app('request')->controller()): ?>active<?php endif; ?>" href="<?php echo url(!empty($menu['url']) ? $menu['url'] : ($menu['sub_menu'][0]['url']??'#')); ?>">
					<?php if(!empty($menu['icon'])): ?>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($menu['name']); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<div class="d-flex justify-content-end align-items-center pr-3">
			<a class="px-3" href="<?php echo url('index/index/index'); ?>" target="_blank">前台</a>
			<div class="px-3">欢迎您，<?php echo htmlentities($_G['user']['username']); ?></div>
			<a class="px-3" href="<?php echo url('admin/account/logout'); ?>">
				<svg class="iconfont" aria-hidden="true">
				    <use xlink:href="#icon-logout"></use>
				</svg>
				退出
			</a>
		</div>
	</nav>
	<div class="left-bar">
		<h5>管理中心</h5>
		<div class="left-nav">
			<?php foreach($_G['admin_menu'][app('request')->controller()]['sub_menu'] as $sub_menu): ?>
				<a class="<?php if(in_array(app('request')->action(),$sub_menu['active_list'])): ?>active<?php endif; ?>" href="<?php echo url($sub_menu['url']); ?>" <?php if(!(empty($sub_menu['target']) || (($sub_menu['target'] instanceof \think\Collection || $sub_menu['target'] instanceof \think\Paginator ) && $sub_menu['target']->isEmpty()))): ?>target="<?php echo htmlentities($sub_menu['target']); ?>"<?php endif; ?>>
					<?php if(!empty($sub_menu['icon'])): ?>
						<svg class="iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($sub_menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($sub_menu['name']); ?>
				</a>
			<?php endforeach; ?>
			<a class="text-warning d-none new-version-nav" href="<?php echo url('admin/tools/upgrade'); ?>">
				<svg class="iconfont mr-2" aria-hidden="true">
				    <use xlink:href="#icon-nav"></use>
				</svg>
				发现新版本
			</a>
		</div>
	</div>
	<div class="admin-content p-3"><div class="card">
	<div class="card-header border-bottom-0 d-flex justify-content-between align-items-center">
		<div>总计共有<strong class="text-danger px-2"><?php echo htmlentities($count['all']); ?></strong>位用户 <?php if($is_search): ?>有<strong class="text-danger px-2"><?php echo htmlentities($count['search']); ?></strong>位用户符合搜索条件<?php endif; ?></div>
		<div>
			<a class="btn btn-success btn-sm" href="<?php echo url('admin/user/add_user'); ?>">新增用户</a>
			<a class="btn btn-info btn-sm" href="<?php echo url('admin/user/batch_add'); ?>">批量创建</a>
		</div>
	</div>
	<div class="card-body p-0">
		<table class="table table-hover mb-0">
			<thead>
				<tr>
					<th width="80">UID</th>
					<th>用户名</th>
					<th width="80">账户余额</th>
					<th width="160">最后登录</th>
					<th>角色</th>
					<th width="80">价格折扣</th>
					<th>
						累计解析
						<svg data-toggle="tooltip" data-html="true" data-placement="right" data-title="已解析次数/最大可解析次数" class="text-info iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#icon-bangzhu"></use>
						</svg>
					</th>
					<th>
						站点权限
						<svg data-toggle="tooltip" data-html="true" data-placement="right" data-title="日/周/月/年/最大次数限制" class="text-info iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#icon-bangzhu"></use>
						</svg>
					</th>
					<th width="100"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($user_list as $user): ?>
					<tr>
						<td><?php echo htmlentities($user['uid']); ?></td>
						<td><?php echo htmlentities($user['username']); ?></td>
						<td><?php echo htmlentities($user['balance']); ?></td>
						<td><?php echo htmlentities($user['last_time']); ?></td>
						<td><?php echo htmlentities($user['type_text']); ?></td>
						<td class="text-danger"><?php echo htmlentities($user['discount']); ?></td>
						<td><?php echo htmlentities($user['parse_times']); ?>/<?php echo htmlentities($user['parse_max_times_text']); ?></td>
						<td class="text-info" data-toggle="tooltip" data-html="true" data-placement="right" data-title="
						<?php if(is_array($user['site_access']) || $user['site_access'] instanceof \think\Collection || $user['site_access'] instanceof \think\Paginator): $i = 0; $__LIST__ = $user['site_access'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$site_access): $mod = ($i % 2 );++$i;
							if(empty($web_site[$site_access['site_id']]) || $site_access['day_times'] < 0 || $site_access['week_times'] < 0 || $site_access['month_times'] < 0 || $site_access['year_times'] < 0 || $site_access['max_times'] < 0){
								continue;
							}
						 ?>
						<?php echo htmlentities($web_site[$site_access['site_id']]['title']); ?> : &lt;strong class=&quot;text-success&quot;&gt;<?php echo htmlentities($site_access['day_times']); ?>&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;<?php echo htmlentities($site_access['week_times']); ?>&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;<?php echo htmlentities($site_access['month_times']); ?>&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;<?php echo htmlentities($site_access['year_times']); ?>&lt;/strong&gt; / &lt;strong class=&quot;text-success&quot;&gt;<?php echo htmlentities($site_access['max_times']); ?>&lt;/strong&gt;
						&lt;br&gt;<?php endforeach; endif; else: echo "" ;endif; ?>
						">查看权限</td>
						<td class="text-right">
							<a href="<?php echo url('admin/user/edit_user',['uid'=>$user['uid']]); ?>">编辑</a>
							<?php if(!in_array($user['uid'], config('app.founder'))): ?>
								<a class="ajax-link" data-mode="confirm" href="<?php echo url('admin/user/delete_user',['uid'=>$user['uid']]); ?>">删除</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php if($page): ?><div class="card-footer"><?php echo $page; ?></div><?php endif; ?>
</div>
</div>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'<?php echo url('admin/tools/check_new_version'); ?>',
				success:function(s){
					if(s.code == 1){
						$('.new-version-nav').removeClass('d-none');
						<?php if(empty(cookie('new_version_tip'))): ?>
							dialog.open({
								type: 1,
								anim: 2,
								shadeClose: false,
								content: '<div class="p-3">发现程序新版本，请及时更新程序确保解析功能正常<br>新版本号：<strong class="text-danger">'+s.data.new_version+'</strong><br><a href="<?php echo url('admin/tools/upgrade'); ?>">前往升级</a></div>'
							});
							<?php cookie('new_version_tip',1,86400); ?>
						<?php endif; ?>
					}
				}
			})
			$.ajax({
				url:'<?php echo url('index/job/index'); ?>',
				success:function(s){
					console.log(s);
				}
			})
		})
	</script>
</body>
</html>


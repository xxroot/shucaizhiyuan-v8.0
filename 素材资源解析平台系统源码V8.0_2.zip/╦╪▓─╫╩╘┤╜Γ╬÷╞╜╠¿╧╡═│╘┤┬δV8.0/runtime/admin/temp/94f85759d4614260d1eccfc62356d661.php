<?php /*a:4:{s:61:"/www/wwwroot/182.61.40.116/app/admin/view/setting/fission.php";i:1569991696;s:52:"/www/wwwroot/182.61.40.116/app/admin/view/layout.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/header.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/footer.php";i:1569991696;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title>管理中心</title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<nav class="d-flex justify-content-between fixed-top admin-top bg-white">
		<div class="d-flex justify-content-start pl-3">
			<?php foreach($_G['admin_menu'] as $controller => $menu): ?>
				<a class="px-3 <?php if($controller === app('request')->controller()): ?>active<?php endif; ?>" href="<?php echo url(!empty($menu['url']) ? $menu['url'] : ($menu['sub_menu'][0]['url']??'#')); ?>">
					<?php if(!empty($menu['icon'])): ?>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($menu['name']); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<div class="d-flex justify-content-end align-items-center pr-3">
			<a class="px-3" href="<?php echo url('index/index/index'); ?>" target="_blank">前台</a>
			<div class="px-3">欢迎您，<?php echo htmlentities($_G['user']['username']); ?></div>
			<a class="px-3" href="<?php echo url('admin/account/logout'); ?>">
				<svg class="iconfont" aria-hidden="true">
				    <use xlink:href="#icon-logout"></use>
				</svg>
				退出
			</a>
		</div>
	</nav>
	<div class="left-bar">
		<h5>管理中心</h5>
		<div class="left-nav">
			<?php foreach($_G['admin_menu'][app('request')->controller()]['sub_menu'] as $sub_menu): ?>
				<a class="<?php if(in_array(app('request')->action(),$sub_menu['active_list'])): ?>active<?php endif; ?>" href="<?php echo url($sub_menu['url']); ?>" <?php if(!(empty($sub_menu['target']) || (($sub_menu['target'] instanceof \think\Collection || $sub_menu['target'] instanceof \think\Paginator ) && $sub_menu['target']->isEmpty()))): ?>target="<?php echo htmlentities($sub_menu['target']); ?>"<?php endif; ?>>
					<?php if(!empty($sub_menu['icon'])): ?>
						<svg class="iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($sub_menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($sub_menu['name']); ?>
				</a>
			<?php endforeach; ?>
			<a class="text-warning d-none new-version-nav" href="<?php echo url('admin/tools/upgrade'); ?>">
				<svg class="iconfont mr-2" aria-hidden="true">
				    <use xlink:href="#icon-nav"></use>
				</svg>
				发现新版本
			</a>
		</div>
	</div>
	<div class="admin-content p-3"><form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-tabs card-header-tabs">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#setting">裂变设置</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#reward">推广奖励</a>
				</li>
			</ul>
		</div>
		<div class="card-body tab-content p-0">
			<div class="tab-pane fade p-3 show active" id="setting">
				<div class="form-group">
					<label class="font-weight-bold">裂变推广</label>
					<div class="custom-control custom-radio">
						<input name="setting[user_fission]" type="radio" class="custom-control-input" value="1" <?php if($_G['setting']['user_fission']): ?>checked<?php endif; ?>>
						<label class="custom-control-label">启用裂变推广</label>
					</div>
					<div class="custom-control custom-radio">
						<input name="setting[user_fission]" type="radio" class="custom-control-input" value="0" <?php if(!$_G['setting']['user_fission']): ?>checked<?php endif; ?>>
						<label class="custom-control-label">禁用裂变推广</label>
					</div>
					<small class="form-text text-muted">启用裂变推广后用户将拥有唯一推广链接地址，通过该推广地址注册的会员将会成为其下属会员</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">裂变推广链接时效</label>
					<input type="number" class="form-control" name="setting[user_fission_time]" value="<?php echo htmlentities($_G['setting']['user_fission_time']); ?>">
					<small class="form-text text-muted">新用户访问推广链接多长时间内注册有效成为推广者下属会员，单位：小时</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大裂变级数</label>
					<input type="number" class="form-control" name="setting[user_fission_lv]" value="<?php echo htmlentities($_G['setting']['user_fission_lv']); ?>">
					<small class="form-text text-muted">用户最大裂变等级数，-1为关闭裂变，0为不限制，不建议开启无限制级数裂变，且裂变级数需大于奖励层级数</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">最大奖励层级</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_lv]" value="<?php echo htmlentities($_G['setting']['user_fission_reward_lv']); ?>">
					<small class="form-text text-muted">裂变推广注册的会员会无限向上级会员赠送下面设置的解析次数</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">单日内最大奖励次数</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_day_times]" value="<?php echo htmlentities($_G['setting']['user_fission_reward_day_times']); ?>">
					<small class="form-text text-muted">同一用户通过推广单日内获得最大奖励次数，0为不限制，任何负数表示禁止</small>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">账户最大奖励次数</label>
					<input type="number" class="form-control" name="setting[user_fission_reward_max_times]" value="<?php echo htmlentities($_G['setting']['user_fission_reward_max_times']); ?>">
					<small class="form-text text-muted">同一用户通过推广可获得最大的奖励次数，0为不限制，任何负数表示禁止</small>
				</div>
			</div>
			<div class="tab-pane fade" id="reward">
				<table class="table table-hover mb-0">
					<thead>
						<tr>
							<th class="border-top-0" width="100">站点名称</th>
							<th class="border-top-0">奖励解析次数</th>
							<th class="border-top-0">有效期(小时/0-无限)</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($web_site_list as $web_site): ?>
							<tr>
								<td><div class="mt-1 text-right"><?php echo htmlentities($web_site['title']); ?></div></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="setting[user_fission_reward][times][<?php echo htmlentities($web_site['site_id']); ?>]" value="<?php echo isset($_G['setting']['user_fission_reward']['times'][$web_site['site_id']]) ? htmlentities($_G['setting']['user_fission_reward']['times'][$web_site['site_id']]) : 0; ?>"></td>
								<td><input type="number" class="form-control form-control-sm d-inline" name="setting[user_fission_reward][out_time][<?php echo htmlentities($web_site['site_id']); ?>]" value="<?php echo isset($_G['setting']['user_fission_reward']['out_time'][$web_site['site_id']]) ? htmlentities($_G['setting']['user_fission_reward']['out_time'][$web_site['site_id']]) : 0; ?>"></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>
</div>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'<?php echo url('admin/tools/check_new_version'); ?>',
				success:function(s){
					if(s.code == 1){
						$('.new-version-nav').removeClass('d-none');
						<?php if(empty(cookie('new_version_tip'))): ?>
							dialog.open({
								type: 1,
								anim: 2,
								shadeClose: false,
								content: '<div class="p-3">发现程序新版本，请及时更新程序确保解析功能正常<br>新版本号：<strong class="text-danger">'+s.data.new_version+'</strong><br><a href="<?php echo url('admin/tools/upgrade'); ?>">前往升级</a></div>'
							});
							<?php cookie('new_version_tip',1,86400); ?>
						<?php endif; ?>
					}
				}
			})
			$.ajax({
				url:'<?php echo url('index/job/index'); ?>',
				success:function(s){
					console.log(s);
				}
			})
		})
	</script>
</body>
</html>


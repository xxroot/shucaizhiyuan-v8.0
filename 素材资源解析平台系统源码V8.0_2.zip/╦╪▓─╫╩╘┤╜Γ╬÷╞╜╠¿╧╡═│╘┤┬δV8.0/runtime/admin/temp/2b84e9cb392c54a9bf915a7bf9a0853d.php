<?php /*a:4:{s:57:"/www/wwwroot/182.61.40.116/app/admin/view/index/index.php";i:1597573965;s:52:"/www/wwwroot/182.61.40.116/app/admin/view/layout.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/header.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/footer.php";i:1569991696;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title>管理中心</title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<nav class="d-flex justify-content-between fixed-top admin-top bg-white">
		<div class="d-flex justify-content-start pl-3">
			<?php foreach($_G['admin_menu'] as $controller => $menu): ?>
				<a class="px-3 <?php if($controller === app('request')->controller()): ?>active<?php endif; ?>" href="<?php echo url(!empty($menu['url']) ? $menu['url'] : ($menu['sub_menu'][0]['url']??'#')); ?>">
					<?php if(!empty($menu['icon'])): ?>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($menu['name']); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<div class="d-flex justify-content-end align-items-center pr-3">
			<a class="px-3" href="<?php echo url('index/index/index'); ?>" target="_blank">前台</a>
			<div class="px-3">欢迎您，<?php echo htmlentities($_G['user']['username']); ?></div>
			<a class="px-3" href="<?php echo url('admin/account/logout'); ?>">
				<svg class="iconfont" aria-hidden="true">
				    <use xlink:href="#icon-logout"></use>
				</svg>
				退出
			</a>
		</div>
	</nav>
	<div class="left-bar">
		<h5>管理中心</h5>
		<div class="left-nav">
			<?php foreach($_G['admin_menu'][app('request')->controller()]['sub_menu'] as $sub_menu): ?>
				<a class="<?php if(in_array(app('request')->action(),$sub_menu['active_list'])): ?>active<?php endif; ?>" href="<?php echo url($sub_menu['url']); ?>" <?php if(!(empty($sub_menu['target']) || (($sub_menu['target'] instanceof \think\Collection || $sub_menu['target'] instanceof \think\Paginator ) && $sub_menu['target']->isEmpty()))): ?>target="<?php echo htmlentities($sub_menu['target']); ?>"<?php endif; ?>>
					<?php if(!empty($sub_menu['icon'])): ?>
						<svg class="iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($sub_menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($sub_menu['name']); ?>
				</a>
			<?php endforeach; ?>
			<a class="text-warning d-none new-version-nav" href="<?php echo url('admin/tools/upgrade'); ?>">
				<svg class="iconfont mr-2" aria-hidden="true">
				    <use xlink:href="#icon-nav"></use>
				</svg>
				发现新版本
			</a>
		</div>
	</div>
	<div class="admin-content p-3"><div class="p-3 bg-white">
	<h5 style="padding-left: 8px;border-left: 4px solid #00aeff">运营统计</h5>
	<div style="color: red !important; text-align: center;"><strong>&#26356;&#22810;&#20146;&#27979;&#28304;&#30721;&#35831;&#21040;&#22244;&#20027;&#39064;&#119;&#119;&#119;&#46;&#116;&#122;&#104;&#117;&#116;&#105;&#46;&#99;&#111;&#109;
</strong></div>
	<div class="d-flex justify-content-between mt-3">
		<div class="w-100 p-3 text-light" style="background: linear-gradient(-125deg, #57bdbf, #2f9de2)">
			<h6>用户总数</h6>
			<h1><?php echo htmlentities($count['users']); ?></h1>
			<p>当前用户总数量</p>
		</div>
		<div class="w-100 p-3 text-light ml-3" style="background: linear-gradient(-125deg, #ff7d7d, #fb2c95)">
			<h6>可用站点</h6>
			<h1><?php echo htmlentities($count['web_sites']); ?></h1>
			<p>已开通解析素材站数量</p>
		</div>
		<div class="w-100 p-3 text-light ml-3" style="background: linear-gradient(-113deg, #c543d8, #925cc3)">
			<h6>附件数量</h6>
			<h1><?php echo htmlentities($count['attachs']); ?></h1>
			<p>已存储附件数量</p>
		</div>
		<div class="w-100 p-3 text-light ml-3" style="background: linear-gradient(-141deg, #ecca1b, #f39526)">
			<h6>解析记录数</h6>
			<h1><?php echo htmlentities($count['download_logs']); ?></h1>
			<p>已完成解析数量</p>
		</div>
	</div>
</div>

<div class="p-3 bg-white mt-3">
	<h5 style="padding-left: 8px;border-left: 4px solid #00aeff">实时数据</h5>
	<div class="d-flex justify-content-between mt-3">
		<div class="d-flex justify-content-between align-items-center w-100">
			<img src="static/images/count-yuan.png" style="width: 60px;height: 60px;">
			<div class="w-100 p-3 ml-3">
				<div class="text-secondary">累计收入</div>
				<h1 class="text-success"><?php echo htmlentities($_G['setting']['recharge_all']); ?></h1>
				<p class="small text-muted">用户总充值金额</p>
			</div>
			<div class="w-100 p-3 ml-5">
				<div class="text-secondary">累计支出</div>
				<h1 class="text-danger"><?php echo htmlentities($_G['setting']['withdraw_all']); ?></h1>
				<p class="small text-muted">用户申请提现总金额</p>
			</div>
		</div>
		<div class="d-flex justify-content-between align-items-center w-100">
			<img src="static/images/count-numbers.png" style="width: 60px;height: 60px;">
			<div class="w-100 p-3 ml-3">
				<div class="text-secondary">代理总数</div>
				<h1 class="text-info"><?php echo htmlentities($count['proxy_users']); ?></h1>
				<p class="small text-muted">站点拥有的代理用户数</p>
			</div>
			<div class="w-100 p-3 ml-5">
				<div class="text-secondary">裂变会员</div>
				<h1 class="text-warning"><?php echo htmlentities($count['fission_users']); ?></h1>
				<p class="small text-muted">会员裂变数</p>
			</div>
		</div>
	</div>
</div>

<div class="p-3 bg-white mt-3">
	<h5 style="padding-left: 8px;border-left: 4px solid #00aeff">近日交易统计</h5>
	<div id="echarts-trade" class="mt-3 w-100" style="height: 400px;"></div>
</div>
<script type="text/javascript">
	$(function(){
	    var dom = document.getElementById('echarts-trade');
	    $.getScript('static/js/echarts.min.js',function(){
	    	$.getScript('static/js/echarts-walden.js',function(){
			    echarts.init(dom, 'walden').setOption({
			        tooltip: {
			            trigger: 'axis'
			        },
			        legend: {
			            data: ['解析数量', '自助注册会员数']
			        },
			        toolbox: {
			            show: true,
			            showTitle: false,
			            feature: {
			                mark: {show: true},
			                magicType: {show: true, type: ['line', 'bar']}
			            }
			        },
			        calculable: true,
			        xAxis: {
			            type: 'category',
			            boundaryGap: false,
			            data: <?php echo $days; ?>
			        },
			        yAxis: {
			            type: 'value'
			        },
			        series: [
			            {
			                name: '解析数量',
			                type: 'line',
			                data: <?php echo $logs; ?>
			            },
			            {
			                name: '自助注册会员数',
			                type: 'line',
			                data: <?php echo $registers; ?>
			            }
			        ]
			    }, true);
	    	})
	    })
	})
</script>
</div>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'<?php echo url('admin/tools/check_new_version'); ?>',
				success:function(s){
					if(s.code == 1){
						$('.new-version-nav').removeClass('d-none');
						<?php if(empty(cookie('new_version_tip'))): ?>
							dialog.open({
								type: 1,
								anim: 2,
								shadeClose: false,
								content: '<div class="p-3">发现程序新版本，请及时更新程序确保解析功能正常<br>新版本号：<strong class="text-danger">'+s.data.new_version+'</strong><br><a href="<?php echo url('admin/tools/upgrade'); ?>">前往升级</a></div>'
							});
							<?php cookie('new_version_tip',1,86400); ?>
						<?php endif; ?>
					}
				}
			})
			$.ajax({
				url:'<?php echo url('index/job/index'); ?>',
				success:function(s){
					console.log(s);
				}
			})
		})
	</script>
</body>
</html>


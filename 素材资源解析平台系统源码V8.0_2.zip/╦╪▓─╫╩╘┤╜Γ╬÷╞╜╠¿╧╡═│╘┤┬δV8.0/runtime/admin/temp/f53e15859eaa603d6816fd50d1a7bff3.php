<?php /*a:3:{s:59:"/www/wwwroot/182.61.40.116/app/admin/view/account/login.php";i:1597573344;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/header.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/footer.php";i:1569991696;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title>管理中心</title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body>
    <style type="text/css">html,body {height: 100%;}</style>
    <div class="d-flex justify-content-center d-flex align-items-center h-100 w-100">
        <form autocomplete="off" class="card" style="width: 400px;">
            <h5 class="card-header text-center">管理员登陆</h5>
            <div class="card-body">
                <div class="form-group">
                    <input type="text" class="form-control" name="account" placeholder="会员账号" required autofocus>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" placeholder="登陆密码" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text p-0"><img class="captcha" src="<?php echo url('index/captcha/index'); ?>" style="height: 36px;cursor: pointer;"></span>
                    </div>
                    <input type="text" class="form-control" name="verify_code">
                </div>
                <button class="btn btn-success btn-block ajax-post" type="submit">登 录</button>
            </div>
			<div>&#26356;&#22810;&#20146;&#27979;&#28304;&#30721;&#35831;&#21040;&#22244;&#20027;&#39064;&#119;&#119;&#119;&#46;&#116;&#122;&#104;&#117;&#116;&#105;&#46;&#99;&#111;&#109;
</div>

        </form>
    </div>
</body>
</html>


<?php /*a:4:{s:59:"/www/wwwroot/182.61.40.116/app/admin/view/setting/email.php";i:1569991696;s:52:"/www/wwwroot/182.61.40.116/app/admin/view/layout.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/header.php";i:1569991696;s:59:"/www/wwwroot/182.61.40.116/app/admin/view/common/footer.php";i:1569991696;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="always" name="referrer">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="This CMS from NanBoWang，Technical Support：3555990206">
    <meta name="author" content="NanBoWang，QQ：3555990206">
    <meta name="generator" content="<?php echo request()->setting['version']; ?>">
	<title>管理中心</title>
	<base href="<?php echo request()->domain(); ?>">
	<script src="static/js/jquery-3.4.1.min.js"></script>
	<script src="static/js/bootstrap.min.js"></script>
	<script src="static/js/common.js"></script>
	<link rel="stylesheet" href="static/css/bootstrap.min.css">
	<link rel="stylesheet" href="static/css/common.css">
</head>

<body>
	<style type="text/css">html,body {background: #f1f1f9;}</style>
	<nav class="d-flex justify-content-between fixed-top admin-top bg-white">
		<div class="d-flex justify-content-start pl-3">
			<?php foreach($_G['admin_menu'] as $controller => $menu): ?>
				<a class="px-3 <?php if($controller === app('request')->controller()): ?>active<?php endif; ?>" href="<?php echo url(!empty($menu['url']) ? $menu['url'] : ($menu['sub_menu'][0]['url']??'#')); ?>">
					<?php if(!empty($menu['icon'])): ?>
						<svg class="iconfont" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($menu['name']); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<div class="d-flex justify-content-end align-items-center pr-3">
			<a class="px-3" href="<?php echo url('index/index/index'); ?>" target="_blank">前台</a>
			<div class="px-3">欢迎您，<?php echo htmlentities($_G['user']['username']); ?></div>
			<a class="px-3" href="<?php echo url('admin/account/logout'); ?>">
				<svg class="iconfont" aria-hidden="true">
				    <use xlink:href="#icon-logout"></use>
				</svg>
				退出
			</a>
		</div>
	</nav>
	<div class="left-bar">
		<h5>管理中心</h5>
		<div class="left-nav">
			<?php foreach($_G['admin_menu'][app('request')->controller()]['sub_menu'] as $sub_menu): ?>
				<a class="<?php if(in_array(app('request')->action(),$sub_menu['active_list'])): ?>active<?php endif; ?>" href="<?php echo url($sub_menu['url']); ?>" <?php if(!(empty($sub_menu['target']) || (($sub_menu['target'] instanceof \think\Collection || $sub_menu['target'] instanceof \think\Paginator ) && $sub_menu['target']->isEmpty()))): ?>target="<?php echo htmlentities($sub_menu['target']); ?>"<?php endif; ?>>
					<?php if(!empty($sub_menu['icon'])): ?>
						<svg class="iconfont mr-2" aria-hidden="true">
						    <use xlink:href="#<?php echo htmlentities($sub_menu['icon']); ?>"></use>
						</svg>
					<?php endif; ?>
					<?php echo htmlentities($sub_menu['name']); ?>
				</a>
			<?php endforeach; ?>
			<a class="text-warning d-none new-version-nav" href="<?php echo url('admin/tools/upgrade'); ?>">
				<svg class="iconfont mr-2" aria-hidden="true">
				    <use xlink:href="#icon-nav"></use>
				</svg>
				发现新版本
			</a>
		</div>
	</div>
	<div class="admin-content p-3"><form method="post" autocomplete="off">
	<div class="card">
		<div class="card-header">邮箱设置</div>
		<div class="card-body">
			<div class="form-group">
				<label class="font-weight-bold">验证码有效期</label>
				<input type="text" class="form-control" name="setting[verify_code_time]" value="<?php echo htmlentities($_G['setting']['verify_code_time']); ?>">
				<small class="form-text text-muted">单位：分钟</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件HOST</label>
				<input type="text" class="form-control" name="setting[email_host]" value="<?php echo htmlentities($_G['setting']['email_host']); ?>">
				<small class="form-text text-muted">邮件发送服务器HOST，QQ邮箱为：smtp.qq.com，腾讯企业邮箱：smtp.exmail.qq.com</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件发送端口</label>
				<input type="text" class="form-control" name="setting[email_port]" value="<?php echo htmlentities($_G['setting']['email_port']); ?>">
				<small class="form-text text-muted">一般为25或465</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮箱用户名</label>
				<input type="text" class="form-control" name="setting[email_username]" value="<?php echo htmlentities($_G['setting']['email_username']); ?>">
				<small class="form-text text-muted">登陆邮箱的用户名，例如：12345678@qq.com</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮箱授权码</label>
				<input type="text" class="form-control" name="setting[email_password]" value="<?php echo htmlentities($_G['setting']['email_password']); ?>">
				<small class="form-text text-muted">企业邮箱请填写邮箱密码，个人邮箱<a class="pl-1 text-success" href="https://service.mail.qq.com/cgi-bin/help?subtype=1&&no=1001256&&id=28" target="_blank">点击这里查看如何获取授权码</a></small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件来源名称</label>
				<input type="text" class="form-control" name="setting[email_fromname]" value="<?php echo htmlentities($_G['setting']['email_fromname']); ?>">
				<small class="form-text text-muted">可填写站点名称</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件自助注册</label>
				<div class="custom-control custom-radio" data-after="email_register">
					<input name="setting[email_register]" type="radio" class="custom-control-input" value="1" <?php if($_G['setting']['email_register']): ?>checked<?php endif; ?>>
					<label class="custom-control-label">启用邮箱自助注册帐号</label>
				</div>
				<div class="custom-control custom-radio" data-after="email_register">
					<input name="setting[email_register]" type="radio" class="custom-control-input" value="0" <?php if(!$_G['setting']['email_register']): ?>checked<?php endif; ?>>
					<label class="custom-control-label">禁用邮箱自助注册帐号</label>
				</div>
				<small class="form-text text-muted">启用后前台用户需通过邮箱才能自助注册帐号</small>
			</div>
			<div class="form-group email_register_content <?php if(!$_G['setting']['email_register']): ?>d-none<?php endif; ?>">
				<label class="font-weight-bold">自助注册帐号邮件内容</label>
				<div class="editor-box"><textarea class="editor d-none" name="setting[email_register_content]"><?php echo htmlentities($_G['setting']['email_register_content']); ?></textarea></div>
				<small class="form-text text-muted">用户注册时收到的邮件内容，内容中必须包含<strong class="px-2 text-success">[REGISTER_CODE]</strong>代码，该代码会被替换成验证码（不限次数）</small>
			</div>
			<div class="form-group">
				<label class="font-weight-bold">邮件找回密码</label>
				<div class="custom-control custom-radio" data-after="email_reset_password">
					<input name="setting[email_reset_password]" type="radio" class="custom-control-input" value="1" <?php if($_G['setting']['email_reset_password']): ?>checked<?php endif; ?>>
					<label class="custom-control-label">启用邮件找回密码</label>
				</div>
				<div class="custom-control custom-radio" data-after="email_reset_password">
					<input name="setting[email_reset_password]" type="radio" class="custom-control-input" value="0" <?php if(!$_G['setting']['email_reset_password']): ?>checked<?php endif; ?>>
					<label class="custom-control-label">禁用邮件找回密码</label>
				</div>
				<small class="form-text text-muted">启用后用户可通过邮件自助重置密码（仅针对已绑定邮箱的用户）</small>
			</div>
			<div class="form-group email_reset_content <?php if(!$_G['setting']['email_reset_password']): ?>d-none<?php endif; ?>">
				<label class="font-weight-bold">密码重置邮件内容</label>
				<div class="editor-box"><textarea class="editor d-none" name="setting[email_reset_content]"><?php echo htmlentities($_G['setting']['email_reset_content']); ?></textarea></div>
				<small class="form-text text-muted">用户自助找回密码时收到的邮件内容，内容中必须包含<strong class="px-2 text-success">[RESET_CODE]</strong>代码，该代码会被替换成验证码（不限次数）</small>
			</div>
		</div>
		<div class="card-footer">
			<button type="submit" class="btn btn-success ajax-post">保存设置</button>
		</div>
	</div>
</form>
<script type="text/javascript">
	function email_register(input,data){
		$('.email_register_content').addClass('d-none');
		if(input.val() == 1){
			$('.email_register_content').removeClass('d-none');
		}
	}
	function email_reset_password(input,data){
		$('.email_reset_content').addClass('d-none');
		if(input.val() == 1){
			$('.email_reset_content').removeClass('d-none');
		}
	}
</script>
</div>
	<script type="text/javascript">
		$(function(){
			$.ajax({
				url:'<?php echo url('admin/tools/check_new_version'); ?>',
				success:function(s){
					if(s.code == 1){
						$('.new-version-nav').removeClass('d-none');
						<?php if(empty(cookie('new_version_tip'))): ?>
							dialog.open({
								type: 1,
								anim: 2,
								shadeClose: false,
								content: '<div class="p-3">发现程序新版本，请及时更新程序确保解析功能正常<br>新版本号：<strong class="text-danger">'+s.data.new_version+'</strong><br><a href="<?php echo url('admin/tools/upgrade'); ?>">前往升级</a></div>'
							});
							<?php cookie('new_version_tip',1,86400); ?>
						<?php endif; ?>
					}
				}
			})
			$.ajax({
				url:'<?php echo url('index/job/index'); ?>',
				success:function(s){
					console.log(s);
				}
			})
		})
	</script>
</body>
</html>


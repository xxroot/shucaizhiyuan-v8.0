<?php

return [
    'default' => 'local',
    'disks'   => [
        'local' => [
            'type'       => 'local',
            'root'       => app()->getRootPath() . 'public/',
            'url'        => '/',
            'visibility' => 'public',
        ],
        // 更多的磁盘配置信息
    ],
];
